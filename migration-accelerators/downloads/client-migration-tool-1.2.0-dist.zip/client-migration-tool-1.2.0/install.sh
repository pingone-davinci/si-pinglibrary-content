#!/bin/sh -e

SCRIPT_DIR=$(dirname "$0" | pwd)
. "${SCRIPT_DIR}/lib/_common.sh"

if [ -r "${CLIENT_MIGRATION_TOOL_CONF}" ]; then
    . "${CLIENT_MIGRATION_TOOL_CONF}"
fi

check_command awk
check_command unzip

####################################################
# Function to set environment vars
####################################################
set_env_vars() {

  echo "
###################################################################
# CLOUD_MIGRATION_KEY (required)                                  #
#   This should be the EXACT same key used during the             #
#   PingFederate export script.  This will be used to encrypt     #
#   the data as client information is collected.                  #
#                                                                 #
# CLIENT_MIGRATION_EXPORT_FILE (required)                         #
#   This is the name of the path/file that will be created to     #
#   hold the exported client information.                         #
#                                                                 #
# CLIENT_MIGRATION_LIMIT (optional, default=1000)                 #
#   Limit to number of unique client id/secret combinations will  #
#   will be allowed before collections will stop.  Helps with     #
#   possible DOS attacks.                                         #
#                                                                 #
# CLIENT_MIGRATION_DUPLICATE_IDS (optional, default=false)        #
#   Allows for collection of duplicate clientIDs, if same client  #
#   is used with different secret.  If set to true, all client ID #
#   and secret combinations will be collected.                    #
#                                                                 #
# CLIENT_MIGRATION_INCLUDE_IDS (optional, default= )              #
#   This is a comma-separated list of client IDs to include in    #
#   the export. If not specified, all clients will be exported.   #
#                                                                 #
# CLIENT_MIGRATION_EXCLUDE_IDS (optional, default= )              #
#   This is a comma-separated list of client IDs to exclude from  #
#   the export. If not specified, no clients will be excluded.    #
###################################################################
"

  # Prompt for PingFederate Admin API information
  read -r -sp "            CLOUD_MIGRATION_KEY: " CLOUD_MIGRATION_KEY && echo && echo
  read -r -p "   CLIENT_MIGRATION_EXPORT_FILE: " CLIENT_MIGRATION_EXPORT_FILE && echo
  read -r -p "         CLIENT_MIGRATION_LIMIT: " CLIENT_MIGRATION_LIMIT && echo
  read -r -p " CLIENT_MIGRATION_DUPLICATE_IDS: " CLIENT_MIGRATION_DUPLICATE_IDS && echo
  read -r -p "   CLIENT_MIGRATION_INCLUDE_IDS: " CLIENT_MIGRATION_INCLUDE_IDS && echo
  read -r -p "   CLIENT_MIGRATION_EXCLUDE_IDS: " CLIENT_MIGRATION_EXCLUDE_IDS && echo

    {
        echo "# Environment variables for Client Migration Tool"
        echo "# Generated on $(date)"
        echo ""
        echo "export CLOUD_MIGRATION_KEY=${CLOUD_MIGRATION_KEY}"
        echo "export CLIENT_MIGRATION_EXPORT_FILE=${CLIENT_MIGRATION_EXPORT_FILE}"
        echo "export CLIENT_MIGRATION_LIMIT=${CLIENT_MIGRATION_LIMIT}"
        echo "export CLIENT_MIGRATION_DUPLICATE_IDS=${CLIENT_MIGRATION_DUPLICATE_IDS}"
        echo "export CLIENT_MIGRATION_INCLUDE_IDS=${CLIENT_MIGRATION_INCLUDE_IDS}"
        echo "export CLIENT_MIGRATION_EXCLUDE_IDS=${CLIENT_MIGRATION_EXCLUDE_IDS}"
    } > "${CLIENT_MIGRATION_TOOL_CONF}"
}

####################################################
# Function to add filter
####################################################
add_filter() {
  WEB_XML="WEB-INF/web.xml"

  # Copy pf-runtime.war to bak dir as original
  if [ ! -r "${BAK_PF_RUNTIME}" ]; then
    cp "${PF_RUNTIME}" "${BAK_PF_RUNTIME}"
  fi

  # Copy pf-runtime.war to as original
  if [ ! -r "${PF_RUNTIME}-orig" ]; then
    cp "${PF_RUNTIME}" "${PF_RUNTIME}-orig"
  fi

  # If there is no run.conf, create an empty one
  if [ ! -r "${PF_RUN_CONF}" ]; then
    touch "${PF_RUN_CONF}"
  fi

  # Copy run.conf to bak dir as original
  if [ ! -r "${BAK_RUN_CONF}" ]; then
    cp "${PF_RUN_CONF}" "${BAK_RUN_CONF}"
  fi

  # Copy run.conf to server dir as original
  if [ ! -r "${PF_RUN_CONF}-orig" ]; then
    cp "${PF_RUN_CONF}" "${BAK_RUN_CONF}-orig"
  fi

  FILTER_NAME="ClientMigrationToolFilter"
  FILTER_CLASS="com.ping.internal.ClientMigrationTool"
  URL_PATTERN_ARRAY="/as/token.oauth2 /as/introspect.oauth2 /as/revoke_token.oauth2 /as/par.oauth2"

  cd "${TMP_DIR}"
  unzip "${PF_RUNTIME}" "${WEB_XML}"

  # Check if filter already exists
  if grep -q "<filter-name>$FILTER_NAME</filter-name>" "$WEB_XML"; then
      echo "Filter $FILTER_NAME already exists. Skipping filter addition."
  else
      cp "${PF_RUNTIME}" "${AUDIT_DIR}/pf-runtime.war.before"
      cp "${WEB_XML}" "${AUDIT_DIR}/web.xml.before"

      # Add <filter> after the last </filter>
      awk -v filter_name="$FILTER_NAME" -v filter_class="$FILTER_CLASS" '
          /<\/filter>/ { last_filter=NR }
          { lines[NR]=$0 }
          END {
              for (i=1; i<=NR; i++) {
                  print lines[i]
                  if (i == last_filter) {
                      print "    <filter>"
                      print "        <filter-name>" filter_name "</filter-name>"
                      print "        <filter-class>" filter_class "</filter-class>"
                      print "    </filter>"
                  }
              }
          }
      ' "$WEB_XML" > "$WEB_XML.tmp" && mv "$WEB_XML.tmp" "$WEB_XML"

    # Add <filter-mapping> for each URL pattern if not already present
    for URL_PATTERN in ${URL_PATTERN_ARRAY}; do
      if grep -q "<url-pattern>$URL_PATTERN</url-pattern>" "${WEB_XML}"; then
            echo "Filter-mapping for $FILTER_NAME and $URL_PATTERN already exists. Skipping mapping addition."
        else
            awk -v filter_name="$FILTER_NAME" -v url_pattern="$URL_PATTERN" '
                /<\/filter-mapping>/ { last_mapping=NR }
                { lines[NR]=$0 }
                END {
                    for (i=1; i<=NR; i++) {
                        print lines[i]
                        if (i == last_mapping) {
                            print "    <filter-mapping>"
                            print "        <filter-name>" filter_name "</filter-name>"
                            print "        <url-pattern>" url_pattern "</url-pattern>"
                            print "    </filter-mapping>"
                        }
                    }
                }
            ' "$WEB_XML" > "$WEB_XML.tmp" && mv "$WEB_XML.tmp" "$WEB_XML"
        fi
    done

    zip "${PF_RUNTIME}" "${WEB_XML}"

    cp "${PF_RUNTIME}" "${AUDIT_DIR}/pf-runtime.war.after"
    cp "${WEB_XML}" "${AUDIT_DIR}/web.xml.after"

    # diff "${AUDIT_DIR}/web.xml.before" "${AUDIT_DIR}/web.xml.after" > "${AUDIT_DIR}/web.xml.diff"

    #
    # Install the Client Migration Tool JAR file
    #
    cp "${SCRIPT_DIR}"/lib/client-migration-tool-*.jar "${PF_ROOT_DIR}/server/default/deploy/."
  fi

  # Update run.conf with CLIENT_MIGRATION_TOOL_CONF
  echo "Updating run.conf with Client Migration Tool configuration..."
  PF_RUN_CONF_HEADER="# Client Migration Tool Configuration"
  if ! grep -q "${PF_RUN_CONF_HEADER}" "${PF_RUN_CONF}"; then
    echo "" >> "${PF_RUN_CONF}"
    echo "${PF_RUN_CONF_HEADER}" >> "${PF_RUN_CONF}"
    cat "${CLIENT_MIGRATION_TOOL_RUN_CONF}" >> "${PF_RUN_CONF}"
  else
    echo "Client Migration Tool configuration already exists in run.conf. Skipping update."
  fi
}

####################################################
# Function to display environment details
####################################################
display_environment_info() {
    echo "# "
    echo "#               Script Version: ${SCRIPT_VERSION:-Not Set}"
    echo "#        Server Root Directory: ${SERVER_ROOT_DIR:-Not Set}"
    echo "# "

    if [ -z "${CLOUD_MIGRATION_KEY}" ]; then
        echo "#            CLOUD_MIGRATION_KEY: Not Set"
    else
        echo "#            CLOUD_MIGRATION_KEY: ********"
    fi

    echo "#   CLIENT_MIGRATION_EXPORT_FILE: ${CLIENT_MIGRATION_EXPORT_FILE:-Not Set}"
    echo "#         CLIENT_MIGRATION_LIMIT: ${CLIENT_MIGRATION_LIMIT:-Not Set}"
    echo "# CLIENT_MIGRATION_DUPLICATE_IDS: ${CLIENT_MIGRATION_DUPLICATE_IDS:-Not Set}"
    echo "#   CLIENT_MIGRATION_INCLUDE_IDS: ${CLIENT_MIGRATION_INCLUDE_IDS:-Not Set}"
    echo "#.  CLIENT_MIGRATION_EXCLUDE_IDS: ${CLIENT_MIGRATION_EXCLUDE_IDS:-Not Set}"
}

uninstall() {
    if [ -r "${BAK_PF_RUNTIME}" ]; then
    echo "Restoring original pf-runtime.war from backups..."
        cp "${BAK_PF_RUNTIME}" "${PF_RUNTIME}"
    fi

    if [ -r "${BAK_RUN_CONF}" ]; then
        echo "Restoring original run.conf from backups..."
        cp "${BAK_RUN_CONF}" "${PF_RUN_CONF}"
    fi

    #
    # Remove the Client Migration Tool JAR file
    #
    echo "Removing Client Migration Tool JAR file..."
    rm -f "${PF_ROOT_DIR}"/server/default/deploy/client-migration-tool-*.jar || erro
}

####################################################
# Function to display the top menu
####################################################
menu() {
    clear
    echo "##############################################################"
    echo "#                     Client Migration Tool"
    display_environment_info
    echo "##############################################################"
    echo "#  1. Set Environment Variables"
    echo "#"
    echo "#  2. Install Client Migration Tool Filter"
    echo "#"
    echo "#  3. UnInstall Client Migration Tool Filter"
    echo "#"
    echo "#  Q: Quit"
    echo "##############################################################"
}

####################################################
# Function to execute the command based on top menu
####################################################
execute_choice() {
    case $1 in
        1)
            set_env_vars
            ;;
        2)
            add_filter
            ;;
        3)
            uninstall
            ;;
        Q | q)
            exit
            ;;
        *)
            echo "Invalid option"
            ;;
    esac
}

####################################################
# Main Loop
####################################################
while true; do
    menu
    printf "\nEnter your choice: "
    read choice
    clear
    execute_choice $choice
    echo ""
    printf "Press Enter to continue..."
    read _dummy
    clear
done
