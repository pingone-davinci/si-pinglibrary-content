#!/bin/sh

# Set these variables as needed
TMP_DIR=$(mktemp -d)
DATE=$(date +"%y%m%d-%H%M%S")
SCRIPT_DIR=$(dirname "$0" | pwd)

AUDIT_DIR="${SCRIPT_DIR}/audit/${DATE}"
BAK_DIR="${SCRIPT_DIR}/bak"

mkdir -p "${AUDIT_DIR}"
mkdir -p "${BAK_DIR}"

cleanup() { rm -rf "${TMP_DIR}"; }
trap cleanup EXIT
error() {
    echo
    echo "ERROR: ${1}"
    exit 1
}
check_command() {
    command -v "$1" 1> /dev/null 2> /dev/null
    if [ $? -ne 0 ]; then
        error "$1 command not found. Please install '$1'."
    fi
}
audit() { echo "${1}" >> "${AUDIT_DIR}/log"; }

if [ ! -z "${SERVER_ROOT_DIR}" ]; then
  PF_ROOT_DIR=${SERVER_ROOT_DIR}
else
  echo "Unable to get env variable SERVER_ROOT_DIR"
fi

CLIENT_MIGRATION_TOOL_JAR=$(ls "${SCRIPT_DIR}/lib/"client-migration-tool-*.jar | head -n 1)
SCRIPT_VERSION=$(echo "$CLIENT_MIGRATION_TOOL_JAR" | sed -E 's/.*client-migration-tool-([0-9]+\.[0-9]+\.[0-9]+)\.jar/\1/')
PF_RUN_CONF="${PF_ROOT_DIR}/bin/run.conf"
CLIENT_MIGRATION_TOOL_RUN_CONF="${SCRIPT_DIR}/lib/run.conf"
CLIENT_MIGRATION_TOOL_CONF="${PF_ROOT_DIR}/bin/client-migration-tool.conf"
PF_RUNTIME="${PF_ROOT_DIR}/server/default/deploy/pf-runtime.war"
BAK_PF_RUNTIME="${BAK_DIR}/pf-runtime.war"
BAK_RUN_CONF="${BAK_DIR}/run.conf"

audit "Starting run of ${0} on ${DATE}"