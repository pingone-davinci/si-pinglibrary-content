#!/bin/sh

PF="https://localhost:9031"

uuid="uuidgen"

if [ "$(uname -o)" == "Linux" ]; then
  uuid="cat /proc/sys/kernel/random/uuid"
fi

test_path() {
  local path="$1"
  local url="${PF}${path}"

  curl -k --location "${url}?grant_type=client_credentials" \
    --header 'Content-Type: application/x-www-form-urlencoded' \
    --data-urlencode "client_id=---STARTING TEST----$(date)" \
    --data-urlencode "client_secret=$($uuid)" \
    > /dev/null 2>&1

  curl -k --location "${url}?grant_type=client_credentials" \
    --header 'Content-Type: application/x-www-form-urlencoded' \
    --data-urlencode "client_id=POST-${path}-$($uuid)" \
    --data-urlencode "client_secret=$($uuid)" \
    > /dev/null 2>&1

  curl -X GET \
    -k --location "${url}?grant_type=client_credentials&client_id=GET-${path}-$($uuid)&client_secret=$($uuid)" \
    > /dev/null 2>&1

  curl -X GET \
    -k --location "${url}?grant_type=client_credentials" \
    --user "AUTH-${path}-$($uuid):$($uuid)" \
    > /dev/null 2>&1
}

test_path "/as/token.oauth2"
test_path "/as/introspect.oauth2"
test_path "/as/revoke_token.oauth2"
test_path "/as/par.oauth2"
test_path "/as/INVALID.oauth2"