/***************************************************************************
 * Copyright (C) 2006 Ping Identity Corporation
 * All rights reserved.
 *
 * The contents of this file are the property of Ping Identity Corporation.
 * You may not copy or use this file, in either source code or executable
 * form, except in compliance with terms set by Ping Identity Corporation.
 * For further information please contact:
 *
 *      Ping Identity Corporation
 *      1099 18th St Suite 2950
 *      Denver, CO 80202
 *      303.468.2900
 *      http://www.pingidentity.com
 *
 **************************************************************************/

package com.pingidentity.wam.agent;

import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.Iterator;
import java.util.Set;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import org.apache.commons.collections.MultiMap;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.pingidentity.wam.sdk.WAMAgent;
import com.pingidentity.wam.sdk.WAMAgentHelper;
import com.pingidentity.wam.sdk.WAMAgentInitializeException;
import com.pingidentity.wam.sdk.WAMConfiguration;
import com.pingidentity.wam.sdk.WAMConstants;
import com.pingidentity.wam.sdk.WAMLoginException;
import com.pingidentity.wam.sdk.WAMTokenExpiredException;
import com.pingidentity.wam.sdk.WAMTokenInvalidException;
import com.pingidentity.wam.sdk.WAMTokenNotAuthorizedException;
import com.pingidentity.wam.sdk.WAMTokenCreationException;
import com.pingidentity.wam.sdk.WAMConfigValidationException;

import sirrus.runtime.APIFactory;
import sirrus.runtime.RuntimeAPI;
import sirrus.connect.ConnectionDescriptor;
import sirrus.runtime.RuntimeAPIException;
import sirrus.runtime.TokenException;
import sirrus.runtime.OptionConstants;
import sirrus.runtime.UserConstants;
import sirrus.runtime.AuthTypes;
import sirrus.runtime.TokenKeys;
import sirrus.runtime.ResourceConstants;
import sirrus.runtime.ResultConstants;

public class RSAAMAgent
    implements WAMAgent
{
    private static final Logger log = Logger.getLogger(RSAAMAgent.class);

    private static final String RSA_DISPATCHER_PORT_DEFAULT = "5608";
    private static final String RSA_DEFAULT_USERID_ATTRIBUTE = UserConstants.SC_USER_ID;

    private WAMConfiguration wamConfiguration = null;
    private RuntimeAPI runtimeAPI;
    private Map<String, String> resourceMap = null;

    public String getAgentType()
    {
        return "RSA";
    }

    public boolean initializeAgent(WAMConfiguration wamConfigData)
        throws WAMAgentInitializeException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------RSAAMAgent.initializeAgent(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        // You can also store the configuration data locally so that rest of the methods
        // have access to them
        this.wamConfiguration = wamConfigData;

        // Use configuration data obtained above to establish connection with WAM Servers
        try
        {
            List<ConnectionDescriptor> connectionDescriptorList = new ArrayList<ConnectionDescriptor>();
            int retries = 1;
            int timeout = 15000;
            for (HashMap<String, String> rsaServer : wamConfigData.getRSAServers())
            {
                String dispatcherHost = rsaServer.get(WAMConstants.WAM_RSA_SERVER_NAME_FIELD);
                int dispatcherPort = Integer.parseInt(!StringUtils.isBlank(rsaServer.get(WAMConstants.WAM_RSA_SERVER_DISPATCHER_PORT_FIELD)) ? rsaServer.get(WAMConstants.WAM_RSA_SERVER_DISPATCHER_PORT_FIELD)
                        : RSA_DISPATCHER_PORT_DEFAULT);
                int authType = Integer.parseInt(rsaServer.get(WAMConstants.WAM_RSA_SERVER_AUTH_FIELD));
                ConnectionDescriptor connectionDescriptor = null;

                try
                {
                    timeout = Integer.parseInt(rsaServer.get(WAMConstants.WAM_RSA_SERVER_TIMEOUT_FIELD));
                    retries = Integer.parseInt(rsaServer.get(WAMConstants.WAM_RSA_SERVER_RETRIES_FIELD));
                }
                catch (NumberFormatException e)
                {
                    log.info("ERROR: Plugin Configuration missing timeout or retry value");
                    log.info("WARNING: Using Default values for RSA plugin configuration parameters: retries: "
                             + retries + " timeout: " + timeout + "ms");
                }

                if (authType == ConnectionDescriptor.SSL_AUTH)
                {
                    String keystoreFile = rsaServer.get(WAMConstants.WAM_RSA_SERVER_KEYSTORE_PATH_FIELD);
                    String keystorePassword = rsaServer.get(WAMConstants.WAM_RSA_SERVER_KEYSTORE_PASSWORD_FIELD);
                    String keyAlias = rsaServer.get(WAMConstants.WAM_RSA_SERVER_KEY_ALIAS_FIELD);
                    String keyPassword = rsaServer.get(WAMConstants.WAM_RSA_SERVER_KEY_PASSWORD_FIELD);
                    connectionDescriptor = new ConnectionDescriptor(dispatcherHost, dispatcherPort,
                                                                    ConnectionDescriptor.SSL_AUTH, keystoreFile,
                                                                    keystorePassword, keystoreFile, keystorePassword,
                                                                    keyAlias, keyPassword, timeout);
                }
                else
                {
                    connectionDescriptor = new ConnectionDescriptor(dispatcherHost, dispatcherPort, authType);
                }
                log.info(" + dispatcher");
                connectionDescriptorList.add(connectionDescriptor);
            }

            log.debug("rsa Retries set to: " + retries);
            log.debug("rsa Timeout set to: " + timeout + "ms");

            runtimeAPI = APIFactory.createFromServerDispatchers(null,
                                                                connectionDescriptorList.toArray(new ConnectionDescriptor[connectionDescriptorList.size()]),
                                                                null, timeout, false, null, retries);

            if (!StringUtils.isEmpty(wamConfigData.getAgentName()))
            {
                this.resourceMap = new HashMap<String, String>();
                this.resourceMap.put(ResourceConstants.TYPE, ResourceConstants.WEB_RESOURCE);
                this.resourceMap.put(ResourceConstants.WEB_SERVER_NAME, wamConfigData.getAgentName());
                this.resourceMap.put(ResourceConstants.URI, wamConfigData.getProtectedResource());
            }
            log.info(" + runtimeAPI");

        }
        catch (RuntimeAPIException e)
        {
            throw new WAMAgentInitializeException(e);
        }
        return true;
    }

    public void validateConfiguration(WAMConfiguration wamConfigData)
        throws WAMConfigValidationException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------RSAAMAgent.validateConfiguration(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        // Validate the input configuration and throw a WAMConfigValidationException
        // exception if any errors are encountered.
        // validate that the user has configured at least 1 policy server
        if (wamConfigData.getRSAServers().isEmpty())
            throw new WAMConfigValidationException("An RSA Dispatcher Server must be configured within WAM Servers.");

    }

    public String createToken(WAMConfiguration wamConfigData, String username, MultiMap extendedAttributes)
        throws WAMTokenCreationException, WAMTokenNotAuthorizedException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------RSAAMAgent.createToken(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());        
        msg.append("username: ").append(username);

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        String tokenString = "";
        Map ret_vals = null;
        Map user = new HashMap();
        Map resource = new HashMap();
        Map values = new HashMap();

        user.put(UserConstants.SC_USER_ID, username);

        // Check authorization if Agent name and protected resource are identified
        if (resourceMap != null)
        {
            try
            {
                Map resultMap = runtimeAPI.authorize(user, resourceMap);
                String returnCode = (String)resultMap.get(ResultConstants.RETURN_CODE);
                String authorizationResult = (String)resultMap.get(ResultConstants.AUTHORIZATION_RESULT);
                log.debug("authorizationResult = " + authorizationResult);
                log.debug("authorizationReturnCode = " + returnCode);
                if (!returnCode.equalsIgnoreCase(ResultConstants.ACCESS_ALLOWED))
                {
                    String errorMessage = "User '" + username + "' is not auhtorized to access protected resource.";
                    log.error(errorMessage);
                    throw new WAMTokenNotAuthorizedException(errorMessage);
                }
            }
            catch (RuntimeAPIException rae)
            {
                log.error(rae);
                throw new WAMTokenCreationException(rae.getMessage());
            }            
        }    
        
        try
        {
            user.put(UserConstants.AUTHENTICATION_TYPE, AuthTypes.SC_BASIC);

            // The OptionConstants.TOKEN_OPTIONS must be included within
            // the user map if we want the created token to be returned.
            user.put(OptionConstants.TOKENS_OPTION, OptionConstants.ON);

            // The RuntimeAPI.createToken() method allows an explicit
            // token to be created for a specified user.
            tokenString = runtimeAPI.createToken(user);
            log.debug("tokenString = " + tokenString);

            // New values may now placed into a map to be set within
            // the token.
            //values.put(TokenKeys.SC_NT_PASSWORD, "myNTpassword");
            //values.put(TokenKeys.SC_NT_DOMAIN, "myNTdomain");
            // Obtain Client IP Address from extended Attributes
            values.put(TokenKeys.SC_CLIENT_IP, WAMAgentHelper.getServerAddress());
            values.put(AuthTypes.SC_BASIC, "true");
            values.put(AuthTypes.SC_LDAP, "true");

            tokenString = runtimeAPI.setTokenValues(tokenString, values);
            log.debug("RSA Token = " + tokenString);
            if(wamConfigData.isEncodeToken())
            {
                tokenString = URLEncoder.encode(tokenString,"UTF-8");
                log.debug("RSA Encoded Token = " + tokenString);
            }
        }
        catch (TokenException te)
        {
            log.error(te);
            throw new WAMTokenCreationException(te.getMessage());
        }
        catch (RuntimeAPIException rae)
        {
            log.error(rae);
            throw new WAMTokenCreationException(rae.getMessage());
        }
        catch (Exception e)
        {
            log.error(e);
            throw new WAMTokenCreationException(e.getMessage());
        }
        return tokenString;
    }

    public Map<String, String> getAttributes(WAMConfiguration wamConfigData, String tokenString)
        throws WAMTokenInvalidException, WAMTokenExpiredException, WAMTokenNotAuthorizedException, WAMLoginException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------RSAAMAgent.getAttributes(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());
        msg.append("WAM Token String: ").append(tokenString);

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        Map<String, String> userAttributes = new HashMap<String, String>();

        try
        {
            String CTSESSION = URLDecoder.decode(tokenString, "UTF-8");
            String token = runtimeAPI.validateToken(CTSESSION);
            Map ret_vals = runtimeAPI.getTokenValues(token);
            log.debug(ret_vals);
            String userIdAttribute = this.wamConfiguration.getUserIdentifier();
            if (StringUtils.isEmpty(userIdAttribute))
            {
                userIdAttribute = RSA_DEFAULT_USERID_ATTRIBUTE;
            }
            log.debug("UserId Attribute Name = " + userIdAttribute);

            if (ret_vals.get(userIdAttribute) == null)
            {
                String errorMessage = "Could not obtain userId attribute '" + userIdAttribute
                                      + "' from resulting attributes.";
                log.error(errorMessage);
                throw new WAMLoginException(errorMessage);
            }

            String userId = ret_vals.get(userIdAttribute).toString();

            log.debug("UserId Attribute Value = " + userId);

            // Instrumented fix that ONLY handles checking token for SC_BASIC=true to determine that it is an
            // authenticated  session prior to doing any authorization checks if agent name is specified - STAGING-1726
            if (ret_vals.get(AuthTypes.SC_BASIC) != null && ret_vals.get(AuthTypes.SC_BASIC).toString().equals("true"))
            {
                log.debug("SC_BASIC AuthType is: " + ret_vals.get(AuthTypes.SC_BASIC));
            }
            else
            {
                String errorMessage = "User '" + userId + "' is not authenticated to access protected resource.";
                log.error(errorMessage);
                throw new WAMTokenInvalidException(errorMessage);
            }

            // Check authorization if Agent name and protected resource are identified
            if (resourceMap != null)
            {
                Map resultMap = runtimeAPI.authorize(ret_vals, resourceMap);
                String returnCode = (String)resultMap.get(ResultConstants.RETURN_CODE);
                String authorizationResult = (String)resultMap.get(ResultConstants.AUTHORIZATION_RESULT);
                log.debug("authorizationResult = " + authorizationResult);
                log.debug("authorizationReturnCode = " + returnCode);
                if (!returnCode.equalsIgnoreCase(ResultConstants.ACCESS_ALLOWED))
                {
                    String errorMessage = "User '" + userId + "' is not auhtorized to access protected resource.";
                    log.error(errorMessage);
                    throw new WAMTokenNotAuthorizedException(errorMessage);
                }
            }
            userAttributes.putAll(ret_vals);
            userAttributes.put("userId", userId);
        }
        catch (TokenException te)
        {
            log.error(te);
            throw new WAMTokenExpiredException(te.getMessage());
        }
        catch (UnsupportedEncodingException uee)
        {
            log.error(uee);
            throw new WAMTokenExpiredException(uee.getMessage());
        }
        catch (RuntimeAPIException rae)
        {
            log.error(rae);
            throw new WAMTokenExpiredException(rae.getMessage());
        }

        return userAttributes;
    }

    public boolean logout(WAMConfiguration wamConfigData, String tokenString)
        throws WAMTokenInvalidException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------RSAAMAgent.logout(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());
        msg.append("WAM Token String: ").append(tokenString);

        msg.append("\n-----------------------------------------------------------------å-----\n");

        log.debug(msg);

        // Invalidate user session with WAM servers using proprietary APIs

        return true;
    }

    /** @deprecated */
    public String createToken(String username, MultiMap extendedAttributes)
        throws WAMTokenCreationException
    {
        String errorMessage = "createToken(String username, MultiMap extendedAttributes) Method not implemented for this version.";
        log.warn(errorMessage);
        throw new WAMTokenCreationException(errorMessage);
    }

    /** @deprecated */
    public Map<String, String> getAttributes(String tokenString)
        throws WAMTokenInvalidException, WAMTokenExpiredException, WAMTokenNotAuthorizedException, WAMLoginException
    {
        String errorMessage = "getAttributes(String tokenString) Method not implemented for this version.";
        log.warn(errorMessage);
        throw new WAMLoginException(errorMessage);
    }

    /** @deprecated */
    public boolean logout(String tokenString)
        throws WAMTokenInvalidException
    {
        String errorMessage = "logout(String tokenString) Method not implemented for this version.";
        log.warn(errorMessage);
        throw new WAMTokenInvalidException(errorMessage);
    }
    
}
