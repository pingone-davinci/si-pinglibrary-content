/***************************************************************************
 * Copyright (C) 2012 Ping Identity Corporation
 * All rights reserved.
 *
 * The contents of this file are the property of Ping Identity Corporation.
 * You may not copy or use this file, in either source code or executable
 * form, except in compliance with terms set by Ping Identity Corporation.
 * For further information please contact:
 *
 *      Ping Identity Corporation
 *      1001 17th Street Suite 100
 *      Denver, CO 80202
 *      303.468.2900
 *      http://www.pingidentity.com
 *
 **************************************************************************/

import java.util.Map;
import java.util.HashMap;

import oracle.security.am.plugin.authn.*;
import oracle.security.am.plugin.*;

public class PingCustomAuthPlugin
extends AbstractAuthenticationPlugIn
{
    private String pluginSecret;

    public ExecutionStatus initialize(PluginConfig config)
    {
        super.initialize(config);
        Object tmp = config.getParameter("pluginSecret");
        if (tmp != null)
        {
            pluginSecret = (String)tmp;
        }
        return ExecutionStatus.SUCCESS;
    }

    public void setMonitoringStatus(boolean status)
    {

    }

    public boolean getMonitoringStatus()
    {
        return true;
    }

    public Map<String, MonitoringData> getMonitoringData()
    {
        Map<String, MonitoringData> monitoringData = new HashMap<String, MonitoringData>();
        return monitoringData;
    }

    public int getRevision()
    {
        return 1;
    }

    public String getPluginName()
    {
        return "PingCustomAuthPlugin";
    }

    public String getDescription()
    {
        return "Ping Identity Custom Authentication PlugIn";
    }

    public ExecutionStatus process(AuthenticationContext context)
    throws AuthenticationException
    {
        String requestSecret = "";
        CredentialParam tmp = context.getCredential().getParam("pluginSecret");
        if ((tmp != null) && (tmp.getValue() != null))
        {
            requestSecret = (String)tmp.getValue();
        }

        if (requestSecret.equalsIgnoreCase(pluginSecret))
        {
            return ExecutionStatus.SUCCESS;
        }
        else
        {
            return ExecutionStatus.FAILURE;
        }
    }
}
