/*******************************************************************************
* Copyright (C) 2008 Ping Identity Corporation All rights reserved.
*
* This software is licensed under the Open Software License v2.1 (OSL v2.1).
*
* A copy of this license has been provided with the distribution of this
* software. Additionally, a copy of this license is available at:
* http://opensource.org/licenses/osl-2.1.php
*
******************************************************************************
*/
using System;
using System.Data;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.SessionState;
using System.Collections;
using System.Collections.Generic;
using opentoken;
using opentoken.util;
using Com.PingIdentity.PingFederate.SampleApp.SampleAppUtility;

namespace com.pingidentity.adapters.sampleapp.sp
{

    /// <summary>
    /// Summary description for OTSPHttpModule
    /// </summary>
    public class OTSPHttpModule : IHttpModule
    {
        private Links samlLinks;
        private String configPath = "";

        public OTSPHttpModule()
        {
        }

        public String ModuleName
        {
            get { return "OTSPHttpModule"; }
        }

        // In the Init function, register for HttpApplication 
        // events by adding your handlers.
        public void Init(HttpApplication application)
        {
            application.PostAcquireRequestState += new EventHandler(Application_PostAcquireRequestState);
            application.BeginRequest +=
                (new EventHandler(this.Application_BeginRequest));
            application.EndRequest +=
                (new EventHandler(this.Application_EndRequest));
        }

        void Application_PostAcquireRequestState(object source, EventArgs e)
        {
            HttpApplication app = (HttpApplication)source;
            // -> at this point session state should be available
            HttpContext context = app.Context;
            HttpRequest request = context.Request;
            HttpResponse response = context.Response;
            HttpSessionState session = HttpContext.Current.Session;


            if (samlLinks.configTable["tokenType"].Equals("OpenToken"))
            {
                String cmd = request["cmd"];
                switch (cmd)
                {
                    case "sso":
                        HandleSPSSORequest(context, request, response, session);
                        break;

                    case "slo":
                        HandleSPSLORequest(context, request, response, session);
                        break;

                    case "accountlink":
                        HandleSPAccountLinkingRequest(context, request, response, session);
                        break;

                    case "logout":
                        HandleLogoutRequest(context, request, response, session);
                        break;

                    default:
                        HandleSPSSORequest(context, request, response, session);
                        break;

                }

            }
        }



        private void Application_BeginRequest(Object source,
             EventArgs e)
        {
            HttpApplication app = (HttpApplication)source;
            HttpContext context = app.Context;
            //get properties from Idp config file
            String spConfig = ConfigurationManager.AppSettings["config-file"];
            configPath = HttpRuntime.AppDomainAppPath + "\\config\\";
            samlLinks = new Links(context, configPath + spConfig);
        }

        private void Application_EndRequest(Object source, EventArgs e)
        {
            HttpApplication application = (HttpApplication)source;
            HttpContext context = application.Context;
        }

        public void Dispose()
        {
        }

        private void HandleSPSSORequest(HttpContext context, HttpRequest request, HttpResponse response, HttpSessionState session)
        {
            MultiStringDictionary userInfo = getOpenToken(context);
            if (userInfo != null)
            {
                // Set attributes in session
                if (session != null)
                {
                    session.Add(Constants.USER_INFO, (MultiStringDictionary)userInfo);
                }

                if (request.Cookies[FormsAuthentication.FormsCookieName] == null)
                {
                    FormsAuthenticationTicket tkt;
                    string cookiestr;
                    HttpCookie ck;
                    tkt = new FormsAuthenticationTicket(1, (String)userInfo[Constants.SUBJECT][0], DateTime.Now,
                        DateTime.Now.AddMinutes(30), false, userInfo.ToString());
                    cookiestr = FormsAuthentication.Encrypt(tkt);
                    ck = new HttpCookie(FormsAuthentication.FormsCookieName, cookiestr);
                    ck.Path = FormsAuthentication.FormsCookiePath;
                    response.Cookies.Add(ck);
                }
            }
        }

        private void HandleSPSLORequest(HttpContext context, HttpRequest request, HttpResponse response, HttpSessionState session)
        {
            MultiStringDictionary attributes;
            if (request.Cookies[FormsAuthentication.FormsCookieName] != null)
            {
                string cookiestr;
                cookiestr = request.Cookies[FormsAuthentication.FormsCookieName].Value;
                FormsAuthenticationTicket tkt = FormsAuthentication.Decrypt(cookiestr);
                if (session != null)
                {
                    // Get attributes from session
                    attributes = (MultiStringDictionary)session[Constants.USER_INFO];
                }
                else
                {
                    attributes = new MultiStringDictionary();
                    attributes.Add(Constants.SUBJECT, tkt.Name);
                }
                //session.Clear();
                FormsAuthentication.SignOut();
            }
            else
            {
                attributes = new MultiStringDictionary();
                attributes.Add(Constants.SUBJECT, "logout");
            }
            string strRedirect;
            if (request[Constants.RESUME_PATH] != null)
            {
                strRedirect = Links.hostPF + request[Constants.RESUME_PATH];
                response.Redirect(strRedirect, true);
            }
        }

        private void HandleSPAccountLinkingRequest(HttpContext context, HttpRequest request, HttpResponse response, HttpSessionState session)
        {
            if (request.Cookies[FormsAuthentication.FormsCookieName] != null)
            {
                string cookiestr;
                cookiestr = request.Cookies[FormsAuthentication.FormsCookieName].Value;
                FormsAuthenticationTicket tkt = FormsAuthentication.Decrypt(cookiestr);
                MultiStringDictionary attributes;
                if (session != null)
                {
                    // Get attributes from session
                    attributes = (MultiStringDictionary)session[Constants.USER_INFO];
                }
                else
                {
                    attributes = new MultiStringDictionary();
                    attributes.Add(Constants.SUBJECT, tkt.Name);
                }

                string strRedirect;
                if (request[Constants.RESUME_PATH] != null)
                {

                    strRedirect = Links.hostPF + request[Constants.RESUME_PATH];
                    strRedirect = setOpenToken(context, strRedirect, attributes);
                    response.Redirect(strRedirect, true);

                }
            }
            else
            {
                string strRedirect;
                strRedirect = "default.aspx?cmd=accountlinklogin";
                if (request[Constants.RESUME_PATH] != null)
                {
                    //strRedirect += "&ReturnUrl=" + Links.hostPF + request[Constants.RESUME_PATH];
                    String returnUrl = request.ApplicationPath + "/?cmd=accountlink&" + Constants.RESUME_PATH + "=" + request[Constants.RESUME_PATH];
                    strRedirect += "&ReturnUrl=" + HttpUtility.UrlEncode(returnUrl);
                }
                response.Redirect(strRedirect, true);
            }
        }

        private void HandleLogoutRequest(HttpContext context, HttpRequest request, HttpResponse response, HttpSessionState session)
        {
            if (request.Cookies[FormsAuthentication.FormsCookieName] != null)
            {
                //session.Clear();
                FormsAuthentication.SignOut();
                string strRedirect;
                strRedirect = "default.aspx?error=Successfully logged out";
                response.Redirect(strRedirect, true);
            }
        }

        /// <summary>
        /// setOpenToken method uses the .NET Integration Kit API to create an 
        /// instance of Agent. The user attributes are added to this agent and 
        /// then the OpenToken is created as a cookie or query parameter
        /// </summary>
        /// <param name="context">current HttpContext</param>
        /// <param name="url">url to append OpenToken</param>
        /// <param name="userInfo">MultiStringDictionary of user attributes</param>
        /// <returns>URL with OpenToken</returns>
        private String setOpenToken(HttpContext context, String url, MultiStringDictionary userInfo)
        {
            String returnUrl = url;

            HttpRequest request = context.Request;
            HttpResponse response = context.Response;
            HttpSessionState session = context.Session;

            //read properties from SP agent properties file
            String propsPath = configPath + Constants.PFAGENT_PROPERTIES;

            // Create OpenToken Idp Agent
            Agent agent = new Agent(propsPath);

            UrlHelper urlHelper = new UrlHelper(url);
            agent.WriteToken(userInfo, response, urlHelper, false);

            return urlHelper.ToString();
        }

        private MultiStringDictionary getOpenToken(HttpContext context)
        {
            HttpRequest request = context.Request;
            HttpResponse response = context.Response;
            HttpSessionState session = context.Session;

            String propsPath = configPath + Constants.PFAGENT_PROPERTIES;
            MultiStringDictionary attributes = null;

            // Create OpenToken Agent
            Agent agent = new Agent(propsPath);
            try
            {
                attributes = (MultiStringDictionary)agent.ReadTokenMultiStringDictionary(request);
            }
            catch (TokenException e)
            {
                agent.DeleteToken(response);
                string strRedirect;
                strRedirect = "default.aspx?error=" + e.Message;
                response.Redirect(strRedirect, true);
            }
            catch (TokenExpiredException e)
            {
                agent.DeleteToken(response);
                string strRedirect;
                strRedirect = "default.aspx?error=" + e.Message;
                response.Redirect(strRedirect, true);
            }
            return attributes;
        }

    }
}