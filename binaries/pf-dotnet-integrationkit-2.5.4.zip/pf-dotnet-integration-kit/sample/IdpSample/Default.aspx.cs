/*******************************************************************************
* Copyright (C) 2008 Ping Identity Corporation All rights reserved.
*
* This software is licensed under the Open Software License v2.1 (OSL v2.1).
*
* A copy of this license has been provided with the distribution of this
* software. Additionally, a copy of this license is available at:
* http://opensource.org/licenses/osl-2.1.php
*
******************************************************************************
*/
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Com.PingIdentity.PingFederate.SampleApp.SampleAppUtility;

using opentoken;
using opentoken.util;


public partial class _Default : System.Web.UI.Page
{
    protected String idpStartSLO = "";
    protected bool showAdvanced = false;
    protected bool sessionExists = false;
    public Links samlLinks;
    protected String usersFilePath = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        //prevent the output of aspx page from being cached by the browser
        Response.AddHeader("Cache-Control", "no-cache");
        Response.AddHeader("Pragma", "no-cache");

        //get properties from Idp config file
        String idpConfig = ConfigurationManager.AppSettings["config-file"];
        String configPath = Context.Server.MapPath("config/" + idpConfig);

        //read properties from Idp users XML file
        String idpUsers = ConfigurationManager.AppSettings["users-props-file"];
        usersFilePath = Context.Server.MapPath("config/" + idpUsers);
        samlLinks = new Links(Context, configPath);

        idpStartSLO = samlLinks.getIdpSLOLink();

        if (Request["showAdvanced"] != null)
        {
            if (Request["showAdvanced"].Equals("true"))
            {
                showAdvanced = true;
            }
            else
            {
                showAdvanced = false;
            }
        }

        if (Request.Cookies[FormsAuthentication.FormsCookieName] != null)
        {
            string cookiestr;
            cookiestr = Request.Cookies[FormsAuthentication.FormsCookieName].Value;
            FormsAuthenticationTicket tkt = FormsAuthentication.Decrypt(cookiestr);
            // Check to see if user has the required role
            Context.Session.Add("FORMAUTHTICKET", tkt);
            sessionExists = true;

        }

        if (!IsPostBack)
        {


            PopulateUserList();

        }
        else
        {
            XmlUtility xmlUtility = new XmlUtility();
            MultiStringDictionary userInfo = xmlUtility.AuthenticateUser(userName.Value, password.Value, usersFilePath);
            if (userInfo != null)
            {
                Session.Add(Constants.USER_INFO, userInfo);
                FormsAuthenticationTicket tkt;
                string cookiestr;
                HttpCookie ck;
                tkt = new FormsAuthenticationTicket(1, userName.Value, DateTime.Now,
                    DateTime.Now.AddMinutes(30), false, "your custom data");
                cookiestr = FormsAuthentication.Encrypt(tkt);
                ck = new HttpCookie(FormsAuthentication.FormsCookieName, cookiestr);
                ck.Path = FormsAuthentication.FormsCookiePath;
                Response.Cookies.Add(ck);
                Context.Session.Add("FORMAUTHTICKET", tkt);
                sessionExists = true;

                string strRedirect;
                strRedirect = HttpUtility.UrlDecode(Request["ReturnUrl"]);
                if (strRedirect != null)
                {
                    Response.StatusCode = 301;
                    Response.StatusDescription = "Moved Permanently";
                    Response.RedirectLocation = strRedirect;
                    Response.Flush();
                    //Response.Redirect(strRedirect, true);
                }
                //strRedirect = Request.ApplicationPath + "/default.aspx";

            }
            else
                Response.Redirect("default.aspx?cmd=login&error=Authentication failed&ReturnUrl=" + Request["ReturnUrl"], true);
        }
    }

    private void PopulateUserList()
    {
        XmlUtility xmlUtility = new XmlUtility();
        ArrayList usersList = xmlUtility.GetPropsFromXmlFile(usersFilePath);
        if (usersList == null || usersList.Count == 0)
        {
            String errorMessage = "Error in " + usersList;
            Context.Response.Redirect(Constants.WEB_PREFIX + Constants.ERROR_PAGE + errorMessage);
        }
        else
        {
            for (int i = 0; i < usersList.Count; i++)
            {
                Hashtable user = (Hashtable)usersList[i];
                String subject = (String)user[Constants.USER_ID];
                userName.Items.Add(subject);
            }
        }
    }

    public String PrintUserAttributes()
    {
        return samlLinks.WriteHtmlUserAttributes(Request, (MultiStringDictionary)Session[Constants.USER_INFO]);
    }

}
