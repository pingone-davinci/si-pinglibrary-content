//
//  pingid.c
//  pingid_fc
//
//  Created by Asaf David on 1/6/15.
//  Copyright (c) 2015 Ping Identity. All rights reserved.
//

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>
#include <fcntl.h>
#include <grp.h>
#include <limits.h>
#include <pwd.h>
#include <libgen.h>
#include <time.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/wait.h>

#include <arpa/inet.h>
#include <openssl/hmac.h>
#include <openssl/engine.h>
#include "cJSON.h"
#include "base64.h"
#include "util.h"
#include "http.h"
#include "pingid.h"
#include "config.h"

#define REST_PATH "agentauth"
#define SP_ALIAS_SSH "ssh"

#define PARAM_USER_NAME "username"
#define PARAM_DATA "data"
#define PARAM_SP_ALIAS "spAlias"
#define PARAM_SESSION_ID "sessionId"
#define PARAM_AGENT_AUTH_STATUS "agentAuthStatus"
#define PARAM_MESSAGE "message"

#define PARAM_CONFIG "config"
#define PARAM_PARAMS "params"
#define CONFIG_PARAM_DOMAIN_POSTFIX "DOMAIN_POSTFIX"
#define CONFIG_PARAM_POLICY_USER_NOT_REGISTERED "POLICY_USER_NOT_REGISTERED"
#define PARAM_CLIENT_IP "CLIENT_IP"
#define POLICY_VALUE_USER_NOT_REGISTERED_FAIL "fail"
#define POLICY_VALUE_USER_NOT_REGISTERED_ALLOW "allow"
#define POLICY_VALUE_USER_NOT_REGISTERED_GRACE "grace_fail"
#define POLICY_VALUE_USER_NOT_REGISTERED_REGISTER "register"

#define RESPONSE_STATUS_SUCCESS "SUCCESS"
#define RESPONSE_STATUS_REJECT "REJECT"
#define RESPONSE_STATUS_MORE_INFO "MORE_INFO"

static BOOL checkPropertyExists(char * name, unsigned char value[])
{
    if (StrEmptyOrNull(value))
    {
        pingidLog(__MARK__, "Missing value for mandatory parameter: %s", name);
        return FALSE;
    }
    
    return TRUE;
}

int readPropertiesFile(char *fileName, Properties *props)
{
    FILE *f = fopen(fileName, "r");
    char line[1024];
    int rc = READ_PROPERTIES_FILE_OK;
    static int depth = 0;
    char propertiesFileName[1024] = "";
    
    /*
     protect against stack overflow
     */
    if (++depth > 2) {
        pingidLog(__MARK__, "Only one '%s' parameter can be specified", PINGID_PARAM_PROPS_FILE);
        return READ_PROPERTIES_FILE_INTERNAL_ERROR;
    }
    
    /*
     zero the data on first time only
     */
    if (depth == 1) {
        memset(props, 0, sizeof(Properties));
    }
    
    if (f == NULL)
    {
        pingidLog(__MARK__, "Failed to open file '%s' (%d - %s)", fileName, errno, strerror(errno));
        return READ_PROPERTIES_FILE_FAILED;
    }
    
    while (fgets(line, sizeof(line), f)) {
        char *sep, *value;
        
        trim(line);
        
        if (line[0] == '#' || line[0] == '\n')
        {
            continue;
        }
        
        sep = strchr(line, '=');
        if (sep == NULL) {
            pingidLog(__MARK__, "Ignoring properties line '%s'. All lines must be in key=value format", line);
            continue;
        }
        
        *sep = 0;
        value = sep + 1;
        
        trim(line);
        trim(value);
        
        if (strequal(line, PINGID_PARAM_USE_BASE64_KEY))
        {
            strncpy((char *)props->key, value, sizeof(props->key));
        } else if (strequal(line, PINGID_PARAM_USE_SIGNATURE)) {
            props->useSignature = strequal(value, "true") || strequal(value, "1");
        } else if (strequal(line, PINGID_PARAM_VERBOSE)) {
            props->verbose = strequal(value, "true") || strequal(value, "1");
        } else if (strequal(line, PINGID_PARAM_TOKEN)) {
            strncpy((char *)props->token, value, sizeof(props->token));
        } else if (strequal(line, PINGID_PARAM_IDP_URL)) {
            strncpy((char *)props->idpUrl, value, sizeof(props->idpUrl));
        } else if (strequal(line, PINGID_PARAM_ORG_ALIAS)) {
            strncpy((char *)props->orgAlias, value, sizeof(props->orgAlias));
        } else if (strequal(line, PINGID_PARAM_LOG_FILE)) {
            strncpy((char *)props->logfile, value, sizeof(props->logfile));
        } else if (strequal(line, PINGID_PARAM_POLICY_USER_NOT_REGISTERED)) {
            strncpy((char *)props->policyUserNotRegistered, value, sizeof(props->policyUserNotRegistered));
        } else if (strequal(line, PINGID_PARAM_HTTP_PROXY)) {
            strncpy((char *)props->httpProxy, value, sizeof(props->httpProxy));
        } else if (strequal(line, PINGID_PARAM_DOMAIN_POSTFIX)) {
            strncpy((char *)props->domainPostfix, value, sizeof(props->domainPostfix));
        } else if (strequal(line, PINGID_PARAM_MAX_PROMPTS)) {
            props->maxPrompts = atoi(value);
        } else if (strequal(line, PINGID_PARAM_FAIL_MODE)) {
            strncpy((char *)props->failMode, value, sizeof(props->failMode));
        } else if (strequal(line, PINGID_PARAM_PROPS_FILE)) {
            strncpy(propertiesFileName, value, sizeof(propertiesFileName));
        }
    }
    
    if (!feof(f))
    {
        pingidLog(__MARK__, "Failed to read line from file '%s' (%d - %s)", fileName, errno, strerror(errno));
        return READ_PROPERTIES_FILE_FAILED;
    }

    if (depth == 1) {
        if (StrEmptyOrNull(propertiesFileName)) {
            // dirname() may modify the contents of the path variable, so it
            // may be desirable to pass a copy when calling one of these functions.
            char *fileNameTmp = strdup(fileName);
            snprintf(propertiesFileName, sizeof(propertiesFileName), "%s/pingid.properties", dirname(fileNameTmp));
            free(fileNameTmp);
        }
        
        rc = readPropertiesFile(propertiesFileName, props);
        if (rc == READ_PROPERTIES_FILE_OK)
        {
            if (!checkPropertyExists(PINGID_PARAM_TOKEN, props->token)) rc = READ_PROPERTIES_FILE_FAILED;
            if (!checkPropertyExists(PINGID_PARAM_USE_BASE64_KEY, props->key)) rc = READ_PROPERTIES_FILE_FAILED;
            if (!checkPropertyExists(PINGID_PARAM_IDP_URL, props->idpUrl)) rc = READ_PROPERTIES_FILE_FAILED;
            if (!checkPropertyExists(PINGID_PARAM_ORG_ALIAS, props->orgAlias)) rc = READ_PROPERTIES_FILE_FAILED;
        }
    }
    
    if (rc != READ_PROPERTIES_FILE_OK)
    {
        pingidLog(__MARK__, "Check file: %s", fileName);
    }
    
    if (props->maxPrompts > DEFAULT_MAX_PROMPTS)
    {
        pingidLog(__MARK__, "Max prompts will be set to %d", DEFAULT_MAX_PROMPTS);
        props->maxPrompts = DEFAULT_MAX_PROMPTS;
    }
    
    if (StrEmptyOrNull(props->failMode))
    {
        pingidLog(__MARK__, "Setting %s=%s", PINGID_PARAM_FAIL_MODE, PINGID_RESTRICTIVE);
        strncpy((char *)props->failMode, PINGID_RESTRICTIVE, sizeof(props->failMode));
        
    }
    
    return rc;
}

static unsigned char *calculateHmacSHA1(unsigned char *data, unsigned char *key_base64, unsigned char *buffer, int buffsize)
{
    unsigned char tmp_digest[1000];
    size_t out_len;
#if OPENSSL_VERSION_NUMBER >= 0x1010000fL
    HMAC_CTX *c;
#else
    HMAC_CTX c;
#endif
    
    unsigned char *decoded_key = base64_decode(key_base64, strlen((const char *)key_base64), &out_len);
    
    ENGINE_load_builtin_engines();
    ENGINE_register_all_complete();
    
#if OPENSSL_VERSION_NUMBER >= 0x1010000fL
    c = HMAC_CTX_new();
    HMAC_Init_ex(c, decoded_key, (int)out_len, EVP_sha1(), NULL);
    HMAC_Update(c, data, (unsigned int)strlen((const char *)data));
    HMAC_Final(c, tmp_digest, (unsigned int *)&out_len);
#else
    HMAC_CTX_init(&c);
    HMAC_Init_ex(&c, decoded_key, (int)out_len, EVP_sha1(), NULL);
    HMAC_Update(&c, data, (unsigned int)strlen((const char *)data));
    HMAC_Final(&c, tmp_digest, (unsigned int *)&out_len);
#endif
    
    unsigned char *digest_base64 = base64_encode(tmp_digest, out_len, &out_len);
    
    if (buffsize < out_len)
    {
        //err
        return (unsigned char *)"";
    }
    
    strncpy((char *)buffer, (const char *)digest_base64, buffsize - 1);
    
    strremove((char *)buffer, '\n');
    
    free(decoded_key);
    free(digest_base64);
    
#if OPENSSL_VERSION_NUMBER >= 0x1010000fL
    HMAC_CTX_free(c);
#else
    HMAC_CTX_cleanup(&c);
#endif
    
    return buffer;
}

static cJSON *buildRequestJson(Properties *props, cJSON *body)
{
    char timestamp[25];
    cJSON *root = cJSON_CreateObject();
    cJSON *header = cJSON_CreateObject();
    
    cJSON_AddItemToObject(root, "reqBody", body);
    cJSON_AddItemToObject(root, "reqHeader", header);
    
    cJSON_AddStringToObject(header, "orgAlias", (const char *)props->orgAlias);
    cJSON_AddStringToObject(header, "secretKey", (const char *)props->token);
    cJSON_AddStringToObject(header, "version", API_VERSION);
    cJSON_AddStringToObject(header, "timestamp", getCurrTimeStr(timestamp, sizeof(timestamp)-1));
    cJSON_AddStringToObject(header, "clientVersion", "ssh-" PACKAGE_VERSION);
    
    return root;
}

static char *getUrl(char *appUrl, const char *service, char buffer[], int buffsize)
{
    snprintf(buffer, buffsize, "%s/rest/%s/%s/do", appUrl, REST_VERSION, service);
    strremove(buffer, '\\'); // sometimes the properties file contains urls with '\' (backslash) to escape the ':' (colon)
    return buffer;
}

BOOL extractResponseData(cJSON *jsonResponse, char *sessionId, char *responseStatus, char *responseMessage, BOOL verbose)
{
    cJSON *jsonResponseBody = NULL;
    cJSON *jsonObj = NULL;
    
    if (!jsonResponse)
    {
        pingidLog(__MARK__, "Failed to extract response data. jsonResponse is NULL");
        return FALSE;
    }
    
    if (verbose)
    {
        pingidLog(__MARK__, "response='%s'", cJSON_Print(jsonResponse));
    }

    jsonResponseBody = cJSON_GetObjectItem(jsonResponse, "responseBody");

    if (!jsonResponseBody)
    {
        pingidLog(__MARK__, "Failed to extract response data. jsonResponseBody is NULL");
        return FALSE;
    }

    jsonObj = cJSON_GetObjectItem(jsonResponseBody, PARAM_SESSION_ID);
    if (jsonObj && jsonObj->valuestring)
    {
        strncpy(sessionId, jsonObj->valuestring, SESSION_ID_MAX_LEN);
        if (verbose)
        {
            pingidLog(__MARK__, "sessionId='%s'", sessionId);
        }
    }
    
    jsonObj = cJSON_GetObjectItem(jsonResponseBody, PARAM_AGENT_AUTH_STATUS);
    if (jsonObj && jsonObj->valuestring)
    {
        strncpy(responseStatus, jsonObj->valuestring, STATUS_RESPONSE_MAX_LEN);
        if (verbose)
        {
            pingidLog(__MARK__, "responseStatus='%s'", responseStatus);
        }
    }
    
    jsonObj = cJSON_GetObjectItem(jsonResponseBody, PARAM_MESSAGE);
    if (jsonObj && jsonObj->valuestring)
    {
        strncpy(responseMessage, jsonObj->valuestring, MESSAGE_MAX_LEN);
        if (verbose)
        {
            pingidLog(__MARK__, "responseMessage='%s'", responseMessage);
        }
    }
    
    cJSON_Delete(jsonResponse);
    
    return TRUE;
}

BOOL onlyOnce()
{
    static BOOL first = TRUE;
    
    if (first)
    {
        first = FALSE;
        return TRUE;
    }
    
    return FALSE;
}

int authAgent(Properties *props, const char *username, conversationCallback_t conversationCallback, void *conversationData)
{
    char url[1024];
    unsigned char signature[256];
    char buffer[1024];
    char responseBuffer[4096] = "";
    size_t base64HeaderSize;
    unsigned char *base64Header = NULL;
    char *requestHeaderStr, *fullRequestStr;
    char requestData[DATA_MAX_LEN + 1] = "";
    char sessionId[SESSION_ID_MAX_LEN + 1] = "";
    char responseStatus[STATUS_RESPONSE_MAX_LEN + 1] = "";
    char responseMessage[MESSAGE_MAX_LEN + 1] = "";
    cJSON *jsonRequestBody = NULL;
    cJSON *jsonRequestConfigParams = NULL;
    cJSON *jsonRequestParams = NULL;
    cJSON *jsonRequest = NULL;
    char *clientIP = NULL;
    int rc;
    int iterations = 0;
    
    if (!onlyOnce())
    {
        pingidLog(__MARK__, "Second call always fails");
        return -1;
    }

    conversationCallback("Authenticating using PingID...\n", conversationData, NULL, 0, FALSE);
    
    pingidLog(__MARK__, "Authenticating user '%s'", username);

    getUrl((char *)props->idpUrl, REST_PATH, url, sizeof(url));
    
    do {
        responseStatus[0] = 0;
        responseMessage[0] = 0;

        jsonRequestBody = cJSON_CreateObject();
        jsonRequestConfigParams = cJSON_CreateObject();
        jsonRequestParams = cJSON_CreateObject();
        jsonRequest = NULL;
        
        if (iterations++ >= props->maxPrompts)
        {
            pingidLog(__MARK__, "Exceeded maximum number of prompts (%d)", props->maxPrompts);
            conversationCallback("Exceeded maximum number of prompts\n", conversationData, NULL, 0, FALSE);
            break;
        }
        
        cJSON_AddStringToObject(jsonRequestBody, PARAM_USER_NAME, username);
        cJSON_AddStringToObject(jsonRequestBody, PARAM_SP_ALIAS, SP_ALIAS_SSH);
        
        if (!StrEmptyOrNull(requestData))
        {
            cJSON_AddStringToObject(jsonRequestBody, PARAM_DATA, requestData);
        } else if (strequal(responseStatus, RESPONSE_STATUS_MORE_INFO)) {
            pingidLog(__MARK__, "no user input!");
            break;
        }
        
        if (!StrEmptyOrNull(sessionId))
        {
            cJSON_AddStringToObject(jsonRequestBody, PARAM_SESSION_ID, sessionId);
        }
        
        cJSON_AddItemToObject(jsonRequestBody, PARAM_CONFIG, jsonRequestConfigParams);
        cJSON_AddStringToObject(jsonRequestConfigParams, CONFIG_PARAM_POLICY_USER_NOT_REGISTERED, (char *)props->policyUserNotRegistered);

        if (!StrEmptyOrNull(props->domainPostfix))
        {
            cJSON_AddStringToObject(jsonRequestConfigParams, CONFIG_PARAM_DOMAIN_POSTFIX, (char *)props->domainPostfix);
        }
        
        cJSON_AddItemToObject(jsonRequestBody, PARAM_PARAMS, jsonRequestParams);
        
        clientIP = getClientIP();
        if (clientIP)
        {
            cJSON_AddStringToObject(jsonRequestParams, PARAM_CLIENT_IP, clientIP);
        }

        jsonRequest = buildRequestJson(props, jsonRequestBody);
        fullRequestStr = cJSON_PrintUnformatted(jsonRequest);
        
        requestHeaderStr = cJSON_PrintUnformatted(cJSON_GetObjectItem(jsonRequest, "reqHeader"));
        calculateHmacSHA1((unsigned char *)fullRequestStr, props->key, signature, sizeof(signature));
        snprintf(buffer, sizeof(buffer), "%s###%s", requestHeaderStr, signature);
        base64Header = base64_encode_url((unsigned char *)buffer, strlen(buffer), &base64HeaderSize);
        rc = sendUrl(url, fullRequestStr, (char *)base64Header, props->verbose, 65, responseBuffer, sizeof(responseBuffer) - 1, (char *)props->httpProxy);
        if (base64Header != NULL)
        {
            free(base64Header);
        }

        if (rc != 0)
        {
            pingidLog(__MARK__, "Failed to send request URL to server");
            if (strequal((const char *)props->failMode, PINGID_PERMISSIVE))
            {
                pingidLog(__MARK__, "PingID authentication failed but fail mode is 'permissive'. Access allowed.");
                conversationCallback("PingID authentication completed successfully\n", conversationData, NULL, 0, FALSE);
                return 0;
            }
            break;
        }
        
        if (extractResponseData(cJSON_Parse(responseBuffer), sessionId, responseStatus, responseMessage, props->verbose))
        {
            if (!strequal(responseStatus, RESPONSE_STATUS_SUCCESS))
            {
                requestData[0] = 0;

                conversationCallback(responseMessage, conversationData, requestData, DATA_MAX_LEN, !strequal(responseStatus, RESPONSE_STATUS_REJECT));
                if (props->verbose && !StrEmptyOrNull(requestData))
                {
                    pingidLog(__MARK__, "user input='%s'", requestData);
                }
            }
        }
        
    } while (strequal(responseStatus, RESPONSE_STATUS_MORE_INFO));
    
    if (strequal(responseStatus, RESPONSE_STATUS_SUCCESS))
    {
        pingidLog(__MARK__, "Successfully authenticated user '%s'", username);
        conversationCallback("PingID authentication completed successfully\n", conversationData, NULL, 0, FALSE);
        return 0;
    }
    
    pingidLog(__MARK__, "Failed to authenticate user '%s' (msg: '%s')", username, (StrEmptyOrNull(responseMessage) ? "N/A" : responseMessage));
    conversationCallback("PingID authentication failed\n", conversationData, NULL, 0, FALSE);

    return -1;
}
