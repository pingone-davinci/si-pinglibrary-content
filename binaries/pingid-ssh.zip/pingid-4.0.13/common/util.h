//
//  util.h
//  pingid_fc
//
//  Created by Asaf David on 12/30/14.
//  Copyright (c) 2014 Ping Identity. All rights reserved.
//

#ifndef __pingid_fc__util__
#define __pingid_fc__util__

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define __MARK__ __FILE__,__LINE__

typedef char BOOL;
#define TRUE 1
#define FALSE 0

#ifndef MIN
#define MIN(x,y) (x>y?y:x)
#endif

#define StrEmptyOrNull(s) (s == 0 || s[0] == 0)

void strreplace(char *s, char c1, char c2);
void strremove(char *s, char c);
char *trim(char *s);
BOOL strequal(const char *s1, const char *s2);

void setLogFileName(const char *filename);
FILE *getLogFile();

void pingidLog (const char *file,
                int         line,
                const char *fmt, ...);

char *getCurrTimeStr(char *buffer, int bufferLen);

char *getClientIP();

#endif /* defined(__pingid_fc__util__) */
