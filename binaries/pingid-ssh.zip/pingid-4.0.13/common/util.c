//
//  util.c
//  pingid_fc
//
//  Created by Asaf David on 12/30/14.
//  Copyright (c) 2014 Ping Identity. All rights reserved.
//

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <ctype.h>
#include <syslog.h>
#include <unistd.h>
#include "util.h"

#ifndef LOG_AUTHPRIV
#define LOG_AUTHPRIV LOG_AUTH
#endif

void strreplace(char *s, char c1, char c2)
{
    while (*s != 0)
    {
        if (*s == c1)
        {
            *s = c2;
        }
        s++;
    }
}

void strremove(char *s, char c)
{
    char *s2 = s;
    while (*s2 != 0)
    {
        if (*s2 == c)
        {
            s2++;
            continue;
        }
        
        *s = *s2;
        s++;
        s2++;
    }
    
    if (*s != 0) {
        *s = 0;
    }
}

char *trim(char *s)
{
    char *orig = s;
    char *tmp;
    char *end;
    
    // Trim leading spaces
    while(isspace(*s)) s++;
    
    // All spaces?
    if (*s == 0) {
        return s;
    }
    
    tmp = orig;
    while(*s)
    {
        *tmp = *s;
        tmp++;
        s++;
    }
    *tmp=0;
    
    s = orig;

    // Trim trailing space
    end = s + strlen(s) - 1;
    while(end > s && isspace(*end)) end--;
    
    // Write new null terminator
    *(end + 1) = 0;
    
    return s;
}

BOOL strequal(const char *s1, const char *s2)
{
    return strcmp(s1,s2) == 0;
}

#define MAX_LINE_LEN 1024

FILE *pingidLogFile = NULL;

void setLogFileName(const char *filename)
{
    pingidLogFile = fopen(filename, "a");
    if (!pingidLogFile)
    {
        if (isatty(STDOUT_FILENO))
        {
            printf("Failed to open log file '%s' (%d - %s)\n", filename, errno, strerror(errno));
            pingidLogFile = stdout;
        }
    }
}

FILE *getLogFile()
{
    return pingidLogFile != NULL ? pingidLogFile : stdout;
}

void pingidLog (const char *file,
                int         line,
                const char *fmt, ...)
{
    char    msg [MAX_LINE_LEN];
    va_list args;
    char    timeBuffer[64];
    
    va_start(args,fmt);
    vsprintf(msg,fmt,args);
    va_end(args);
    
    if (pingidLogFile != NULL)
    {
        fprintf (pingidLogFile, "%s[%d] %s(%d): %s\n", getCurrTimeStr(timeBuffer, sizeof(timeBuffer) - 1), getpid(), file, line, msg);
        fflush(pingidLogFile);
    } else {
        syslog(LOG_PID | LOG_AUTHPRIV | LOG_DEBUG, "[%d] %s(%d): %s\n", getpid(), file, line, msg);
    }
}

char *getCurrTimeStr(char *buffer, int bufferLen)
{
    struct timeval tv;
    time_t nowtime;
    struct tm *nowtm;
    char tmbuf[64];
    int millis = 0;
    
    gettimeofday(&tv, NULL);
    nowtime = tv.tv_sec;
    nowtm = localtime(&nowtime);
    strftime(tmbuf, sizeof tmbuf, "%Y:%m:%d %H:%M:%S", nowtm);
    millis = (int)tv.tv_usec / 1000;
    snprintf(buffer, bufferLen, "%s.%03d", tmbuf, millis);
    
    return buffer;
}

char *getClientIP()
{
    char *sshClient = getenv("SSH_CLIENT");
    
    if (!sshClient)
    {
        pingidLog(__MARK__, "SSH_CLIENT not defined");
        return NULL;
    }

    pingidLog(__MARK__, "SSH_CLIENT: '%s'", sshClient);
    char *end = strstr(sshClient, " ");
    if (end)
    {
        *end = 0;
    }
    
    return sshClient;
}
