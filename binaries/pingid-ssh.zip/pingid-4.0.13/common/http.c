#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <curl/curl.h>
#include "util.h"

typedef struct _Response
{
    size_t size;
    char *buffer;
} Response;

static void initResponse(Response *response)
{
    memset(response, 0, sizeof(Response));
}

static void freeResponse(Response *response)
{
    if (response->buffer != NULL)
    {
        free(response->buffer);
    }
}

static size_t updateResponseCallback(void *ptr, size_t size, size_t nmemb, void *userdata)
{
    Response *response = (Response *)userdata;
    size_t dataSize = size * nmemb;
    
    if (dataSize == 0)
    {
        return -1;
    }

    if (response->buffer == NULL)
    {
        response->buffer = (char *)malloc(dataSize);
        response->size = dataSize;
        memcpy(response->buffer, ptr, dataSize);
    } else {
        response->buffer = (char *)realloc(response->buffer, dataSize);
        memcpy(response->buffer + response->size, ptr, dataSize);
        response->size += dataSize;
    }

    return dataSize;
}

static struct curl_slist *addHedaers(CURL *curl, const char *key)
{
    struct curl_slist *slist = NULL;
    char buffer[1024];

    snprintf(buffer, sizeof(buffer), "x-accells-request-header: %s", key);

    slist = curl_slist_append(slist, "Content-Type: application/json");
    slist = curl_slist_append(slist, buffer);

    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, slist);
    
    return slist;
}

int debugCallback(CURL *curl,
                  curl_infotype type,
                  char *data,
                  size_t size,
                  void *userptr)
{
    char *str = (char *)malloc(size + 1);
    memcpy(str, data, size);
    str[size] = 0;
    
    pingidLog(__MARK__, "CURL LOG: %s", str);
    return 0;
}

#define SAFE_CURL_CALL(f) rc = f; \
                          if (CURLE_OK != rc) \
                          { \
                              pingidLog(__MARK__, "%s (error code = %d)\n", errorBuffer, rc); \
                              goto cleanUp; \
                          }

/*
options: verbose, timeout
*/
int sendUrl(char *url,const char *data, const char *key, BOOL bVerbose, int timeout, char *reponseBuffer, int reponseBufferLen, const char *httpProxy)
{
    CURL *curl;
    int rc;
    char errorBuffer[CURL_ERROR_SIZE] = "";
    struct curl_slist *headers = NULL;
    long httpCode;
    Response response;
    
    if (bVerbose)
    {
        pingidLog(__MARK__, "sending url: '%s'", url);
        pingidLog(__MARK__, "with data: '%s'", data);
        pingidLog(__MARK__, "with key: '%s'", key);
    }
    
    SAFE_CURL_CALL(curl_global_init(CURL_GLOBAL_ALL));

    curl = curl_easy_init();
    if (curl == NULL)
    {
        pingidLog(__MARK__, "curl_easy_init failed (%d)", errno);
        rc = -1;
        goto cleanUp;
    }

    /* Set an error buffer to get some readable error massages */
    SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, errorBuffer));
    
    SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_STDERR, getLogFile()));

    /* Set our own write function for cURL */
    SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, updateResponseCallback));
    SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response));

    /* set http/s proxy */
    SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_PROXY, httpProxy));
    
    /* Set a user agent */
    SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_USERAGENT, "PingID agent"));

    if (bVerbose)
    {
        SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_VERBOSE, 1));
        SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_DEBUGFUNCTION, debugCallback));
    }

    SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0));
    SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0));

    SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_TIMEOUT, timeout)); /* in secs */

    headers = addHedaers(curl, key);
    
    SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_URL, url));
    
    SAFE_CURL_CALL(curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data));

    initResponse(&response);

    SAFE_CURL_CALL(curl_easy_perform(curl));
    
    memcpy(reponseBuffer, response.buffer, MIN(response.size,reponseBufferLen));

    SAFE_CURL_CALL(curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode));

    if (bVerbose)
    {
        pingidLog(__MARK__, "http status: %d", httpCode);
    }

cleanUp:

    if (headers)
    {
        curl_slist_free_all(headers); 
    }

    freeResponse(&response);

    return rc;
}