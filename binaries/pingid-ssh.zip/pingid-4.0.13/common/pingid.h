//
//  pingid.h
//  pingid_fc
//
//  Created by Asaf David on 1/6/15.
//  Copyright (c) 2015 Ping Identity. All rights reserved.
//

#ifndef pingid_fc_pingid_h
#define pingid_fc_pingid_h

#include "util.h"

//
// this file is only generated after running ./configure:
// from package dir execute: ./configure
//
#include "config.h"

#define REST_VERSION "4"
#define API_VERSION "4.0"

#define PINGID_CONF_FILE PINGID_CONF_DIR "/pingid.conf"

#define PINGID_PARAM_USE_BASE64_KEY "use_base64_key"
#define PINGID_PARAM_USE_SIGNATURE "use_signature"
#define PINGID_PARAM_TOKEN "token"
#define PINGID_PARAM_IDP_URL "idp_url"
#define PINGID_PARAM_ORG_ALIAS "org_alias"
#define PINGID_PARAM_VERBOSE "verbose"
#define PINGID_PARAM_LOG_FILE "log_file"
#define PINGID_PARAM_PROPS_FILE "properties_file"
#define PINGID_PARAM_POLICY_USER_NOT_REGISTERED "policy_user_not_registered"
#define PINGID_PARAM_DOMAIN_POSTFIX "domain_postfix"
#define PINGID_PARAM_MAX_PROMPTS "max_prompts"
#define PINGID_PARAM_HTTP_PROXY "proxy"
#define PINGID_PARAM_FAIL_MODE "fail_mode"

#define PINGID_PERMISSIVE  "permissive"
#define PINGID_RESTRICTIVE "restrictive"

#define READ_PROPERTIES_FILE_OK 0
#define READ_PROPERTIES_FILE_FAILED -1
#define READ_PROPERTIES_FILE_INTERNAL_ERROR -2

#define SESSION_ID_MAX_LEN 1024
#define MESSAGE_MAX_LEN 4096
#define STATUS_RESPONSE_MAX_LEN 15
#define DATA_MAX_LEN 4096
#define DEFAULT_MAX_PROMPTS 10

typedef struct _Properties {
    unsigned char key[1024];
    BOOL useSignature;
    unsigned char token[1024];
    unsigned char idpUrl[1024];
    unsigned char orgAlias[1024];
    unsigned char logfile[1024];
    unsigned char domainPostfix[1024];
    unsigned char policyUserNotRegistered[64];
    unsigned char httpProxy[256];
    unsigned char failMode[256];
    BOOL verbose;
    int maxPrompts;
} Properties;

typedef char *(*conversationCallback_t)(char *in, void *data, char *out, int outLen, BOOL shouldGetResponse);

int readPropertiesFile(char *fileName, Properties *props);
int authAgent(Properties *props, const char *username, conversationCallback_t conversationCallback, void *conversationData);
#endif
