//
//  http.h
//  pingid_fc
//
//  Created by Asaf David on 1/5/15.
//  Copyright (c) 2015 Ping Identity. All rights reserved.
//

#ifndef pingid_fc_http_h
#define pingid_fc_http_h

int sendUrl(char *url,const char *data, const char *key, BOOL bVerbose, int timeout, char *reponseBuffer, int reponseBufferLen, const char *httpProxy);

#endif
