//
//  pingid_fc.c
//
//  Created by Asaf David on 12/28/14.
//  Copyright (c) 2014 Ping Identity. All rights reserved.
//

#include <stdio.h>
#include <unistd.h>

#include <sys/param.h>
#include <sys/stat.h>
#include <sys/wait.h>

#include <errno.h>
#include <ctype.h>
#include <fcntl.h>
#include <pwd.h>
#include "common/util.h"
#include "common/pingid.h"

char *conversationCallback(char *in, void *data, char *out, int outLen, BOOL shouldGetResponse)
{
    if (!isatty(STDOUT_FILENO))
    {
        pingidLog(__MARK__, "No TTY!");
        return NULL;
    }

    fprintf(stdout, "%s", in);
    fflush(stdout);

    if (out == NULL)
    {
        return NULL;
    }
    
    out[0] = 0;
    if (shouldGetResponse)
    {
        fgets (out, outLen + 1, stdin);
        strremove(out,'\n');
    }
    return out;
}

void invokeShell(struct passwd *userInfo)
{
    const char *shell;
    char arg[256];
    char *origCommand = getenv("SSH_ORIGINAL_COMMAND");
    
    if (StrEmptyOrNull(userInfo->pw_shell)) {
        pingidLog(__MARK__, "user has no shell - rejecting authentication");
        puts("user has no shell - rejecting authentication");
        exit(-1);
    }
    
    if ((shell = strrchr(userInfo->pw_shell, '/')) != NULL) {
        shell++;
    } else {
        shell = userInfo->pw_shell;
    }
    
    // drop privileges
    if (setgid(userInfo->pw_gid) < 0)
    {
        pingidLog(__MARK__, "Failed to drop privilegs to group id: %d", userInfo->pw_gid);
        return;
    }

    if (setuid(userInfo->pw_uid) < 0)
    {
        pingidLog(__MARK__, "Failed to drop privilegs to user id: %d", userInfo->pw_uid);
        return;
    }

    if (origCommand != NULL) {
        execl(userInfo->pw_shell, shell, "-c", origCommand, (char *)NULL);
    } else {
        int i = snprintf(arg, sizeof(arg), "-%s", shell);
        if (i == -1 || i >= sizeof(arg)) {
            pingidLog(__MARK__, "%s: Invalid shell (%s)\n", userInfo->pw_shell, shell);
            exit(EXIT_FAILURE);
        }
        execl(userInfo->pw_shell, arg, (char *)NULL);
    }
    
    pingidLog(__MARK__, "%s (%d - %s)\n", userInfo->pw_shell, errno, strerror(errno));
    
    exit(errno);
}

const char *getAuthUser(struct passwd *userInfo, int argc, const char *argv[])
{
    const char *userName = userInfo->pw_name;
    
    if (argc > 2)
    {
        if (strequal(argv[1], "-u"))
        {
            pingidLog(__MARK__, "Authenticating '%s' to login to '%s'", argv[2], userName);
            userName = argv[2];
        }
    }
    
    return userName;
}

int main(int argc, const char *argv[])
{
    Properties props;
    struct passwd *userInfo;
    int rc;
    const char *user;

    if (argc > 1)
    {
        if (strequal(argv[1], "-version") || strequal(argv[1], "-v") || strequal(argv[1], "--version"))
        {
            printf("PingID API version " API_VERSION " (Package version " PACKAGE_VERSION ")\n");
            printf("Configuration file: " PINGID_CONF_FILE "\n");
            exit(0);
        }
    }

    if ((userInfo = getpwuid(getuid())) == NULL){
        printf("Invalid user\n");
        exit(EXIT_FAILURE);
    }
    
    if (readPropertiesFile(PINGID_CONF_FILE, &props) == READ_PROPERTIES_FILE_FAILED)
    {
        invokeShell(userInfo);
    }
    
    if (!StrEmptyOrNull(props.logfile))
    {
        setLogFileName((const char *)props.logfile);
    }
    
    user = getAuthUser(userInfo, argc, argv);
    
    if (props.verbose)
    {
        pingidLog(__MARK__, "Starting PingID client (version %s)", VERSION);
    }

    rc = authAgent(&props, user, conversationCallback, NULL);
    if (rc != 0)
    {
        return rc;
    }
    
    invokeShell(userInfo);
    
    return 0;
}
