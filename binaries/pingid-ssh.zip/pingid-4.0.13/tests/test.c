//
//  pingid.c
//  pingid_fc
//
//  Created by Asaf David on 1/6/15.
//  Copyright (c) 2015 Ping Identity. All rights reserved.
//

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "common/cJSON.h"
#include "common/base64.h"
#include "common/util.h"

#define TEST(name, f) {printf("Running test '%s'\n", name); int rc; if ((rc = f) != 0) return rc;}

static int testGetIP()
{
    putenv(strdup("SSH_CLIENT=1.2.3.4 123 45"));
    if (!strequal("1.2.3.4", getClientIP()))
    {
        return -1;
    }
    return 0;
}

int main(int argc, char **argv)
{
    TEST("testGetIP", testGetIP());
    puts("Tests finished successfully");
    return 0;
}


