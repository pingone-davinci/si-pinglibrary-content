#include <sys/param.h>

#include <pwd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "common/pingid.h"

#define PAM_SM_AUTH
#define PAM_SM_ACCOUNT
#define PAM_SM_SESSION
#define PAM_SM_PASSWORD

#ifdef HAVE_SECURITY_PAM_APPL_H
#include <security/pam_appl.h>
#endif
#ifdef HAVE_SECURITY_PAM_MODULES_H
#include <security/pam_modules.h>
#endif
#ifdef HAVE_SECURITY_PAM_EXT_H
#include <security/pam_ext.h>   /* Linux-PAM */
#endif

#ifndef PAM_EXTERN
#define PAM_EXTERN
#endif

static char *getResponse(pam_handle_t *pamh, const char *prompt, const char *user, Properties *props, char *responseBuffer, int responseBufferLen, int msgStyle) {
    struct pam_conv *conv;
    int rc;
    struct pam_message msg;
    const struct pam_message *msgp;
    struct pam_response *resp;
    
    rc = pam_get_item(pamh, PAM_CONV, (const void**) &conv);
    if (rc != PAM_SUCCESS) {
        pingidLog(__MARK__, "pam_get_item failed with RC = '%d' (%s)", rc,  pam_strerror(pamh, rc));
        return NULL;
    }
    
    /* set up the conversation */
    msg.msg_style = msgStyle;
    msg.msg = (char *)prompt;
    msgp = &msg;
    resp = NULL;
    rc = (*conv->conv)(1, &msgp, &resp, conv->appdata_ptr);
    if (resp == NULL)
    {
        if (rc != PAM_SUCCESS)
        {
            pingidLog(__MARK__, "pam_conv failed with RC = '%d' (%s)", rc,  pam_strerror(pamh, rc));
        }
        return NULL;
    }
    
    if (rc == PAM_SUCCESS && msgStyle == PAM_PROMPT_ECHO_ON) {
        strncpy(responseBuffer, resp->resp, responseBufferLen);
    }
    if (resp->resp)
    {
        free(resp->resp);
    }
    free(resp);
    
    return responseBuffer;
}

char *conversationCallback(char *in, void *data, char *out, int outLen, BOOL shouldGetResponse)
{
    return getResponse((pam_handle_t *)data, in, NULL, NULL, out, outLen, shouldGetResponse ? PAM_PROMPT_ECHO_ON : PAM_ERROR_MSG);
}

PAM_EXTERN int
pam_sm_authenticate(pam_handle_t *pamh, int flags,
                    int argc, const char *argv[])
{
    Properties props;

    struct passwd *pwd;
    const char *user;
    int pam_err;
    int rc;
    
    /* identify user */
    if ((pam_err = pam_get_user(pamh, &user, NULL)) != PAM_SUCCESS)
    {
        return (pam_err);
    }
    
    if ((pwd = getpwnam(user)) == NULL)
    {
        return (PAM_USER_UNKNOWN);
    }

    if (readPropertiesFile(PINGID_CONF_FILE, &props) == READ_PROPERTIES_FILE_FAILED)
    {
        return PAM_SUCCESS;
    }
    
    if (!StrEmptyOrNull(props.logfile))
    {
        setLogFileName((const char *)props.logfile);
    }
    
    if (props.verbose)
    {
        pingidLog(__MARK__, "Starting PingID client (version %s)", VERSION);
    }

    rc = authAgent(&props, user, conversationCallback, pamh);
    if (rc != 0)
    {
        return PAM_AUTH_ERR;
    }
    
    return PAM_SUCCESS;
}

PAM_EXTERN int
pam_sm_setcred(pam_handle_t *pamh, int flags,
               int argc, const char *argv[])
{
    
    return (PAM_SUCCESS);
}

PAM_EXTERN int
pam_sm_acct_mgmt(pam_handle_t *pamh, int flags,
                 int argc, const char *argv[])
{
    
    return (PAM_SUCCESS);
}

PAM_EXTERN int
pam_sm_open_session(pam_handle_t *pamh, int flags,
                    int argc, const char *argv[])
{
    
    return (PAM_SUCCESS);
}

PAM_EXTERN int
pam_sm_close_session(pam_handle_t *pamh, int flags,
                     int argc, const char *argv[])
{
    
    return (PAM_SUCCESS);
}

PAM_EXTERN int
pam_sm_chauthtok(pam_handle_t *pamh, int flags,
                 int argc, const char *argv[])
{
    
    return (PAM_SERVICE_ERR);
}

#ifdef PAM_MODULE_ENTRY
PAM_MODULE_ENTRY("pam_pingid");
#endif
