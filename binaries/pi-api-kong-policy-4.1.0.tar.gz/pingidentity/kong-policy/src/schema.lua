-- Copyright 2020 Ping Identity Corporation. All Rights Reserved.
-- Ping Identity reserves all rights in the program as delivered.
-- Unauthorized use, copying, modification, reverse engineering, disassembling,
-- attempt to discover any source code or underlying ideas or algorithms,
-- creating other works from it, and distribution of this program is strictly prohibited.
-- The program or any portion thereof may not be used or reproduced in any form
-- whatsoever except as provided by a license without the written consent of Ping Identity.
-- A license under Ping Identity's rights in the program may be available directly from Ping Identity.

return {
  no_consumer = true, -- this plugin will only be API-wide
  fields = {
    ase_primary_host = {type = "string",  default = "localhost"},
    ase_secondary_host = { type = "string", default = "localhost"},
    ase_port = {type = "string",  default = "8443"},
    ase_token = {type = "string",  default = "1ebd5fde1b0b4373a1ad8b8724d13813"},
    ase_timeout = {type = "string",  default = "5000"},
    ase_keepalive = {type = "string",  default = "60000"},
    use_tls = { type = "boolean", default = true },
    sni_name = { type = "string", default = "test.ase.pi"},
    access_token = { type = "string", default = "access_token"},
    tls_verify = { type = "boolean", default = false }
  },
  self_check = function(schema, plugin_t, dao, is_updating)
    return true
  end
}
