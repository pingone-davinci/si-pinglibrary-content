-- Copyright 2020 Ping Identity Corporation. All Rights Reserved.
-- Ping Identity reserves all rights in the program as delivered.
-- Unauthorized use, copying, modification, reverse engineering, disassembling,
-- attempt to discover any source code or underlying ideas or algorithms,
-- creating other works from it, and distribution of this program is strictly prohibited.
-- The program or any portion thereof may not be used or reproduced in any form
-- whatsoever except as provided by a license without the written consent of Ping Identity.
-- A license under Ping Identity's rights in the program may be available directly from Ping Identity.

local BasePlugin  = require "kong.plugins.base_plugin"
local PingIntelligenceHandler = BasePlugin:extend()
local ase_host
local ase_secondary_host
local ase_port
local ase_timeout
local ase_keepalive
PingIntelligenceHandler.PRIORITY = 100
PingIntelligenceHandler.VERSION  = "1.0.0"
local delay = 0
local handler
local access_tknkey

-- PING Intelligence Constructor
function PingIntelligenceHandler:new()
  PingIntelligenceHandler.super.new(self, "PingIntelligence")
  ngx.log(ngx.INFO, "Started KONG PingIntelligence Plugin")
end

local function isempty(s)
  return s == nil or s == ''
end

function string.sanitize(str)
  return str:gsub('\\', '\\\\'):gsub('"', '\\"')
end


local function split1 (inputstr, sep)
  if sep == nil then
    sep = "%s"
  end
  local t={}
  for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
    table.insert(t, str)
  end
  return t
end

-- Variable is_ase_secondary is either true or false
-- In /ase/response flow, kong sends to either primary or secondary ASE based on context(ctx) setting
local function makeCallToASEAsyncWrapper (premature, msg, config, is_ase_secondary)
  ngx.log(ngx.DEBUG, "Entering makeCallToASEAsyncWrapper().")
  if premature then
    ngx.log(ngx.WARN, "ngx.timer library reported that async handler fired prematurely. This can be ignored.");
  end

  ngx.log(ngx.DEBUG, "calling makeCallToASE().")
  makeCallToASE(msg, config, is_ase_secondary)
end

function makeCallWithRetry(msg, config)
  ngx.log(ngx.DEBUG, "Entering makeCallWithRetry().")
  local success = false
  local ok = -1

  kong.ctx.plugin.is_ase_secondary = false
  ok =  makeCallToASE(msg, config, false)

  if ok == -1 then
    ngx.log(ngx.ERR, "Error connecting to primary ASE... trying secondary ASE");
    kong.ctx.plugin.is_ase_secondary = true
    ok =  makeCallToASE(msg, config, true)
  end

  if ok == -1 then
    ngx.log(ngx.ERR, "Error connecting to secondary ASE... sending the request to backend");
  end

  ngx.log(ngx.DEBUG, ok)
  return ok
end

function makeCallToASE(msg, config, secondary)
  ngx.log(ngx.DEBUG, "Entering makeCallToASE().")
  local ok, err
  local sock = ngx.socket.tcp()
  sock:settimeout(ase_timeout)
  if secondary then
    ase_host = ase_secondary_host
  end
  ok, err = sock:connect(ase_host, ase_port)
  if not ok then
    ngx.log(ngx.ERR, "[tcp-log] failed to connect to " ..ase_host.. ":" .. tostring(ase_port) .. ": ", err)
    return -1
  end

  if config.use_tls then
    ok, err = sock:sslhandshake(true, config.sni_name, config.tls_verify, false)
    if not ok then
      ngx.log(ngx.ERR, "[tcp-log] failed to perform TLS handshake to ",
        ase_host, ":", ase_port, ": ", err)
      return -1
    end
  end

  ngx.log(ngx.DEBUG, "#################Time Stamp###### "..os.time(os.date("!*t")));
  ok, err = sock:send(tostring(msg))
  ngx.log(ngx.DEBUG, "#################Time Stamp###### "..os.time(os.date("!*t")));

  ngx.log(ngx.DEBUG, "Message Sent To ASE: "..msg);

  if not ok then
    ngx.log(ngx.ERR, "[tcp-log] Failed to send data to " .. ase_host .. ":" .. tostring(ase_port) .. ": ", err)
    return -1
  end
  local resHDR =""

  local data, err = sock:receive() -- Read the status line
  if not data then
    ngx.log(ngx.ERR, "[tcp-log] Failed to read the data stream \r\n"..err);
    return -1
  end
  ngx.log(ngx.DEBUG, "Read the data stream: "..data);
  local i = 0
  local version = ""
  local returnCode = ""
  local returnStatus = ""
  for token in string.gmatch(data, "%S+")
  do
    if i == 0 then
      ngx.log(ngx.DEBUG, 'Version: '..token)
      version = token
    end
    if i == 1 then
      ngx.log(ngx.DEBUG, 'returnCode: '..token)
      returnCode = token
    end
    if i == 2 then
      ngx.log(ngx.DEBUG, 'returnStatus: '..token)
      returnStatus = token
    end
    i = i + 1
  end

  local read_headers = sock:receiveuntil("\r\n\r\n") -- Read response header block
  while true do
    local data, err, partial = read_headers(4)

    if not isempty(data) then
      resHDR = resHDR..data
    end
    if not data then
      if err then
        break
      end
      break
    end
  end
  ngx.log(ngx.DEBUG, "Received from ASE Response Headers: "..resHDR);
  local headerArray = split1 (resHDR, "\n")
  local mbdyLength = 0
  i = 1
  while headerArray[i] do
    ngx.log(ngx.DEBUG, "ASE Response Header: "..headerArray[i])
    local headerStringArray = split1 (headerArray[i], ":")
    ngx.log(ngx.DEBUG, "ASE Response Header Name: "..headerStringArray[1])
    ngx.log(ngx.DEBUG, "ASE Response Header Value: "..headerStringArray[2])
    if string.lower(headerStringArray[1]) == "content-length" then
      mbdyLength = tonumber(headerStringArray[2])
    end
    i = i + 1
  end
  if mbdyLength > 0 then
    local mBdy =""
    local line = sock:receive(mbdyLength)
    if line then
      mBdy =mBdy..line
    end
    ngx.log(ngx.DEBUG, "Received from ASE Final Message: "..mBdy);
  end

  --Keeping ASE connection Alive
  ngx.log(ngx.DEBUG, "KEEPING  Socket connection ALIVE for "..ase_keepalive);
  ok, err = sock:setkeepalive(ase_keepalive)
  if not ok then
    ngx.log(ngx.ERR, "[tcp-log] failed to keepalive to " .. ase_host .. ":" .. tostring(ase_port) .. ": ", err)
    return 0 -- Don't return an error because of this.
  end
  return tonumber(returnCode)
end

-- Entry point for ASE requests...
function PingIntelligenceHandler:access(config)
  PingIntelligenceHandler.super.access(self)

  ase_host = config.ase_primary_host
  ase_secondary_host = config.ase_secondary_host
  ase_port = config.ase_port
  ase_timeout = config.ase_timeout
  ase_keepalive = config.ase_keepalive
  access_tknkey = config.access_token

  ngx.log(ngx.DEBUG, "#################################");
  ngx.log(ngx.DEBUG, "Reading Configuration Schema ASE HOST : "..config.ase_primary_host);
  ngx.log(ngx.DEBUG, "Reading Configuration Schema ASE PORT : "..config.ase_port);
  ngx.log(ngx.DEBUG, "Reading Configuration Schema ASE TIMEOUT : "..config.ase_timeout);
  ngx.log(ngx.DEBUG, "Reading Configuration Schema ASE KEEPALIVE : "..config.ase_keepalive);
  ngx.log(ngx.DEBUG, "Reading Configuration Schema ASE Token : "..config.ase_token);
  ngx.log(ngx.DEBUG, "Reading Configuration Schema ASE Token : "..config.access_token);
  ngx.log(ngx.DEBUG, "#################################");

  local aseReqBody
  local aseResBody
  local aseReqHeader
  local postmsg
  local aseToken = "aseToken"
  local Authorization = ""
  kong.ctx.plugin.request_id = ngx.var.request_id
  local correlationId = kong.ctx.plugin.request_id
  ngx.log(ngx.DEBUG, "correlationId: "..correlationId);
  kong.ctx.plugin.returnCode = 200

  --dump query params
  local rawq = kong.request.get_raw_query()
  ngx.log(ngx.DEBUG, "RAW Query : "..rawq);
  if not isempty(rawq) then
    if not isempty(config.access_token) then
      local accessToken =  kong.request.get_query_arg(config.access_token) -- "return Access Token value"
      if accessToken then
        Authorization ="Bearer "..accessToken
      end
    end
  end

  local requestHeaders = kong.request.get_headers()
  ngx.log(ngx.DEBUG, "Dumping Headers: "..table.getn(requestHeaders));

  local hdr = "["

  for key,value in pairs(requestHeaders) do
    hdr= hdr..'{"'..key..'":"'..value:sanitize()..'"},'
  end

  if string.match(hdr, "Authorization") then
    ngx.log(ngx.DEBUG, "Authorization Header already present");
  else

    if not isempty(Authorization) then
      hdr= hdr..'{"Authorization":"'..Authorization..'"},'
    else
      ngx.log(ngx.DEBUG, "Authorization is Nil  ");
    end

  end

  hdr = hdr:sub(1, -2).."]"

  -- local UserAgent = kong.request.get_header("user-agent")
  -- local Host = kong.request.get_header("host")
  local ContentType = "application/json"
  local ContentLength
  local ASETOKEN = "asetoken"
  local XCorrelationID = correlationId
  local source_ip = ngx.var.remote_addr
  local source_port = kong.client.get_port()
  local method=  kong.request.get_method()
  local url = kong.request.get_path()
  local http_version = kong.request.get_http_version()
  local username = kong.request.get_header("X-Credential-Username")
  if not isempty(username) then
    ngx.log(ngx.DEBUG, "Found consumer: "..username)
  end

  aseReqBody = '{'
  if not isempty(source_ip) then
    aseReqBody= aseReqBody..'"source_ip":"'..source_ip..'",'
  end
  if not isempty(source_port) then
    aseReqBody= aseReqBody..'\r\n"source_port":"'..source_port..'",'
  end
  if not isempty(method) then
    aseReqBody= aseReqBody..'\r\n"method":"'..method..'",'
  end
  if not isempty(url) then
    if isempty(rawq) then
      aseReqBody= aseReqBody..'\r\n"url":"'..url..'",'
    else
      aseReqBody= aseReqBody..'\r\n"url":"'..url.."?"..rawq..'",'
    end
  end
  if not isempty(http_version) then
    aseReqBody= aseReqBody..'\r\n"http_version":"'..http_version..'",'
  end

  if not isempty(hdr) then
    aseReqBody= aseReqBody..'\r\n"headers":'..hdr
  end

  if not isempty(username) then
    aseReqBody = aseReqBody..',\r\n"user_info":[{"username":"'..username..'"}]'
  end

  aseReqBody = aseReqBody..'}'

  local ContentLength =#aseReqBody


  aseReqHeader = "POST /ase/request HTTP/1.1\r\nHost:"..ase_host..
    "\r\nConnection: keep-alive\r\n"..
    "X-CorrelationID:"..XCorrelationID..
    "\r\nASE-TOKEN:"..config.ase_token..
    "\r\nContent-Length:"..ContentLength..
    "\r\nContent-Type:application/json"


  postmsg = aseReqHeader.."\r\n\r\n"..aseReqBody

  ngx.log(ngx.DEBUG, "Request Request Message : "..postmsg);

  local ok
  ok = makeCallWithRetry(postmsg, config)

  if ok == 200 then
    ngx.log(ngx.DEBUG, "Successful call to ASE.")
  elseif ok == 403 then
    ngx.log(ngx.ERR, "ASE instructed to block request. Returning 403 to client.")
    kong.ctx.plugin.returnCode = 403
    return kong.response.exit(403, "Access Forbidden", {
      ["Content-Type"] = "text/plain",
    })
  else
    ngx.log(ngx.ERR, "makeCallToASE: An error occured. rc="..ok)
  end

end

--- Entry point for responses
function PingIntelligenceHandler:header_filter(config)
  PingIntelligenceHandler.super.header_filter(self)

  if kong.ctx.plugin.returnCode == 403 then
    ngx.log(ngx.DEBUG, "ASE returned 403 on request message; not sending data for response.")
    return
  end
  local XCorrelationID = kong.ctx.plugin.request_id
  ngx.log(ngx.DEBUG, "correlationId: "..XCorrelationID);

  local aseResBody = ""
  local aseResHeader
  local postmsg
  local aseToken = "aseToken"

  -- dump headers
  local responseHeaders = kong.response.get_headers()
  ngx.log(ngx.DEBUG, "Dumping responseHeaders Headers: "..table.getn(responseHeaders));
  local reshdr = "["
  for key,value in pairs(responseHeaders) do
    reshdr= reshdr..'{"'..key..'":"'..value:sanitize()..'"},'
  end
  reshdr = reshdr:sub(1, -2).."]"

  -- local UserAgent = kong.response.get_header("user-agent")
  -- local Host = kong.response.get_header("host")
  local ContentType = "application/json"
  local ContentLength = kong.response.get_header("Content-Length")
  -- local ase_token = "asetoken"
  local source_ip = ngx.var.remote_addr
  local source_port = kong.client.get_port()
  local url = kong.request.get_path()
  local response_code = kong.response.get_status()
  local http_version = kong.request.get_http_version()
  local Authorization = ""
  local Connection = kong.response.get_header("Connection")


  if not isempty(response_code) then
    aseResBody = aseResBody..'{"response_code":"'..response_code..'",'
    aseResBody = aseResBody..'\r\n"response_status":" ",'
  end

  ngx.log(ngx.DEBUG, "Response Code : "..response_code);
  ngx.log(ngx.DEBUG, "Response Status : "..ngx.status);


  if not isempty(http_version) then
    aseResBody = aseResBody..'\r\n"http_version":"'..http_version..'",'
  end

  if not isempty(reshdr) then
    aseResBody = aseResBody..'\r\n"headers":'..reshdr..'}'
  end

  if kong.ctx.plugin.is_ase_secondary then
    ase_host = config.ase_secondary_host
  else
    ase_host = config.ase_primary_host
  end

  local resContentLength =#aseResBody
  aseResHeader = "POST /ase/response HTTP/1.1"..
    "\r\nHost:"..ase_host..
    "\r\nConnection: keep-alive"..
    "\r\nX-CorrelationID:"..XCorrelationID..
    "\r\nASE-TOKEN:"..config.ase_token..
    "\r\nContent-Length:"..resContentLength..
    "\r\nContent-Type:application/json"

  postmsg = aseResHeader.."\r\n\r\n"..aseResBody
  ngx.log(ngx.DEBUG, "Response Metadata Message "..postmsg);

  local ok, err = ngx.timer.at(0, makeCallToASEAsyncWrapper, postmsg, config, kong.ctx.plugin.is_ase_secondary)

end

return PingIntelligenceHandler
