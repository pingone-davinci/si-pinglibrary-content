class ASEConfig {

  constructor() {
    this.ase_primary = "172.16.40.156";
    this.ase_primary_port = 8000;
    this.ase_secondary = "172.16.40.156";
    this.ase_secondary_port = 8000;
    this.is_ase_ssl = false;
    this.ase_token = "c1b8a771-ab84-4431-a19b-841c9b8341fc";
    this.ase_ca = "4.1.pem";
    this.use_ca = false;
    this.APIPaths = ["/"];

    //configure below parameters for JWT tokens
    this.enable_oauth = false;
    this.is_access_token_in_header = false;
    this.access_token_variable = "access_token";
    this.authorization_header_prefix = "Bearer";
    this.user_key_mapping = "username";
    this.clientid_key_mapping = "client_id";

    // Parameters to be used internally. Don't change values for these variable
    this.corelationheader = "X-CorrelationID";
    this.aseheader = "ASE-Token";

  }

  getAPIPaths() {
    return this.APIPaths;
  }

  getASE(is_primary) {
    if (is_primary)
      return this.ase_primary;
    else
      return this.ase_secondary;
  }
  getASEPort(is_primary) {
    if (is_primary)
      return this.ase_primary_port;
    else
      return this.ase_secondary_port;
  }
  getASESSLStatus() {
    return this.is_ase_ssl;
  }
  getASEToken() {
    return this.ase_token;
  }
  getASECA() {
    return this.ase_ca;
  }
  getASECAStatus() {
    return this.use_ca;
  }
  getCorelationID() {
    return this.corelationheader;
  }
  getASETokenHeader() {
    return this.aseheader;
  }
  getEnableOauth() {
    return this.enable_oauth;
  }
  getIsAccessTokenInHeader() {
    return this.is_access_token_in_header;
  }
  getAccessTokenVariable() {
    return this.access_token_variable;
  }
  getAuthorizationHeaderPrefix() {
    return this.authorization_header_prefix;
  }
  getUserKeyMapping() {
    return this.user_key_mapping;
  }
  getClientIDKeyMapping() {
    return this.clientid_key_mapping;
  }
}

module.exports = ASEConfig;
