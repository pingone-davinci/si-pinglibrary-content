/*
 * Copyright 2020 Ping Identity Corporation.
 *
 * Ping Identity reserves all rights in the program as delivered. Unauthorized use, copying,
 * modification, reverse engineering, disassembling, attempt to discover any source code or
 * underlying ideas or algorithms, creating other works from it, and distribution of this
 * program is strictly prohibited. The program or any portion thereof may not be used or
 * reproduced in any form whatsoever except as provided by a license without the written
 * consent of Ping Identity. A license under Ping Identity's rights in the program may be
 * available directly from Ping Identity.
 */
var https = require("https");
var f5 = require("f5-nodejs");
var ilx = new f5.ILXServer();

var Config = require('./ASEConfig');
var AseRequest = require('./ASERequest');
var AseResponse = require('./ASEResponse');


var urlMap = {};
var minPathValue = 100;
var maxPathValue = 0;
var checkAlltraffic = false;
var ASEConfig = new Config();
ASEConfig["is_primary"] = true;
ASEConfig["is_async"] = false;
createMap(ASEConfig.getAPIPaths());
if (ASEConfig.getAPIPaths().length === 0 || ASEConfig.getAPIPaths().includes("/")) {
  checkAlltraffic = true;
}


function httpRequest(req, res) {
  if (ASEConfig.is_async) {
    res.reply("200");
    alreadyReplied = true;
  }
  var http = null;
  if (ASEConfig.getASESSLStatus()) {
    http = require("https");

  } else {
    http = require("http");

  }
  try {
    var headers = JSON.parse(req.params()[4]);

    if (checkAlltraffic || checkIfPathExists(req.params()[1], urlMap, minPathValue, maxPathValue)) {
      var ASERequest = new AseRequest(req.params()[0], ASEConfig, http, req.params()[1], req.params()[2], req.params()[3], headers, req.params()[5], req.params()[6], res);
      ASERequest.process();
    } else if (!ASEConfig.is_async) {
      res.reply("201");
    }
  } catch (ex) {
    console.log(ex);
    if (!ASEConfig.is_async) {
      res.reply("200");
    }
  }
}

function httpResponse(req, res) {
  var http = null;
  res.reply("200");
  if (ASEConfig.getASESSLStatus()) {
    http = require("https");

  } else {
    http = require("http");

  }
  var headers = JSON.parse(req.params()[2]);
  var ASEResponse = new AseResponse(req.params()[0], ASEConfig, http, req.params()[1], headers);
  ASEResponse.process();

}

function createMap(pathArray) {
  for (tIndex = 0; tIndex < pathArray.length; tIndex++) {
    var key = pathArray[tIndex];
    urlMap[key] = true;
    var numOfSlashes = 0;
    for (index = 0; index < key.length; index++) {
      var character = key.charAt(index);
      if (character == "/") {
        numOfSlashes++;
      }
      if (character == "?") {
        break;
      }
    }
    if (minPathValue > numOfSlashes) {
      minPathValue = numOfSlashes;
    }
    if (maxPathValue < numOfSlashes) {
      maxPathValue = numOfSlashes;
    }
  }
}

/*Check the incoming url exists in the map*/
function checkIfPathExists(incomingPath, pathMap, minPath, maxPath) {
  var pathLength = 0;
  var key = incomingPath;
  var numSlashes = 0;
  var urlWithoutQuery = "";
  for (jIndex = 0; jIndex < key.length; jIndex++) {
    var character = key.charAt(jIndex);
    if (character == "/") {
      numSlashes++;
    }
    if (character == "?") {
      break;
    }
    urlWithoutQuery = urlWithoutQuery + character;
  }
  if (numSlashes < minPath) {
    return false;
  }
  var splitURL = urlWithoutQuery.split("/");
  for (iIndex = minPath; iIndex < splitURL.length; iIndex++) {
    var url = "";
    for (kIndex = 1; kIndex <= iIndex && kIndex <= maxPath; kIndex++) {
      url = url + "/" + splitURL[kIndex];
    }
    if (url in pathMap) {
      return true;
    }
  }
}


ilx.addMethod('httpRequest', httpRequest);
ilx.addMethod('httpResponse', httpResponse);
ilx.listen();
