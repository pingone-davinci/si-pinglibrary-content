/*
 * Copyright 2020 Ping Identity Corporation.
 *
 * Ping Identity reserves all rights in the program as delivered. Unauthorized use, copying,
 * modification, reverse engineering, disassembling, attempt to discover any source code or
 * underlying ideas or algorithms, creating other works from it, and distribution of this
 * program is strictly prohibited. The program or any portion thereof may not be used or
 * reproduced in any form whatsoever except as provided by a license without the written
 * consent of Ping Identity. A license under Ping Identity's rights in the program may be
 * available directly from Ping Identity.
 */
const querystring = require('querystring');
const base64url = require('base64url');
var fs = require('fs');

class ASERequest {
  constructor(correlationID, config, http, url, client_ip, client_port, headers, method, query, res) {
    this.correlationID = correlationID;
    this.aseConfig = config;
    this.client_ip = client_ip;
    this.client_port = client_port;
    this.headers = headers;
    this.method = method;
    this.url = url;
    this.query = query;
    this.token = "";
    this.retry = true; // enable retry
    this.retryCount = 1; // retry count
    this.tryCount = 0;
    this.options = {};
    this.http_or_https = http;
    this.requestMethod = "POST";
    this.requestHeaders = {};
    this.jsonBodyString = "";
    this.success = false;
    this.res = res;

  }
  getUserInfo() {
    var username = null;
    var clientId = null;
    var token = "";
    try {
      if (this.aseConfig.getEnableOauth()) {
        if (this.aseConfig.getIsAccessTokenInHeader()) {
          const authHeader = "authorization";
          var tokenObject = this.headers[authHeader];
          if (typeof tokenObject !== undefined && tokenObject !== undefined && tokenObject !== null) {
            token = tokenObject;
            token.trim();
          } else {
            return {}
          }

          var tokens = token.split(/\s+/);
          if (tokens.length == 2) {
            if (tokens[0] == this.aseConfig.getAuthorizationHeaderPrefix()) {
              token = tokens[1];
            } else {
              return {};
            }
          } else {
            return {};
          }
        } else {
          const params = querystring.parse(this.query);
          token = params[this.aseConfig.getAccessTokenVariable()];
        }
        this.token = token; //store it to reuse while creating ASE request body
        if (token) {
          var tokens1 = token.split('.');
          if (tokens1.length == 3) {
            var decodedValue = JSON.parse(base64url.decode(tokens1[1]));
            username = decodedValue[this.aseConfig.getUserKeyMapping()];
            clientId = decodedValue[this.aseConfig.getClientIDKeyMapping()];
            if (typeof username !== undefined && username === null)
              return {};
            if (typeof clientId !== undefined && clientId === null)
              return {
                username: username.toString()
              };
            return {
              username: username.toString(),
              client_id: clientId.toString()
            };
          }
        }
      }
    } catch (e) {
      console.log("exception: " + e);
      return {};
    }
    return {};
  }

  createRequestBody() {
    var url = this.url;
    var userinfo = this.getUserInfo();

    var headers = this.headers;
    var headersFormattedObject = [];
    if (typeof headers !== undefined && headers !== null && Object.keys(headers).length > 0) {
      for (var key in headers) {
        var tmpObject = {};
        tmpObject[key] = this.headers[key];
        headersFormattedObject.push(tmpObject);
      }
    }
    if (this.aseConfig.getEnableOauth() && typeof this.token != 'undefined' && this.token !== null && this.token !== "") {
      headersFormattedObject = headersFormattedObject.filter(function(obj) {
        return typeof obj.authorization == 'undefined' || obj.authorization === null;
      });
      headersFormattedObject.push({
        "authorization": "Bearer " + this.token
      });
    }
    var messageBody = {
      "source_ip": this.client_ip,
      "source_port": this.client_port,
      "method": this.method,
      "url": url,
      "http_version": "1.1",
      "headers": headersFormattedObject,
      "user_info": [userinfo]
    };
    return messageBody;
  }
  process() {
    this.requestHeaders['Content-Type'] = 'application/json; charset=utf-8';
    this.requestHeaders['Connection'] = 'Close';
    this.requestHeaders[this.aseConfig.getASETokenHeader()] = this.aseConfig.getASEToken();
    this.requestHeaders[this.aseConfig.getCorelationID()] = this.correlationID;
    var requestBody = this.createRequestBody();
    this.jsonBodyString = JSON.stringify(requestBody);
    this.options = {
      hostname: this.aseConfig.getASE(this.aseConfig.is_primary),
      port: this.aseConfig.getASEPort(this.aseConfig.is_primary),
      path: "/ase/request",
      method: this.requestMethod,
      headers: this.requestHeaders,
      agent: this.agent
    };
    // if (this.aseConfig.getASESSLStatus() && !(this.aseConfig.getASECAStatus())) {
    //   process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
    //   this.options.ca = fs.readFileSync(this.aseConfig.getASECA()).toString();
    // }
    if (this.aseConfig.getASESSLStatus()) {
      process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
    }

    this.options.timeout = 5000; // 5000 millisecond timeout
    this.sendRequest();
  }
  sendRequest() {
    var origObject = this;
    var req = this.http_or_https.request(this.options, function(res) {
      var reqStatus = res.statusCode;
      origObject.finish(reqStatus);
      res.resume();
      return;
    });
    req.on('error', function(error) {
      origObject.retrySendRequest();
    });
    req.on('timeout', () => {
      origObject.retrySendRequest();
    });
    req.write(this.jsonBodyString);
    req.end();

  }

  retrySendRequest() {
    if (!this.success) {
      if (this.tryCount < this.retryCount) {
        this.tryCount++;
        this.aseConfig.is_primary = !this.aseConfig.is_primary;
        this.options.hostname = this.aseConfig.getASE(this.aseConfig.is_primary);
        this.options.port = this.aseConfig.getASEPort(this.aseConfig.is_primary);
        this.sendRequest();
      } else {
        this.finish(200);
      }
    }
  }

  finish(status) {
    if (!this.res.alreadyReplied) {
      this.res.reply(status);
      this.res.alreadyReplied = true;
    }
  }

}
module.exports = ASERequest;
