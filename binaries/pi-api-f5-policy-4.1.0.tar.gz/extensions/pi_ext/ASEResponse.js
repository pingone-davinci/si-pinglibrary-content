/*
 * Copyright 2020 Ping Identity Corporation.
 *
 * Ping Identity reserves all rights in the program as delivered. Unauthorized use, copying,
 * modification, reverse engineering, disassembling, attempt to discover any source code or
 * underlying ideas or algorithms, creating other works from it, and distribution of this
 * program is strictly prohibited. The program or any portion thereof may not be used or
 * reproduced in any form whatsoever except as provided by a license without the written
 * consent of Ping Identity. A license under Ping Identity's rights in the program may be
 * available directly from Ping Identity.
 */
var fs = require('fs');

class ASEResponse {
  constructor(correlationID, config, http, response_code, headers) {
    this.correlationID = correlationID;
    this.aseConfig = config;
    this.retry = true; // enable retry
    this.retryCount = 0; // retry count
    this.tryCount = 0;
    this.options = {};
    this.http_or_https = http;
    this.requestMethod = "POST";
    this.requestHeaders = {};
    this.jsonBodyString = "";
    this.success = false;
    this.response_code = response_code;
    this.headers = headers;
  }

  createRequestBody() {
    var headers = this.headers;
    var headersFormattedObject = [];
    var indexCount = 0;
    if (typeof headers !== undefined && headers !== null && Object.keys(headers).length > 0) {
      for (var key in headers) {
        var tmpObject = {};
        tmpObject[key] = this.headers[key];
        headersFormattedObject[indexCount] = tmpObject;
        indexCount += 1;
      }
    }
    var messageBody = {
      "response_code": this.response_code,
      "response_status": "",
      "headers": headersFormattedObject
    };
    return messageBody;
  }

  process() {
    this.requestHeaders['Content-Type'] = 'application/json; charset=utf-8';
    this.requestHeaders['Connection'] = 'Close';
    this.requestHeaders[this.aseConfig.getASETokenHeader()] = this.aseConfig.getASEToken();
    this.requestHeaders[this.aseConfig.getCorelationID()] = this.correlationID;
    var requestBody = this.createRequestBody();
    this.jsonBodyString = JSON.stringify(requestBody);
    this.options = {
      hostname: this.aseConfig.getASE(this.aseConfig.is_primary),
      port: this.aseConfig.getASEPort(this.aseConfig.is_primary),
      path: "/ase/response",
      method: this.requestMethod,
      headers: this.requestHeaders,
      agent: this.agent
    };
    // if (this.aseConfig.getASESSLStatus() && !(this.aseConfig.getASECAStatus())) {
    //   process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
    //   this.options.ca = fs.readFileSync(this.aseConfig.getASECA()).toString();
    // }
    if (this.aseConfig.getASESSLStatus()) {
      process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
    }
    this.options.timeout = 1000; // 5000 millisecond timeout
    this.sendRequest();
  }
  sendRequest() {
    var origObject = this;
    var req = this.http_or_https.request(this.options, function(res) {
      origObject.finish()
      res.resume();
    });
    req.on('error', function(error) {
      origObject.retrySendRequest();
    });
    req.on('timeout', () => {
      origObject.retrySendRequest();
    });
    req.write(this.jsonBodyString);
    req.end();

  }
  retrySendRequest() {
    if (!this.success) {
      if (this.tryCount < this.retryCount) {
        this.tryCount++;
        this.sendRequest();
      } else {
        this.finish();
      }
    }
  }
  finish() {
    this.success = true;
  }

}
module.exports = ASEResponse;
