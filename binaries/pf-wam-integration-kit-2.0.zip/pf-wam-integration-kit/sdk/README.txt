﻿==================================
PingFederate WAM Agent Plug-in SDK 
==================================

Release: August, 2014

Copyright (C) 2014 Ping Identity Corporation.  All rights reserved.

This document is provided for informational purposes only, and the information herein is subject to change without notice.  Ping Identity Corporation ("Ping") owns or controls all right, title and license in and to the WAM Agent plug-in SDK, including, but not limited to, all code samples and documentation provided therein.  Ping hereby grants you the limited, revocable, non-transferable, non-sublicensable, worldwide, non-exclusive right to use this SDK for development of software for use in connection with Ping Federate.  Ping is providing the SDK "as is" without warranty of any kind and disclaims any responsibility for any harm resulting from your use of the SDK.

----------
Disclaimer
----------

The purpose of these samples is to demonstrate the use of the WAM plug-in SDK and is not intended as best practices for application development. 

--------
Overview
--------

This document provides instructions on building and deploying WAM plug-in samples for either the integration kit or token translator.

-------------------
System Requirements
-------------------

- Samples for specific WAM systems require libraries from their respective Java SDKs which must be copied to the lib folder.  
- JDK 1.6 or higher to build. Environment variable JAVA_HOME must be set to the path of the JDK.

-----------------------
Building generic Sample
-----------------------

The generic sample builds a dummy WAM plug-in which can be deployed and configured in PingFederate as a sample. The steps required to use this plug-in are as follows:

1 Run sdk/samples/generic/build.bat (on Windows) and (sdk/samples/generic/build.sh) on linux to build the jar.
2 Copy the "pf-wam-plugin-impl.jar" to <PF_install>/pingfederate/server/default/deploy folder and re-start PingFederate.
3 The newly created WAM plug-in will appear in the WAM plug-in Type dropdown within the WAM Adapter or Token Translator as "Sample WAM Agent".

-------------------
Building OAM Sample
-------------------

This sample builds a fully functional OAM plug-in to use with WAM Integration Kit or Token Translator. In addition a custom authentication plug-in is also created which is used to authenticate requests coming from PingFederate. The Integration Kit and Token Translator already include a pre-built, fully functional WAM plug-in for OAM. If you choose to modify the OAM plug-in you can build your custom version as follows:
1 Obtain the following jars from your OAM installation and copy them into sdk/lib folder.
	- oamasdk-api.jar
	- oam-plugin.jar
	- felix.jar
	- utilities.jar
	- identity-provider.jar
2 Run sdk/samples/oam/build.bat (on Windows) and (sdk/samples/oam/build.sh) on linux to build the jars.
3 Copy the "pf-oam-plugin.jar" to <PF_install>/pingfederate/server/default/deploy folder and re-start PingFederate.
4 The newly created OAM plug-in will appear in the WAM plug-in Type dropdown within the WAM Adapter or Token Translator as "OAM".
5 This sample will also create a custom authentication scheme jar 'PingCustomAuthPlugin.java'. This needs to be deployed to the OAM system as a custom authentication scheme. For more information refer to the OAM System documentation. While configuring this auth scheme, make sure the shared secret is the same as Authentication Scheme Secret configured in WAM SP Adapter / WAM Token Generator.
