# Setup the JVM
if [ "x$JAVA_HOME" != "x" ]; then
	PATH_TO_SDK=`dirname "$0"`
	PATH_TO_SDK=`( cd "$PATH_TO_SDK" && pwd )`
	cd "$PATH_TO_SDK"
	for f in ../../lib/*; do LIB_FILES=$LIB_FILES$f\:; done
	echo "Building WAM Plugin jar (pf-wam-plugin-impl.jar)..."
	$JAVA_HOME/bin/javac -classpath $LIB_FILES com/pingidentity/wam/agent/*.java
	$JAVA_HOME/bin/jar cf pf-wam-plugin-impl.jar com/pingidentity/wam/agent/*.class PF-INF
	echo "Done."
else
	echo "JAVA_HOME is not set."
	echo "Set JAVA_HOME to the directory of your local JDK to build WAM plugin."
fi
