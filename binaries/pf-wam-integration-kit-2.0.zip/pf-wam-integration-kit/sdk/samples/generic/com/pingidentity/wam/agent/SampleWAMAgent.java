/***************************************************************************
 * Copyright (C) 2012 Ping Identity Corporation
 * All rights reserved.
 *
 * The contents of this file are the property of Ping Identity Corporation.
 * You may not copy or use this file, in either source code or executable
 * form, except in compliance with terms set by Ping Identity Corporation.
 * For further information please contact:
 *
 *      Ping Identity Corporation
 *      1001 17th Street Suite 100
 *      Denver, CO 80202
 *      303.468.2900
 *      http://www.pingidentity.com
 *
 **************************************************************************/

package com.pingidentity.wam.agent;

import java.util.Map;
import java.util.HashMap;

import org.apache.commons.collections.MultiMap;
import org.apache.log4j.Logger;

import com.pingidentity.wam.sdk.WAMAgent;
import com.pingidentity.wam.sdk.WAMAgentInitializeException;
import com.pingidentity.wam.sdk.WAMConfiguration;
import com.pingidentity.wam.sdk.WAMLoginException;
import com.pingidentity.wam.sdk.WAMTokenExpiredException;
import com.pingidentity.wam.sdk.WAMTokenInvalidException;
import com.pingidentity.wam.sdk.WAMTokenNotAuthorizedException;
import com.pingidentity.wam.sdk.WAMTokenCreationException;
import com.pingidentity.wam.sdk.WAMConfigValidationException;

public class SampleWAMAgent
    implements WAMAgent
{
    private static final Logger log = Logger.getLogger(SampleWAMAgent.class);

    public String getAgentType()
    {
        return "Sample WAM Agent";
    }

    public boolean initializeAgent(WAMConfiguration wamConfigData)
        throws WAMAgentInitializeException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------SampleWAMAgent.initializeAgent(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        // You can retrieve the configuration data specified in adapter instance through
        // WAMConfiguration. For e.g., Agent Name and Secret are retrieved here.
        String agentName = wamConfigData.getAgentName();
        String agentSecret = wamConfigData.getAgentSecret();

        // Use configuration data to establish connection with WAM Servers

        return true;
    }

    public void validateConfiguration(WAMConfiguration wamConfigData)
        throws WAMConfigValidationException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------SampleWAMAgent.validateConfiguration(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        // You can retrieve the configuration data specified in adapter instance through
        // WAMConfiguration. For e.g., Agent Name and Secret are retrieved here.
        String agentName = wamConfigData.getAgentName();
        String agentSecret = wamConfigData.getAgentSecret();

        // Validate the input configuration and throw a WAMConfigValidationException
        // exception if any errors are encountered.
    }

    public String createToken(WAMConfiguration wamConfigData, String username, MultiMap extendedAttributes)
        throws WAMTokenCreationException, WAMTokenNotAuthorizedException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------SampleWAMAgent.createToken(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());
        msg.append("username: ").append(username);

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        String tokenString = "DummyToken";

        // Use the username and shared secret along with configuration
        // data saved earlier to create a WAM token. Also extended attributes
        // are available here

        return tokenString;
    }

    public Map<String, String> getAttributes(WAMConfiguration wamConfigData, String tokenString)
        throws WAMTokenInvalidException, WAMTokenExpiredException, WAMTokenNotAuthorizedException, WAMLoginException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------SampleWAMAgent.getAttributes(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());
        msg.append("WAM Token String: ").append(tokenString);

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        Map<String, String> userAttributes = new HashMap<String, String>();

        // Extract user attributes from token string using proprietary APIs and return as a Map.
        // For this example we will just create a set of dummy attributes
        userAttributes.put("userId", "joe");
        userAttributes.put("group", "Users");

        return userAttributes;
    }

    public boolean logout(WAMConfiguration wamConfigData, String tokenString)
        throws WAMTokenInvalidException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------SampleWAMAgent.logout(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());
        msg.append("WAM Token String: ").append(tokenString);

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        // Invalidate user session with WAM servers using proprietary APIs

        return true;
    }

    /** @deprecated */
    public String createToken(String username, MultiMap extendedAttributes)
        throws WAMTokenCreationException
    {
        String errorMessage = "createToken(String username, MultiMap extendedAttributes) Method not implemented for this version.";
        log.warn(errorMessage);
        throw new WAMTokenCreationException(errorMessage);
    }

    /** @deprecated */
    public Map<String, String> getAttributes(String tokenString)
        throws WAMTokenInvalidException, WAMTokenExpiredException, WAMTokenNotAuthorizedException, WAMLoginException
    {
        String errorMessage = "getAttributes(String tokenString) Method not implemented for this version.";
        log.warn(errorMessage);
        throw new WAMLoginException(errorMessage);
    }

    /** @deprecated */
    public boolean logout(String tokenString)
        throws WAMTokenInvalidException
    {
        String errorMessage = "logout(String tokenString) Method not implemented for this version.";
        log.warn(errorMessage);
        throw new WAMTokenInvalidException(errorMessage);
    }
}
