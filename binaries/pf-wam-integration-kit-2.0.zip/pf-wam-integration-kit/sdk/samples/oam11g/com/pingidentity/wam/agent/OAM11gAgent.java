/***************************************************************************
 * Copyright (C) 2006 Ping Identity Corporation
 * All rights reserved.
 *
 * The contents of this file are the property of Ping Identity Corporation.
 * You may not copy or use this file, in either source code or executable
 * form, except in compliance with terms set by Ping Identity Corporation.
 * For further information please contact:
 *
 *      Ping Identity Corporation
 *      1099 18th St Suite 2950
 *      Denver, CO 80202
 *      303.468.2900
 *      http://www.pingidentity.com
 *
 **************************************************************************/
package com.pingidentity.wam.agent;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.List;
import java.io.File;
import java.net.URLEncoder;

import org.apache.commons.collections.MultiMap;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.pingidentity.wam.sdk.WAMAgent;
import com.pingidentity.wam.sdk.WAMAgentHelper;
import com.pingidentity.wam.sdk.WAMAgentInitializeException;
import com.pingidentity.wam.sdk.WAMConfiguration;
import com.pingidentity.wam.sdk.WAMConstants;
import com.pingidentity.wam.sdk.WAMLoginException;
import com.pingidentity.wam.sdk.WAMTokenExpiredException;
import com.pingidentity.wam.sdk.WAMTokenInvalidException;
import com.pingidentity.wam.sdk.WAMTokenNotAuthorizedException;
import com.pingidentity.wam.sdk.WAMTokenCreationException;
import com.pingidentity.wam.sdk.WAMConfigValidationException;

import oracle.security.am.asdk.AccessClient;
import oracle.security.am.asdk.UserSession;
import oracle.security.am.asdk.ResourceRequest;
import oracle.security.am.asdk.AccessException;

public class OAM11gAgent
    implements WAMAgent
{
    private static final Logger log = Logger.getLogger(OAM11gAgent.class);
    private WAMConfiguration wamConfiguration = null;
    private AccessClient accessClient = null;

    public String getAgentType()
    {
        return "OAM 11g";
    }

    public boolean initializeAgent(WAMConfiguration wamConfigData)
        throws WAMAgentInitializeException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------OAM11gAgent.initializeAgent(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        // You can also store the configuration data locally so that rest of the methods
        // have access to them
        this.wamConfiguration = wamConfigData;

        // Use configuration data obtained above to establish connection with WAM Servers
        try
        {
            accessClient = AccessClient.createDefaultInstance(this.wamConfiguration.getAgentConfigLocation(),
                                                              AccessClient.CompatibilityMode.OAM_11G);
        }
        catch (AccessException ae)
        {
            throw new WAMAgentInitializeException(ae);
        }

        return true;
    }

    public void validateConfiguration(WAMConfiguration wamConfigData)
        throws WAMConfigValidationException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------OAM11gAgent.validateConfiguration(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        String agentConfigLocation = wamConfigData.getAgentConfigLocation();

        // Validate the input configuration and throw a WAMConfigValidationException
        // exception if any errors are encountered.
        if (StringUtils.isBlank(agentConfigLocation))
        {
            throw new WAMConfigValidationException("'" + WAMConstants.WAM_AGENT_CONFIG_LOCATION_FIELD
                                                   + "' must be specified.");
        }

        // Validate if config location is a valid path
        File file = new File(agentConfigLocation);
        if (!file.isDirectory())
        {
            throw new WAMConfigValidationException("'" + WAMConstants.WAM_AGENT_CONFIG_LOCATION_FIELD + "' value '"
                                                   + agentConfigLocation + "' is not a valid path.");
        }

    }

    public String createToken(WAMConfiguration wamConfigData, String username, MultiMap extendedAttributes)
        throws WAMTokenCreationException, WAMTokenNotAuthorizedException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------OAM11gAgent.createToken(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());                
        msg.append("username: ").append(username);

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        String tokenString = null;

        Hashtable<String, String> cred = new Hashtable<String, String>();
        UserSession userSession = null;

        // Get the resource request
        ResourceRequest resourceRequest = null;
        try
        {
            resourceRequest = new ResourceRequest(accessClient, "http", this.wamConfiguration.getProtectedResource(),
                                                  "GET");
            log.debug("About to call isProtected");
            if (!resourceRequest.isProtected())
            {
                String errorMsg = "Target resource is not protected by OAM Access Server.";
                log.error(errorMsg);
                throw new WAMTokenCreationException(errorMsg);
            }
            cred.put("userid", username);
            cred.put("pluginSecret", this.wamConfiguration.getWAMAuthSchemeSecret());

            log.info("Adding extended attributes to the Credential Map");
            if (extendedAttributes != null && extendedAttributes.size() > 0)
            {
                Set infoNames = extendedAttributes.keySet();
                Iterator iterator = infoNames.iterator();
                log.debug("--Begin Extended Attributes--");
                while (iterator.hasNext())
                {
                    String infoName = iterator.next().toString();
                    String infoValue = (String)((List)extendedAttributes.get(infoName)).get(0);

                    cred.put(infoName, infoValue);
                }
                log.debug("--End Extended Attributes--");
            }

            // Obtain Client IP Address from extended Attributes
            log.debug("About to call UserSession");
            userSession = new UserSession(accessClient, resourceRequest, cred, WAMAgentHelper.getServerAddress());
            if (userSession.isAuthorized(resourceRequest))
            {
                log.debug("User is authorized to access protected resource");
            }
            else
            {
                log.warn("User is not authorized to access protected resource");
            }
            tokenString = userSession.getSessionToken();
            log.debug("OAM Session Token = " + tokenString);
            if(wamConfigData.isEncodeToken())
            {
                tokenString = URLEncoder.encode(tokenString);
                log.debug("OAM Encoded Session Token = " + tokenString);
            }              
        }
        catch (AccessException ae)
        {
            log.error(ae);
            throw new WAMTokenCreationException(ae.getMessage(), ae);
        }
        catch (Exception e)
        {
            log.error(e);
            throw new WAMTokenCreationException(e.getMessage(), e);
        }  

        return tokenString;
    }

    public Map<String, String> getAttributes(WAMConfiguration wamConfigData, String tokenString)
        throws WAMTokenInvalidException, WAMTokenExpiredException, WAMTokenNotAuthorizedException, WAMLoginException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------OAM11gAgent.getAttributes(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());                
        msg.append("WAM Token String: ").append(tokenString);

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        Map<String, String> userAttributes = new HashMap<String, String>();

        UserSession userSession = null;

        try
        {
            userSession = new UserSession(this.accessClient, tokenString);
            if (userSession.getStatus() == UserSession.LOGGEDIN)
            {
                ResourceRequest resourceRequest = new ResourceRequest(accessClient, "http",
                                                                      this.wamConfiguration.getProtectedResource(),
                                                                      "GET");
                if (!resourceRequest.isProtected())
                {
                    throw new WAMTokenNotAuthorizedException("Protected Resource '"
                                                             + this.wamConfiguration.getProtectedResource()
                                                             + "' is not protected by OAM Access Server.");
                }
                if (userSession.isAuthorized(resourceRequest))
                {
                    // Retrieve all actions and add them to the userActions map
                    String[] actionTypes = userSession.getActionTypes();
                    log.debug("About to loop through for actions");
                    for (int i = 0; i < actionTypes.length; i++)
                    {
                        log.debug("loop + " + i);
                        Hashtable actions = userSession.getActions(actionTypes[i]);
                        Enumeration e = actions.keys();
                        int item = 0;
                        log.debug("Printing Actions for type " + actionTypes[i]);

                        while (e.hasMoreElements())
                        {
                            String name = (String)e.nextElement();
                            log.debug("Actions[" + item + "] - Name: " + name + " value: " + "*****");
                            userAttributes.put(name, (String)actions.get(name));
                            item++;
                        } // end while loop
                    } // end for loop

                    if (this.wamConfiguration.getAuthLevelIdentifier() != null)
                    {
                        userAttributes.put(this.wamConfiguration.getAuthLevelIdentifier(),
                                           String.valueOf(userSession.getLevel()));
                    }
                }
                else
                {
                    throw new WAMTokenNotAuthorizedException("User '" + userSession.getUserIdentity()
                                                             + "' is not authorized to access protected resource '"
                                                             + this.wamConfiguration.getProtectedResource() + "'.");
                }
            }
        }
        catch (AccessException ae)
        {
            log.error(ae);
            throw new WAMTokenInvalidException(ae.getMessage(), ae);
        }
        catch (Exception e)
        {
            log.error(e);
            throw new WAMTokenInvalidException(e.getMessage(), e);
        }     

        log.debug("userAttributes = " + userAttributes);
        return userAttributes;
    }

    public boolean logout(WAMConfiguration wamConfigData, String tokenString)
        throws WAMTokenInvalidException
    {
        StringBuilder msg = new StringBuilder();

        msg.append("\n---------------OAM11gAgent.logout(...)-----------------\n");

        msg.append("WAM Configuration: ").append(wamConfigData.toString());                
        msg.append("WAM Token String: ").append(tokenString);

        msg.append("\n----------------------------------------------------------------------\n");

        log.debug(msg);

        boolean result = true;
        UserSession userSession = null;
        try
        {
            log.debug("Attempting to terminate existing user session");
            userSession = new UserSession(this.accessClient, tokenString);
            userSession.logoff();

        }
        catch (AccessException ae)
        {
            log.warn("Existing token not found or token was invalid.");
            result = false;
        }
        catch (Exception e)
        {
            log.warn("Existing token not found or token was invalid.");
            result = false;
        }           
        return result;
    }

    /** @deprecated */
    public String createToken(String username, MultiMap extendedAttributes)
        throws WAMTokenCreationException
    {
        String errorMessage = "createToken(String username, MultiMap extendedAttributes) Method not implemented for this version.";
        log.warn(errorMessage);
        throw new WAMTokenCreationException(errorMessage);
    }

    /** @deprecated */
    public Map<String, String> getAttributes(String tokenString)
        throws WAMTokenInvalidException, WAMTokenExpiredException, WAMTokenNotAuthorizedException, WAMLoginException
    {
        String errorMessage = "getAttributes(String tokenString) Method not implemented for this version.";
        log.warn(errorMessage);
        throw new WAMLoginException(errorMessage);
    }

    /** @deprecated */
    public boolean logout(String tokenString)
        throws WAMTokenInvalidException
    {
        String errorMessage = "logout(String tokenString) Method not implemented for this version.";
        log.warn(errorMessage);
        throw new WAMTokenInvalidException(errorMessage);
    }
}
