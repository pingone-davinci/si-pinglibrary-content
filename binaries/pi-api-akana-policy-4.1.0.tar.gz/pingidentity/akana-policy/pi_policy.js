/*
  v108
  Imports Provide-ASE-HTTP-Request-Parameters
*/
var inputMsg = messageContext.getMessage();
var exchange = messageContext.getExchange();
var correlationID;
var status;
var aseMsg;
var type;
var debugMsg;
var blockMode, processMode, piInstance;

//Retain original payload
var content = inputMsg.getContent();
exchange.setProperty("content", content);

switch(messageContext.getParameterType()) {
 case 0:

		type = "request";

		//Set blockMode. Represents a configured value. Set to true by default.
		blockMode = "true";

    /*
		if ( inputMsg.getTransportHeaders().get("blockMode") ) {
			if ( inputMsg.getTransportHeaders().get("blockMode").getValue() != null ) {
				blockMode = inputMsg.getTransportHeaders().get("blockMode").getValue();
				inputMsg.getTransportHeaders().remove("blockMode");
			}
		}
    */

		exchange.setProperty("blockMode", blockMode);
		debugMsg = "INFO {policy}: blockMode " + blockMode + " set on exchange.";
		debugLogger(debugMsg);

		//Set processMode. This will eventually be a configured value.
		processMode = "sync";
		if ( inputMsg.getTransportHeaders().get("processMode") ) {
			if ( inputMsg.getTransportHeaders().get("processMode").getValue() != null ) {
				processMode = inputMsg.getTransportHeaders().get("processMode").getValue();
				inputMsg.getTransportHeaders().remove("processMode");
			}
		}

		//If Authorization, X_Authorization contains the retained Authorization header
		//if ( inputMsg.getTransportHeaders().get("Authorization") ) {
			if ( inputMsg.getTransportHeaders().get("X_Authorization") ) {
				if ( inputMsg.getTransportHeaders().get("X_Authorization").getValue() != null ) {
          var xAuth = inputMsg.getTransportHeaders().get("X_Authorization").getValue();
				  inputMsg.getTransportHeaders().add("Authorization", xAuth);
				  inputMsg.getTransportHeaders().remove("X_Authorization");
          debugMsg = "INFO {policy}: X_Auth value " + xAuth + " copied to Authorization header";
          debugLogger(debugMsg);
			  } else {
          debugMsg = "WARNING {policy}: no value found for X_Authorization header.";
          debugLogger(debugMsg);
        }
		  }
		//}

		exchange.setProperty("processMode", processMode);
		debugMsg = "INFO {policy}: processMode " + processMode + " set on exchange.";
		debugLogger(debugMsg);

		aseMsg = createASEMessage(inputMsg, type);

		//NOTE: BELOW SHOULD BE TRY-CATCH, for one to deal with null pointers
		correlationID = aseMsg.getTransportHeaders().get("X-CorrelationID").getValue();
		if ( !correlationID ) {
			debugMsg = "ERROR {policy}: no correlationID found.";
			debugLogger(debugMsg);
			status = "500";
			scriptFailed(status);
		} else {
			exchange.setProperty("correlationID", correlationID);
			debugMsg = "INFO {policy}: correlationID " + correlationID + " set on exchange.";
			debugLogger(debugMsg);
		}

    piInstance = "primary";

		var parameterArray = setASEParameters(type, piInstance);

		var serviceQName = parameterArray[0];
		var interfaceName = parameterArray[1];
		var operationName = parameterArray[2];

		status = sendHttpRequest(aseMsg, serviceQName, interfaceName, operationName, processMode);

    if ( status == "504" || status == "500") {
      //504 is (also) returned if messenger.send returned '2'. We assume resource unavailable.
      //Try alternative:
      piInstance = "secondary";
      parameterArray = setASEParameters(type, piInstance);

		  serviceQName = parameterArray[0];
		  interfaceName = parameterArray[1];
		  operationName = parameterArray[2];

		  debugMsg = "INFO: trying to call " + piInstance + " instance.";
		 	debugLogger(debugMsg);

		  //aseMsg references an emtpy message after timeout. Create anew?
      aseMsg = createASEMessage(inputMsg, type, correlationID);

      status = sendHttpRequest(aseMsg, serviceQName, interfaceName, operationName, processMode);
    }

		//To be included in scripted policy, perhaps except final result.setSuccess
		if (status == "200" || status == "201") {
			debugMsg = "INFO {policy}: policy will return true (status = )" + status + ".";
			debugLogger(debugMsg);

      exchange = messageContext.getExchange();
      exchange.setProperty("piInstance", piInstance);

			result.setSuccess(true);

		} else if ( status == "403") {

			if ( blockMode == "true" ) {
				debugMsg = "INFO {policy}: policy will return false (status = " + status + ").";
				debugLogger(debugMsg);

			  scriptFailed(status);

			} else {
				//Do not block
				blockOverride(content);
				debugMsg = "INFO {policy}: ASE returned " + status + ", but blockMode is set to " + blockMode + " so " + type + " has not been blocked.";
				debugLogger(debugMsg);
        //exchange.setProperty("piInstance", piInstance);
			}
    } else if (status =="555") {
      //Probably required input parameters were missing
      debugMsg = "ERROR {policy}: sendHttpRequest returned status " + status + ", probably parameters missing.";
      debugLogger(debugMsg);
      scriptFailed(status);
		} else {
			//Assume status 400, 401 or 503: still send request to backend
			debugMsg = "INFO {policy}: ASE returned " + status + ", this allows for " + type + " to be forwarded to backend server.";
      exchange.setProperty("piInstance", piInstance);
			debugLogger(debugMsg);
			result.setSuccess(true);
		}

    	break;

 case 1:
		type = "response";

    processMode = exchange.getProperty("processMode");
    debugMsg = "INFO {policy}: value " + processMode +  " found for processMode."
    debugLogger(debugMsg);

    piInstance = exchange.getProperty("piInstance");
    if (piInstance == "" || piInstance == null ) {
      piInstance = "primary";
      debugMsg = "WARNING {policy}: no value for piInstance found, setting it to default 'primary'."
      debugLogger(debugMsg);
    } else {
      debugMsg = "INFO {policy}: found value " + piInstance + " for piInstance."
      debugLogger(debugMsg);
    }

		var httpStatus;
		var outMessage = exchange.getOutMessage();
		if ( !outMessage ) {
			//auditLog.debug("TEMP {policy}: no outmessage found in 'response' case.");
		} else {
			httpStatus = outMessage.getProperty("http.status.code.property");
		}
		status = httpStatus;

		debugMsg = "INFO {policy}: server response HttpStatus is " + status + ".";
		debugLogger(debugMsg);

    correlationID = exchange.getProperty("correlationID");
		if ( !correlationID || correlationID == "" ) {
			debugMsg = "ERROR {policy}: no correlationID found.";
			debugLogger(debugMsg);
			status = "500";
			scriptFailed(status);
    }

		aseMsg = createASEMessage(inputMsg, type, correlationID);

		var parameterArray = setASEParameters(type, piInstance);

		var serviceQName = parameterArray[0];
		var interfaceName = parameterArray[1];
		var operationName = parameterArray[2];

		status = sendHttpRequest(aseMsg, serviceQName, interfaceName, operationName, processMode);

    if ( status == "408") {
      //408 is (also) returned if messenger.send returned '2'. We assume resource unavailable.
      //Try alternative:
      piInstance = "secondary";
      parameterArray = setASEParameters(type, piInstance);

		  serviceQName = parameterArray[0];
		  interfaceName = parameterArray[1];
		  operationName = parameterArray[2];

		  debugMsg = "INFO: trying to call " + piInstance + " instance.";
		 	debugLogger(debugMsg);

		  //Seems aseMsg references an emtpy message after timeout. Create anew?
      aseMsg = createASEMessage(inputMsg, type, correlationID);

      status = sendHttpRequest(aseMsg, serviceQName, interfaceName, operationName, processMode);
    }

	  //For fault and response, always return true regardless of ASE result
    debugMsg = "INFO: policy will return true (status = )" + status + ".";
    debugLogger(debugMsg);
	  result.setSuccess(true);

    //Is this still required now that we've renamed message vars? TBD
	  inputMsg.setContent(content);
    debugMsg = "INFO {policy}: message content reassigned to message.";
    debugLogger(debugMsg);

	  //ONCE PROCESSED BY ASE, VERIFY IF WE NEED TO REMOVE THE CORRELATION HEADER FROM ACTUAL RESPONSE

    break;

 default:
 		type = "fault";

		processMode = exchange.getProperty("processMode");

		var faultMessage = exchange.getFaultMessage();
		if ( !faultMessage ) {
			//auditLog.debug("TEMP {policy}: no faultmessage found in 'response' case.");
		} else {
			httpStatus = faultMessage.getProperty("http.status.code.property");
		}
		status = httpStatus;

    debugMsg = "INFO {policy}: server fault-response HttpStatus is " + status + ".";
		debugLogger(debugMsg);

		aseMsg = createASEMessage(inputMsg, type);

		correlationID = exchange.getProperty("correlationID");
		if ( !correlationID || correlationID == "" ) {
			debugMsg = "ERROR {policy}: no correlationID found.";
			debugLogger(debugMsg);
			status = "500";

      auditLog.debug("TEMP: this is where ScriptFailed would have been called. Left out for now....");
			//scriptFailed(status);
		} else {
			headerName = "X-CorrelationID";
			aseMsg.getTransportHeaders().add(headerName, correlationID);
      debugMsg = "INFO {policy}: header " + headerName + " added with value " + correlationID + ".";
			debugLogger(debugMsg);

			var parameterArray = setASEParameters(type);

			var serviceQName = parameterArray[0];
			var interfaceName = parameterArray[1];
			var operationName = parameterArray[2];

			status = sendHttpRequest(aseMsg, serviceQName, interfaceName, operationName, processMode);

			//For fault and response, always return true regardless of ASE result
      debugMsg = "INFO {policy}: policy will return true (status = )" + status + ".";
      debugLogger(debugMsg);
			result.setSuccess(true);

      //Is this still required now that we've renamed message vars? TBD
			inputMsg.setContent(content);
      debugMsg = "INFO message content reassigned to message.";
      debugLogger(debugMsg);

			//ONCE PROCESSED BY ASE, VERIFY IF WE NEED TO REMOVE THE CORRELATION HEADER FROM ACTUAL RESPONSE
    }
}


/*
  Function: blockOverride
*/
function blockOverride(content) {

	result.setSuccess(true);
	var outMsg = messageContext.getExchange().getOutMessage();
	if (!outMsg) {
		debugMsg = "ERROR {policy:blockOverride}: expected outMessage, but none found.";
		debugLogger(debugMsg);
	} else {
		var msgText = outMsg.getContentAsString();
		debugMsg = "INFO {policy:blockOverride}: " + msgText + ".";
		debugLogger(debugMsg);
	}
	//Now, the message should proceed as if nothing happened
	//inputMsg.setContent(content);
	//auditLog.debug("INFO message content reassigned to message.")
}

/*
  Function: scriptFailed
*/
function scriptFailed(status) {
   var msgText;

	var outMsg = messageContext.getExchange().getOutMessage();
	if (!outMsg) {
		outMsg = messageContext.getExchange().createOutputMessage();
	} else {
      msgText = new String( outMessage.getContentAsString() );
		//auditLog.debug("TEMP {policy:scriptFailed}: text with outMessage: " + msgText + ".");
  }

	var faultMsg = messageContext.getExchange().getFaultMessage();
	if (! faultMessage) {
		//auditLog.debug("TEMP {policy:scriptFailed}: no faultMessage found in scriptFailed procedure.");
	} else {
		//auditLog.debug("TEMP {policy:scriptFailed}: text with faultMessage: " + faultMessage.getContentAsString() + ".");
	}
	// Set the HTTP status code
	outMsg.setProperty('http.status.code.property', status);

	var headers = outMsg.createTransportHeaders();
	headers.add("Content-Type", "application/json");

  if ( msgText == "" ) {
    msgText = new String("Error description not found, hence presenting default error message");
	  //auditLog.debug("TEMP: default error message set.");
  }

  	//var jObj = { "faultcode":"policy", "faultstring" : msgText };
  	var jObj = { "faultcode":"policy", "faultstring" : "Request not accepted." };
  	var jStr = JSON.stringify(jObj);
	outMsg.setStringContent(jStr);

	result.setSuccess(false);
}


/*
   Function:      buildASEJSON; creates JSON object for ASE request
	Version:       1.6
	Last modified: 26-Nov-2019
	Imports:       getProperties
   Input:         message (non-normalized)
   Returns:       JSON string
*/

function buildASEJSON(inputMsg) {

try{
  var debugMsg;

  var properties = getProperties(inputMsg);

	var client_url = new String( properties["http.client.url"] );
	var source_ip = client_url.substring(client_url.indexOf("//")+2, client_url.lastIndexOf(":") );

	//Sample generated bad source_ip = "3.26.26.26";
	if ( inputMsg.getTransportHeaders().get("source_ip") != null ) {
		if ( inputMsg.getTransportHeaders().get("source_ip").getValue() != "" ) {
			source_ip = new String(inputMsg.getTransportHeaders().get("source_ip").getValue());
			inputMsg.getTransportHeaders().remove("source_ip");
	   	//auditLog.debug("TEMP: Source IP: " + source_ip);
		}
	}

	var tt = client_url.substring(client_url.lastIndexOf(":")+1);
	var source_port = parseInt( tt.substring(0,tt.indexOf("/")) );
	if (source_port == "" || source_port == null ) {
		//Set default
		source_port = "443";
	}
	//auditLog.debug("TEMP: Source port: " + source_port);

  //var url = tt.substring(tt.indexOf("/"));
	//auditLog.debug("TEMP: http.client.url is " + client_url);


  var http_request_line = new String( properties["http.request.line"]);
	//auditLog.debug("TEMP: http.request.line is " + http_request_line);
  var url = http_request_line.substring( http_request_line.indexOf("/"));
  url = url.substring(0, url.lastIndexOf(" ") );
  //auditLog.debug("TEMP: URL: " + url);
  var method = http_request_line.substring(0,http_request_line.indexOf("/")-1);
  //auditLog.debug("TEMP: Method: " + method );

	var http_version = http_request_line.substring(http_request_line.lastIndexOf("/")+1);
		if (http_version == "" || http_version == null ) {
		//Set default
		http_version = "1.1";
	}
	//auditLog.debug("TEMP: Version: " + http_version );

	var tHeaders = inputMsg.getTransportHeaders();

	//Include all incoming transport headers
	var aHeaders = tHeaders.getArray();
	var tHeaderName, tHeaderValue;
	var headers = new Array();
	var s = new String();

	for (var i=0; i<aHeaders.length;i++) {

		var item = new Object();

		var hName = new String( aHeaders[i].getName() );
      var hValue = new String( aHeaders[i].getValue() );

		if ( hName == "Host") {
			var host = hValue;
			if ( hName.indexOf(":") != -1 ) {
				item = { "Host" : hValue.substring( 0,hValue.indexOf(":") ) };
			} else {
				item = { "Host" : hValue }
			}
		} else {

		   item[hName] = hValue;
		}
		headers[i] = item;
	}

  //Added Nov 21: if present with request, add authZ claims to userinfo section
  var authHeaders = [{"username":"OAuth_ResourceOwnerUID"}, {"scope":"OAuth_Scope"}, {"client_id":"OAuth_ClientID"}];

  var obj, k, v;
	var ui = false;
  var userInfoArray = new Array();
  var userInfoObject = new Object();

  for (var i=0; i<authHeaders.length; i++) {
    obj = authHeaders[i];
    k = Object.keys(obj)[0];
    v = obj[k];
	  var hv;

    if ( inputMsg.getTransportHeaders().get(v) ) {
        hv = new String( inputMsg.getTransportHeaders().get(v).getValue() );
        userInfoObject[k] = hv;
		  debugMsg = "INFO: value " + hv + " for header " + v + "added to userinfo object.";
        debugLogger(debugMsg);
		 ui = true;
    } else {
      debugMsg = "WARNING: header " + v + " not found. Skipping.";
      debugLogger(debugMsg);
    }
  }

  var obj = {};
  if ( Object.keys(userInfoObject).length > 0 ) {
    userInfoArray[0] = userInfoObject;
    obj = { "source_ip": source_ip, "source_port": source_port, "method": method, "url": url, "http_version": http_version,"headers":headers, "user_info": userInfoArray };
    debugMsg = "INFO added userinfo to JSON object.";
    debugLogger(debugMsg);
  } else {
    obj = { "source_ip": source_ip, "source_port": source_port, "method": method, "url": url, "http_version": http_version,"headers":headers };
	 debugMsg = "INFO no userinfo added to JSON object.";
    debugLogger(debugMsg);
  }

	var jsonString;
	jsonString = JSON.stringify(obj);

	debugMsg = "INFO: jsonString to be returned: " + jsonString + "."
	debugLogger(debugMsg)

	return jsonString;
}catch(err){
  auditLog.debug(err);
}

}


/*
   Function:      buildASEJSONresponse; creates JSON object for ASE response
	Version:       1.2
	Last modified: 30-Oct-2019
	Imports:       getProperties
   Input:         message (non-normalized)
   Returns:       JSON string
*/

function buildASEJSONresponse(inputMsg) {

try{
 	var properties = getProperties(inputMsg);

   var http_response_status_line = new String( properties["http.response.status.line"]);
   //var http_version = http_response_status_line.substring(http_response_status_line.indexOf("/")+1,http_response_status_line.indexOf("/")+4 );
	var http_version = "1.1";
	if (http_version == "" || http_version == null ) {
		//Set default
		http_version = "1.1";
	}

   //http response code
	var http_response_code = new String( properties["http.status.code.property"] );

	//http response status
	var http_response_status = new String( properties["http.status.message.property"] );

	var tHeaders = inputMsg.getTransportHeaders();

	//Include all incoming transport headers
	var aHeaders = tHeaders.getArray();
	var tHeaderName, tHeaderValue;
	var headers = new Array();
	//var item = new Object();
	var s = new String();

	for (var i=0; i<aHeaders.length;i++) {

		var item = new Object();

		var hName = new String( aHeaders[i].getName() );
      var hValue = new String( aHeaders[i].getValue() );

		if ( hName == "Host") {
			var host = hValue;
			if ( hName.indexOf(":") != -1 ) {
				item = { "Host" : hValue.substring( 0,hValue.indexOf(":") ) };
			} else {
				item = { "Host" : hValue }
			}
		} else {

		   item[hName] = hValue;
		}
		headers[i] = item;
	}

	var jsonString;

	var obj = { "response_code": http_response_code, "response_status": http_response_status, "http_version": http_version,"headers":headers };

	jsonString = JSON.stringify(obj);

	auditLog.debug("INFO: jsonString to be returned: " + jsonString + ".");

	return jsonString;
}catch(err){
  auditLog.debug(err);
}
}


/*
  Function:			  createASEMessage
  Version:			  1.7
  Last modified:	16-Dec-2019
  Imports:			  Build-ASE-JSON, Build-ASE-JSON-Response, Build-ASE-JSON-Fault
  Input:				  message (non-norm.); message type (request, response, fault), correlationID (optional, string)
  Returns:			  new message (content-type application/json)
*/

function createASEMessage(inputMsg, type, correlationID) {

	var debugMsg = "";

	debugMsg = "INFO: creating message for type " + type + ".";
	debugLogger(debugMsg);

	var aseMsg = msgFactory.create("application/json");

	if ( !type || type == "" ) {
		debugMsg = "ERROR: input param type cannot be empty.";
		debugLogger(debugMsg);
	}

	var jsonString;
	if ( type == "request") {
		//Create ASE JSON object based on incoming message. Returns jsonString
		jsonString = buildASEJSON(inputMsg);
	} else if ( type == "response") {
		jsonString = buildASEJSONresponse(inputMsg);
	} else if ( type == "fault") {
		jsonString = buildASEJSONresponse(inputMsg);
	} else {
		debugMsg = "ERROR {script:createASEMessage}: no buildJSON available for given type + " + type + ".";
		debugLogger(debugMsg);
	}

	if ( !jsonString ) {
		debugMsg = "ERROR {script:createASEMessage}: building jsonString was not successful.";
		debugLogger(debugMsg);
	} else {
		debugMsg = "INFO {script:createASEMessage}: adding jsonString " + jsonString + " to message.";
		debugLogger(debugMsg);
		//Associate jsonString with message created for ASE.
    	aseMsg.setStringContent(jsonString);
 	}

	//Make sure the required headers are there with predefined values
	var headers = aseMsg.getTransportHeaders();
	if (headers == null ) {
		debugMsg = "WARNING: aseMsg does not have any transport headers. Create.";
		debugLogger(debugMsg);
		headers= aseMsg.createTransportHeaders();
	}

  //ASE-Token has been generated through 'enable_sideband_authentication' setting on ASE. The value added below has been generated
  var ase_token = getASEToken();
  headers.add("ASE-Token", ase_token);

  debugMsg = "INFO {script:createASEMessage}: ASE header 'ASE-Token' added to message.";
  debugLogger(debugMsg);

	//NOTE: below is ONLY required for request.
  if ( correlationID == "" || correlationID == null) {
    if (type == "request") {
      correlationID = makeId(24);
    }
  }
  headers.add("X-CorrelationID", correlationID);
  debugMsg = "INFO {script:createASEMessage}: ASE header 'X-CorrelationID' added to message with value " + correlationID + " for messagetype " + type + ".";
  debugLogger(debugMsg);

	//TEMP
	if (type == "fault") {
		//Content type may still be server response type..Should no longer be the case with newly created ASE message
		//headers.add("Content-Type","application/json");
    	//debugMsg = "INFO {script:createASEMessage}: Content-Type header set to application/json.";
    	//debugLogger(debugMsg);
	}

	return aseMsg;
}

/*
  Function:      makeId
  Version:		  1.0
  Last modified: 11-Oct-2019
  Imports:       none
  Input:         integer (determines length of generated string)
  Returns:       string (generated random)
*/
function makeId (length) {

  var debugMsg = "";
  var result = "";
  var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for ( var i = 0; i < length; i++ ) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  debugMsg = "INFO {script:createASEMessage:makeID}: new correlationID generated: " + result + ".";
  debugLogger(debugMsg);
  return result;
}


/*
 Function sendHttpRequest
 Version: 1.4
 Last modified: 29-Nov-2019
 Imports: n/a
 Input: message (object),
        serviceQName (string),
		  interfaceName (string),
		  operationName (string),
		  mode (string: "sync" or "async")
 Returns: http status identifier or 500 in case of error - 200 in case of async.
*/

function sendHttpRequest(msg, serviceQName, interfaceName, operationName, mode) {

	var status, exchangeStatus, httpStatus;
	var debugMsg;

   //Error handling: input params missing
	if (!msg) {
		status = "555";
		debugMsg = "ERROR: required input param 'message' missing.";
		debugLogger(debugMsg);
		return status;
	}

	if (!serviceQName) {
		status = "555";
		debugMsg = "ERROR: required input param serviceName missing.";
 		debugLogger(debugMsg);
		return status;
	}

	if (!interfaceName) {
		status = "555";
		debugMsg = "ERROR: required input param interfaceName missing.";
		debugLogger(debugMsg);
		return status;
	}

	if (!operationName) {
		status = "555";
		debugMsg = "ERROR: required input param operationName missing.";
		debugLogger(debugMsg);
		return status;
	}

	if (!mode) {
		status = "555";
		debugMsg = "ERROR: required input param mode missing.";
 		debugLogger(debugMsg);
		return status;
	}

	var SERVICE_QNAME = serviceQName;
	var INTERFACE_NAME = interfaceName;
	var OPERATION_NAME = operationName;

	messenger = msgrService.getMessenger();
	exchangeFactory = msgrService.createExchangeFactory();

	if ( mode == "sync" ) {
		exchange = exchangeFactory.createInOut();
	} else if (mode == "async") {
		exchange = exchangeFactory.createInOnly();
	}

	exchange.setServiceName(SERVICE_QNAME);
	exchange.setInterfaceName(INTERFACE_NAME);
	exchange.setOperationName(OPERATION_NAME);
	exchange.setInMessage(msg);

	debugMsg = "INFO: entering try-catch block - sending message.";
	debugLogger(debugMsg);

	try {
		messenger.send(exchange, true);

		exchangeStatus = exchange.getStatus();
		debugMsg = "INFO 'Send' returned exchange status: " + exchangeStatus + ".";
		debugLogger(debugMsg);

		//Send returns status = 1: ok. Status = 2: resource unavailable. - 25-Nov
    if (exchangeStatus == 1) {
		  if ( mode == "sync") {
			  if ( exchange.getOutMessage() == null ) {

          debugMsg = "WARNING: out message is null. Checking for fault message.";
			    debugLogger(debugMsg);

          if ( exchange.getFaultMessage() != null ) {
				    httpStatus = exchange.getFaultMessage().getProperty("http.status.code.property");
            debugMsg = "INFO: found fault message; http status is "+ httpStatus + ".";
			      debugLogger(debugMsg);
			    }

			    if (httpStatus != null) {
				    status = httpStatus
			    } else {
				    status = "500";
			    }

		    } else {
    		  var response = exchange.getOutMessage();
			    var httpStatus = response.getProperty("http.status.code.property");

			    debugMsg = "INFO Response message: " + response.getContentAsString() + " , http status: " + httpStatus + ".";
			    debugLogger(debugMsg);
        }
      } else if ( mode == "async" ) {
        //Essentially, we don't need to do anything. Fire-and-forget.
      }
    } else if (exchangeStatus == 2) {
      //Resource unavailable. Revert to fail-over instance and retry.
		 //For a first iteration, set returned status to 408.
		 httpStatus = "504";
		 debugMsg = "INFO: exchange returned status 2, setting returned status to 408."
		 debugLogger(debugMsg);
    }

		//For now, return status. For real, probably return HTTP status?
    if (mode == "sync") {
	 	  status = httpStatus;
    } else if (mode == "async") {
      status = "200";
    }

	} catch (err) {
		// DEBUG
		debugMsg = "ERROR: caught " + err + ".";
		debugLogger(debugMsg);

		status = "500";
	}

	return status;

}


/*
   Function:      getProperties:
	Version:       1.0
	Last modified: 20-Oct-2019
	Imports:       n/a
   Input:         message (non-normalized)
   Returns:       array containing all extracted properties
*/

function getProperties(msg) {

  //TEST - inspect exchange properties
   /*var exc = messageContext.getExchange();
   var eprops = exc.getPropertyNames();
    for ( var eprop in Iterator(eprops)) {
        auditLog.debug("exchange prop: " + eprop);
   }*/

  var properties = {};

  //auditLog.debug("Number of properties: " + msg.getPropertyNames().size() );

  var iterator = msg.getPropertyNames().iterator();
  while(iterator.hasNext()) {
	  var propertyName = iterator.next();
     properties[String(propertyName)]=String(msg.getProperty(propertyName));
	  //auditLog.debug("TEMP: found property " + propertyName + " with value " + msg.getProperty(propertyName) + ".");
  }

  return properties;
}


/*
   Function:      debugLogger; generates debug statement IF debug is enabled
	Version:       1.0
	Last modified: 29-Oct-2019
	Imports:       n/a
   Input:         debug message content (string)
   Returns:       n/a
*/
function debugLogger(debugMsg) {
	if ( auditLog.isDebugEnabled() ) {
		auditLog.debug(debugMsg);
	}
}
