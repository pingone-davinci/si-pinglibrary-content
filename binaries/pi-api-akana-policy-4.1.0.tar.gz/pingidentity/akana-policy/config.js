/*
  Function:        setASEParameters; creates JSON object for ASE request/response
	Version:        1.3
	Last modified:  09-Jan-2020 (adjusted primary to newprimary)
	Imports:        none
  Input:           type (string, indicating message type: request or response)
	                piInstance (string, indicating primary or secondary instance)
  Returns:        JSON string
*/

var ase_token = "ASE-Token-123";

/*Primary ASE Configuration*/
var primary_ase_service = "{pi-as-ase-primary_0.0.0}svc_314492f1-ecdc-4184-93a0-57ee2258154b.smshargi.sandbox";
var primary_ase_interface = "{pi-as-ase-primary_0.0.0}pi-as-ase-primary_PortType_0";
var primary_ase_request_operation = "postRequestMetadata";
var primary_ase_response_operation = "postResponseMetadata";
/************************/

/*Secondary ASE Configuration*/
var secondry_ase_service = "{pi-as-ase-primary_0.0.0}svc_314492f1-ecdc-4184-93a0-57ee2258154b.smshargi.sandbox";
var secondary_ase_interface = "{pi-as-ase-primary_0.0.0}pi-as-ase-primary_PortType_0";
var secondary_ase_request_operation = "postRequestMetadata";
var secondary_ase_response_operation = "postResponseMetadata";
/************************/

function setASEParameters(type, piInstance) {

  if (type == "" || type == null) {
    auditLog.debug("ERROR {script setASEParameters}: input param type cannot be null/empty.");
    //FURTHER ERROR HANDLING - TBD
  }

  if (piInstance == "" || piInstance == null) {
    piInstance = "primary";
  }

  debugMsg = "INFO {script setASEParameters}: instance to be invoked is " + piInstance + ".";
  debugLogger(debugMsg);

  var parameterArray = new Array();

  var SERVICE_QNAME, INTERFACE_NAME, OPERATION_NAME;
  if (piInstance == "primary") {
    SERVICE_QNAME = primary_ase_service;
    INTERFACE_NAME = primary_ase_interface;
    if (type == "request") {
      OPERATION_NAME = primary_ase_request_operation;
    } else if (type == "response" || type == "fault") {
      OPERATION_NAME = primary_ase_response_operation;
    }

  } else if (piInstance == "secondary") {
    SERVICE_QNAME = secondry_ase_service;
    INTERFACE_NAME = secondary_ase_interface;
    if (type == "request") {
      OPERATION_NAME = secondary_ase_request_operation;
    } else if (type == "response" || type == "fault") {
      OPERATION_NAME = secondary_ase_response_operation;
    }

  } else {
    debugMsg = "ERROR {script setASEParameters}: no valid value for piInstance found (value is " + piInstance + ").";
    debugLogger(debugMsg);
    return;
  }

  parameterArray[0] = SERVICE_QNAME;
  parameterArray[1] = INTERFACE_NAME;
  parameterArray[2] = OPERATION_NAME;

  return parameterArray;
}

function getASEToken() {
	return ase_token;
}
