/*
  v4
  Imports none.
*/

var msg = messageContext.getMessage();
var headerName = "Authorization";
    
switch(messageContext.getParameterType()) {
	case 0:
		auditLog.debug("Request message.");
		
		var vHeader = msg.getTransportHeaders().get(headerName);
		if (vHeader) {
			var vHeaderValue = new String( vHeader.getValue() );
			auditLog.debug("INFO found headervalue: " + vHeaderValue);
            
			if (vHeaderValue != "") {
				msg.getTransportHeaders().add("X_" + headerName, vHeaderValue);
				auditLog.debug("INFO: X_" + headerName + " header added to request.");
			} else {
				auditLog.debug("**WARNING**: no value found for header " + headerName);
			}
		} else {
        var http_request_line = new String( msg.getProperty("http.request.line"));
        var tokenIndex = http_request_line.indexOf("?access_token=");
        if(tokenIndex <= -1) {
          tokenIndex = http_request_line.indexOf("&access_token=");
        }
        if(tokenIndex > -1) {
          var token_value = http_request_line.substring(tokenIndex+14);
          token_value = token_value.substring(0, token_value.indexOf(" ") );
          var andIndex = token_value.indexOf("&");
          if(andIndex > -1) {
            token_value = token_value.substring(0, andIndex);
        }
  			auditLog.debug("INFO found access_token in query-string: " + token_value);
  			if (token_value != "") {
  				msg.getTransportHeaders().add("X_" + headerName, "Bearer " +token_value);
  				auditLog.debug("INFO: X_" + headerName + " header added to request.");
  			}
      }
    }             
		break;
	
	case 1:
		//auditLog.debug("Response message");
		break;

	default:
		//auditLog.debug("Fault");
}
