#!/usr/bin/env bash

# Configure the gateway host and port and user credentials
#
GW=localhost:8443
GW_USER=admin:password
GW_PASS_B64=cGFzc3dvcmQ=

# Import the folder 'PingIntelligence'
#
curl -k -u $GW_USER -X PUT -H "Content-Type: application/xml" -H "L7-key-passphrase: $GW_PASS_B64" "https://$GW/restman/1.0/bundle" -d @../add-ons/ssg/policies/pingintelligence.bundle

# Import cluster properties that configure the PingIntelligence bundle
#
# ase_host_https
# ase_path_request
# ase_path_response
# ase_host2_https
# ase_path2_request
# ase_path2_response
# ase_request_connection_timeout
# ase_request_read_timeout
# ase_response_connection_timeout
# ase_response_read_timeout
#
curl -k -u $GW_USER -X PUT -H "Content-Type: application/xml" "https://$GW/restman/1.0/bundle" -d @../add-ons/ssg/policies/pingintelligence-properties.bundle