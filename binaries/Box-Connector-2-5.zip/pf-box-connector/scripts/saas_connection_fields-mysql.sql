# Table structure for saas_connection_fields
# ------------------------------------------------------------
DROP TABLE IF EXISTS `saas_connection_fields`;

CREATE TABLE `saas_connection_fields` (
  `SAAS_NAME` varchar(25) NOT NULL,
  `CLIENT_ID` varchar(255) NOT NULL,
  `CLIENT_SECRET` varchar(255) NOT NULL,
  `OAUTH_ACCESS_TOKEN` varchar(255) NOT NULL,
  `OAUTH_REFRESH_TOKEN` varchar(255) NOT NULL,
  `OAUTH_ACCESS_TOKEN_EXP_MILLIS` varchar(255) NOT NULL DEFAULT '0',
  `OAUTH_REFRESH_TOKEN_EXP_MILLIS` varchar(255) NOT NULL DEFAULT '0',
  `DATASTORE` varchar(255) NOT NULL,
   PRIMARY KEY (`SAAS_NAME`,`CLIENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;