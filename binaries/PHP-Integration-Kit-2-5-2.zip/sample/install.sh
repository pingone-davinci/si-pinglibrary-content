#!/bin/bash

CONFIG_DIR=/opt/pingidentity/phpkit/sampleapp/config

function getApacheUser() {
        echo -n "Enter Apache user [$APACHE_USER]: "
        read APACHE_USER
        let ANSWER="y"
}

#check for necessary commands used in this script
if [ -f /bin/ps ] && 
   [ -f /bin/grep ] &&
   [ -f /usr/bin/head ] &&
   [ -f /usr/bin/wc ]; then
	touch -c blah
else
	echo "A necessary command is missing, plese review the PHP_Sample_Application_Startup_Guide.pdf for more details."	
	exit
fi

USER_WORD_COUNT=`ps -C httpd -o user= | grep -v root | head -n 1 | wc -w` 

if [ $USER_WORD_COUNT -gt 1 ] || [ $USER_WORD_COUNT -lt 1 ]; then
	echo "Cannot determine Apache user.  Apache HTTP server must be running."
	exit
else
	APACHE_USER=`ps -C httpd -o user= | grep -v root | head -n 1`
	until [ "$ANSWER" = "y" ] || [ "$ANSWER" = "Y" ] ||
		[ "$ANSWER" = "n" ] || [ "$ANSWER" = "N" ]; do
		echo -n "Apache user is: $APACHE_USER.  Is this correct (Y/N): "
		read ANSWER
	done
	
	if [ "$ANSWER" = "n" ] || [ "$ANSWER" = "N" ]; then
		echo "Unable to detect Apache user, please review PHP_Sample_Application_Startup_Guide.pdf for manual installation instructions."
		exit
	fi

	if [ "$ANSWER" = "y" ] || [ "$ANSWER" = "Y" ]; then

		#create Config directory
		if [ -d $CONFIG_DIR ]; then
			touch -c blah
		else
			mkdir -v -p -m 775 $CONFIG_DIR
			mkdir -v -m 755 $CONFIG_DIR/idp
			mkdir -v -m 755 $CONFIG_DIR/sp
			cp -v $PWD/config/idp/* $CONFIG_DIR/idp
			cp -v $PWD/config/sp/* $CONFIG_DIR/sp
			chown -v $APACHE_USER $CONFIG_DIR/idp/*
			chown -v $APACHE_USER $CONFIG_DIR/sp/*
			chmod -v 644 $CONFIG_DIR/idp/*
			chmod -v 644 $CONFIG_DIR/sp/*
		fi
	fi
fi

echo -n "Enter Apache DocumentRoot: "
read DOCUMENT_ROOT

if [ "$DOCUMENT_ROOT" != "" ] && [ -d $DOCUMENT_ROOT ] && [ -w $DOCUMENT_ROOT ]; then
	mkdir -v -p -m 775 $DOCUMENT_ROOT/sample  
	cp -v -R $PWD/idp $DOCUMENT_ROOT/sample
	cp -v -R $PWD/sp $DOCUMENT_ROOT/sample
	cp -v -R $PWD/common $DOCUMENT_ROOT/sample
	chmod -v -R 755 $DOCUMENT_ROOT/sample
fi
