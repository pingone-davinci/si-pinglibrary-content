<?php

include_once(dirname(__FILE__) . "/Const.php");
include_once(dirname(__FILE__) . "/Config.php");



define("debug", true);



require(dirname(__FILE__) . "/../common/lib/nusoap-0.9.5/lib/nusoap.php");



class DemoAppUtil

{
	
 var $hostPF;	
 var $hostPFidp;
 var $hostPFsp;
 var $config;
 var $hostAppSp;
	
 function __construct() {
 	
 	$this->config = new Config();
 	
 	if($this->config->getProperty(SAMPLE_USE_SSL) == "true")
 	{
 		$this->hostPF = "https://".$this->config->getProperty(SAMPLE_PF_HOST).":".$this->config->getProperty(SAMPLE_PF_HTTPS_PORT); 		
 		$this->hostPFidp = "https://".$this->config->getProperty(SAMPLE_PF_HOST).":".$this->config->getProperty(SAMPLE_PF_HTTPS_PORT).IDP_DIR;
 		$this->hostPFsp = "https://".$this->config->getProperty(SAMPLE_PF_HOST).":".$this->config->getProperty(SAMPLE_PF_HTTPS_PORT).SP_DIR;
 	}
 	else
 	{
 		$this->hostPF = "http://".$this->config->getProperty(SAMPLE_PF_HOST).":".$this->config->getProperty(SAMPLE_PF_HTTP_PORT); 	 		 		
 		$this->hostPFidp = "http://".$this->config->getProperty(SAMPLE_PF_HOST).":".$this->config->getProperty(SAMPLE_PF_HTTP_PORT).IDP_DIR;
 		$this->hostPFsp = "http://".$this->config->getProperty(SAMPLE_PF_HOST).":".$this->config->getProperty(SAMPLE_PF_HTTP_PORT).SP_DIR;
 	}	 		
 }
 

 function getWsClient() {

 	if($this->config->getProperty(SAMPLE_USE_SSL) == "true")
 	{
   $client = new nusoap_client($endpoint='https://'.$this->config->getProperty(SAMPLE_PF_HOST).
   		':'.$this->config->getProperty(SAMPLE_PF_HTTPS_PORT).'/pf-ws/services/SSODirectoryService');

	}
	else
	{
   $client = new nusoap_client($endpoint='http://'.$this->config->getProperty(SAMPLE_PF_HOST).
   		':'.$this->config->getProperty(SAMPLE_PF_HTTP_PORT).'/pf-ws/services/SSODirectoryService');

	}
   

   $client->timeout = 5;

   $client->response_timeout = 5;
   
   if($this->config->getProperty(SAMPLE_PF_WS_UNAME) != null
   	&& $this->config->getProperty(SAMPLE_PF_WS_PWD) != null) {
   		
   		$client->setCredentials($this->config->getProperty(SAMPLE_PF_WS_UNAME),
   		$this->config->getProperty(SAMPLE_PF_WS_PWD),'basic');
   	
   	}



   if (is_a($client, 'nusoap_client')) {

      $err = $client->getError();

      if($err) {

        throw new Exception($err);

      }

   }

   else {

     throw new Exception("Error creating soapclient");

   }



   return $client;

 }



 function getSpList() {



   $client = $this->getWsClient();



   $result = $client->call('getSPList');



   //check for errors other than SOAP faults, i.e. HTTP authentication

   $err = $client->getError();

   if ($err) {

     throw new Exception($err);

   }



   if ($client->fault) {

     throw new Exception("Fault during call");

   }



   return $result;

 }
 
 function getIdpList() {
 
   $client = $this->getWsClient();

   $result = $client->call('getIDPList');

   //check for errors other than SOAP faults, i.e. HTTP authentication
   $err = $client->getError();
   if ($err) {
     throw new Exception($err);
   }

   if ($client->fault) {
     throw new Exception("Fault during call");
   }

   return $result;
 }


 function addParameters($forceAuthn, $isPassive) {

 	//create string with parameters to be added to url
 	$params = null;
 	
 	if($forceAuthn != null && $isPassive == null) {
 		$params = "ForceAuthn=".$forceAuthn;
 	}
    if($forceAuthn == null && $isPassive != null) {
    	$params = "IsPassive=".$isPassive;
    }
    if($forceAuthn != null && $isPassive != null) {
    	$params = "ForceAuthn=".$forceAuthn."&IsPassive=".$isPassive;
    }
    
    return $params;
 }
 
 function getIdpStartSSOLink($partnerSpId, $forceAuthn, $isPassive) {
 	
 	//create url to Pingfederate IdP Start SSO service
 	$url = $this->hostPFidp . START_SSO . "?" . PARTNER_SP_ID . "=" . $partnerSpId;
 	
 	//add ForceAuthn and IsPassive parameters if it is necessary
 	$params = $this->addParameters($forceAuthn, $isPassive);
 	if($params != null) {
 		$url .= "?" . $params;
 	}
    
 	return $url;
 }

 function getSpStartSSOLink($partnerIdpId, $forceAuthn, $isPassive) {
 	
 	//create url to Pingfederate IdP Start SSO service
 	$url = $this->hostPFsp . START_SSO . "?" . PARTNER_IDP_ID . "=" . $partnerIdpId;
 	
 	//add ForceAuthn and IsPassive parameters if it is necessary
 	$params = $this->addParameters($forceAuthn, $isPassive);
 	if($params != null) {
 		$url .= "&" . $params;
 	}
    
 	return $url;
 }
 
 function getSpSLOLink() {
 	//create url to Pingfederate SP Start SLO service
 	$url = $this->hostPFsp + START_SLO + "?" + TARGET_RESOURCE + "=" + hostAppSp + TARGET_SP_SLO;
 	return $url;
 }

 function getAccountTerminationLink() {
 	
 	$url = $this->hostPFsp . START_DEFED;
 	
 	return $url;
 	
 }
 
 function getSpStartSLOLink($serverName) {
 	$url = $this->hostPFsp . START_SLO . "?" . TARGET_RESOURCE . "=" . "http://" . $serverName . $this->config->getProperty(SAMPLE_LOCAL_COOKIE_PATH) .SAMPLE_START_PAGE;
 	return $url;
 }
 
 function getResumeUrl($path) {

 	$url = $this->hostPF . $path;

 	return $url;
 
 }
 
 function getAuthnDisplay($authnContext) {
 	$display = null;
 	if($authnContext == AUTHN_PASSWORD) {
 		$display = AUTHN_PASSWORD_SHORT;
 	}

 	elseif($authnContext == AUTHN_UNSPECIFIED) {

 		$display = AUTHN_UNSPECIFIED_SHORT;

 	}
 	else {
 		$display = $authnContext;
 	}
 	
 	return $display;
  }

}


?>
