<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<?php

spl_autoload_extensions(".php");
spl_autoload_register();

include_once(dirname(__FILE__) . "/DemoAppUtil.php");
include_once(dirname(__FILE__) . "/Const.php");
include_once(dirname(__FILE__) . "/User.php");
include_once(dirname(__FILE__) . "/Config.php");

use pingidentity\opentoken\agent;
use pingidentity\opentoken\helpers\multistringarray;

$users = new User();
$demoAppUtil = new DemoAppUtil();
$config = new Config();

if(isset ($_POST['Login']) && $_POST['Login'] == 'Login') {
	
	if($users->authenticateUser($_POST['userName'], $_POST['password'])) {
		
		if(!isset  ($userInfo)  && $userInfo == null) {
			$userInfo = $users->getUserAttributes($_POST['userName']);
			$userInfo->add("userid", $_POST['userName']);
		}
		
		$resumePath = $_GET['resume'];
		
		//we're in an SSO transaction
		if($resumePath != null) {
			
			$returnUrl = $demoAppUtil->hostPF . $resumePath;
			
			# Construct and use an agent to write a token
        	$agent = new Agent();        	
			
        	$agent_values = new MultiStringArray();
        	$agent_values->add(\pingidentity\opentoken\TOKEN_SUBJECT, $userInfo->get("userid",0));
        	$agent_values->add(\pingidentity\opentoken\AUTHN_CTX_ATTRIBUTE_NAME, $userInfo->get(\pingidentity\opentoken\AUTHN_CTX_ATTRIBUTE_NAME,0));

        	# Write the token; if the agent is in cookie mode, a cookie is written
	        # otherwise, the query parameter that must be appended to the target URL
	        # is returned
	        $queryParam = $agent->writeTokenToHTTPResponse($agent_values);
	        if ($queryParam)
	        {
	            if (strpos($returnUrl, "?") == FALSE)
	            {
	                $returnUrl = $returnUrl . "?";
	
	            }
	
	            $returnUrl = $returnUrl . $queryParam;
	        }
	        
	        # Redirect back to pingfederate
	        header("Location: " . $returnUrl);        
		}
		else {
			header("Location: spmain.php");
		}
	}
	else {
		$error="Account Link Login Failed.";
	}
}

?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8"/>
<?php
include(dirname(__FILE__) . "/scripts.php");
?>
<link rel="stylesheet" href="../common/css/main.css" type="text/css"/>
</head>
<body>
<body class="idp">
<div id="container">
	<div id="left_header">
		<img src="../common/images/spbadge.png" align="middle"/>
	</div>
	<div id="right_header">
		<div id="text" style="clear: both;margin-top: 30px;">Service Provider</div>
	</div>
	<div id="menu">
		<a href="ConfigUI.php">Options</a> |
		<a href="<?php echo SAMPLE_START_PAGE; ?>">Service Provider Home</a> 
	</div>

	<?php
	if(isset ($error) && $error != null) {
	?>
		<div id="errorCenter">
			<?php echo $error; ?>
		</div>
 	<?php
	}
 	?>

	<div id="content">
		<form name="login" method="post">
		<table class="cell" style="margin-left: auto; margin-right: auto;">
			<tr>
				<td colspan=2 style="text-align: center;">
					<h1>Account Link Login</h1>
					<hr class="cell"/>
				</td>
			</tr>
			<tr>
				<td>Username:</td>
				<td>
					<select name="userName">
					<?php
					foreach($users->getUsersNames() as $user) {
					  print '<option>'.$user.'</option>';
					}
					?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Password:</td>
				<td>
					<input type="password" name="password"/>
				</td>
			</tr>
			<tr>
				<td></td>
				<td>
					<input type="submit" name="Login" value="Login"/>
					
				</td>
			</tr>
		</table>
		</form>
	</div>
</div>
</body>
</html>