<?php

define("CONFIG_FILE", "../config/sp/config.properties");

define("SAMPLE_PF_HOST", "hostPF");

define("SAMPLE_TOKEN_TYPE", "tokenType");

define("SAMPLE_CIPHER_SUITE", "cipherSuite");

define("SAMPLE_PASSWORD","tokenPassword");

define("SAMPLE_HOLDER_NAME","holderName");

define("SAMPLE_TRANSFER_METHOD","transferMethod");

define("SAMPLE_IDP_DISCOVERY","idpDiscovery");

define("SAMPLE_ACCOUNT_LINKING","accountLinking");

define("SAMPLE_RAW_DATA","rawData");

define("SAMPLE_ATTRS_NAMES_LIST","attributeNamesList");

define("SAMPLE_PF_HTTP_PORT","httpPort");

define("SAMPLE_PF_HTTPS_PORT","httpsPort");

define("SAMPLE_PF_WS_UNAME","wsUname");

define("SAMPLE_PF_WS_PWD","wsPwd");

define("SAMPLE_LOCAL_COOKIE_PATH","localCookiePath");

define("SAMPLE_START_PAGE","spmain.php");

define("SAMPLE_HTTP_RAW_DATA","showRawHttpData");
define("SAMPLE_USE_SSL","useSSL");
define("USE_SSL_CHECKBOX", SAMPLE_USE_SSL."Checkbox");

define("URL_SHOW_ADVANCED","showAdvanced");

define("URL_LOCAL_LOGOUT","localLogout");

define("URL_RESUME","resume");

define("POST_SAVE","Save");

define("POST_UPLOAD","Upload");

define("IDP_DISCOVERY_CHECKBOX", SAMPLE_IDP_DISCOVERY."Checkbox");

define("ACCOUNT_LINKING_CHECKBOX", SAMPLE_ACCOUNT_LINKING."Checkbox");

define("OPT_OPEN_TOKEN","OpenToken");

define("OPT_STANDARD", "Standard");

define("OPT_NULL","0");

define("OPT_AES_256","1");

define("OPT_AES_128","2");

define("OPT_3DES_168","3");

define("START_SSO","/startSSO.ping");

define("START_SLO","/startSLO.ping");

define("START_DEFED","/defederate.ping");

define("IDP_DIR","/idp");

define("SP_DIR","/sp");

define("PARTNER_SP_ID","PartnerSpId");

define("PARTNER_IDP_ID","PartnerIdpId");

define("TARGET_RESOURCE","TargetResource");

define("TARGET_SP_SLO","/"); 

define("BASIC_AUTH", "basic" );

define("USER_FILE", "users.xml");

define("AUTHN_PASSWORD", "urn:oasis:names:tc:SAML:2.0:ac:classes:Password");

define("AUTHN_UNSPECIFIED", "urn:oasis:names:tc:SAML:2.0:ac:classes:unspecified");

define("AUTHN_PASSWORD_SHORT","PASSWORD");

define("AUTHN_UNSPECIFIED_SHORT","UNSPECIFIED");
?>