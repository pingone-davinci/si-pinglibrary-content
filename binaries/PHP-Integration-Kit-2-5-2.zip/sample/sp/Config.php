<?php


include_once(dirname(__FILE__) . "/Const.php");
include_once(dirname(__FILE__) . "/pingidentity/opentoken/helpers/keyvalueserializer.php");
include_once(dirname(__FILE__) . "/pingidentity/opentoken/helpers/multistringarray.php");

use pingidentity\opentoken\helpers\keyvalueserializer;
use pingidentity\opentoken\helpers\multistringarray;

class Config {

  var $config;

  function __construct() {
    // open the config file and read its contents
    $config_data = file_get_contents(CONFIG_FILE);
    $this->config = KeyValueSerializer::deserialize($config_data);
  }

  function getProperty($key) {
    // set the various instance variables
    if ($this->config->containsKey($key)) {
      return trim($this->config->get($key,0));
    }
    
    return null;
  }
  
  function setProperty($key, $value) {
  	$this->config->remove($key);
  	$this->config->add($key, $value);
  }
  
  function removeProperty($key) {
  	$this->config->remove($key);
  }
  
  function save() {
    $data = KeyValueSerializer::serialize($this->config);
    return file_put_contents(CONFIG_FILE, $data);
  }
}

?>