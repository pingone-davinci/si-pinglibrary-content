<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<?php

spl_autoload_extensions(".php");
spl_autoload_register();

use pingidentity\opentoken\agent;
use pingidentity\opentoken\helpers\multistringarray;
include_once(dirname(__FILE__) . "/DemoAppUtil.php");
include_once(dirname(__FILE__) . "/Const.php");
include_once(dirname(__FILE__) . "/Config.php");


$opentoken_subject = null;         // the authenticated subject (user)
$opentoken_haveValidToken = false; // set to true if the token was valid
$opentoken_lastError = null; // contains a string describing any open token errors
$opentoken_values = null; // contains an array of all the token values
$opentoken_valuesMultiStringArray = null;

// code begins here

$opentoken_agent = new Agent();
$opentoken_values = $opentoken_agent->readTokenFromHTTPRequest();
$opentoken_valuesMultiStringArray = $opentoken_agent->readTokenFromHTTPRequestToMultiStringArray();

if ($opentoken_values != null || $opentoken_valuesMultiStringArray != null) {
    $opentoken_haveValidToken = true;
    $opentoken_subject = $opentoken_values[\pingidentity\opentoken\TOKEN_SUBJECT];
}

$opentoken_lastError = $opentoken_agent->lastError;


ob_start();
header("Cache-Control","no-cache");
header("Pragma","no-cache");
header("Expires","0");

$config = new Config();
session_set_cookie_params (0, $config->getProperty(SAMPLE_LOCAL_COOKIE_PATH));
session_start();


$demoAppUtil = new DemoAppUtil();

if (isset ($_GET[URL_SHOW_ADVANCED]))
	$showAdvanced = $_GET[URL_SHOW_ADVANCED];
if (isset ($_GET[URL_LOCAL_LOGOUT]))
	$localLogout = $_GET[URL_LOCAL_LOGOUT];
if (isset ($_GET[URL_RESUME]))	
	$resume = $_GET[URL_RESUME];

if(isset ($localLogout) && $localLogout == "true") {
	
	session_destroy();
	ob_end_clean();
	
	if(isset ($resume)  && $resume != null) {
		header("Location: " . $demoAppUtil->getResumeUrl($resume));
	}
	else {
		header("Location: spmain.php");
	}
}


if($opentoken_haveValidToken) {

	$agent = new Agent();

	$values = $agent->readTokenFromHTTPRequestToMultiStringArray();

	#$values = $opentoken_agent->readTokenFromHTTPRequestToMultiStringArray();

	if (!$values) {

		$values = $_SESSION['values'];

	}

	else {

		$_SESSION['values'] = $values;

		$message = "Successfully logged in via SSO";

	}

}

else{
	//discard no token found mesages, these are normal
	$error = (strpos($opentoken_lastError, "token found") == false ? $opentoken_lastError : null);

	if (isset ($_SESSION['values']))
		$values = $_SESSION['values'];
	else 
		$values  = '';
}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8"/>

<title>Service Provider</title>
<?php
include(dirname(__FILE__) . "/scripts.php");
?>
<link rel="stylesheet" href="../common/css/main.css" type="text/css"/>
</head>
<body class="sp">

<?php

try {

  $idps = $demoAppUtil->getIdpList();

}

catch(Exception $e) {

  $error = "This sample application requires PingFederate to be running in order to retreive a list of configured connections.  Please check to make sure your server is online.";

}

?>
<div id="container">
	<div id="left_header">
		<img src="../common/images/spbadge.png" align="middle"/>
	</div>
	<div id="right_header">
		<div id="text" style="clear: both;margin-top: 30px;">Service Provider</div>
	</div>
	<div id="menu">
		<a href="ConfigUI.php">Options</a>
		<?php
		if($values != null && $config->getProperty(SAMPLE_ACCOUNT_LINKING) == "true") {
		?>
			| <a href="<?php echo $demoAppUtil->getAccountTerminationLink(); ?>">Terminate Account Link</a>
		<?php
		}
		?><?php
		if($values != null) {
		?>
			| <a href="?localLogout=true">Local Logout</a>
		<?php
		}
		?>
	</div>

	<?php
	if(isset ($message) && $message != null) {
	?>
	<div id="messageCenter">
		<?php echo $message; ?>
	</div>
 	<?php
	}
 	?>


	<?php
	if(isset ($error) && $error != null) {
	?>
 	<div id="errorCenter">

		<?php echo $error; ?>

	</div>

 	<?php

	}

 	?>

	<div id="content">
	<?php
		if($values != null) {
		?>
			<table style="float: left;" class="cell">
				<tr>
					<td colspan=2 style="text-align: center;">
						<h1>User Attributes</h1>
						<hr class="cell"/>
					</td>
				</tr>
				<?php
				$i = 0;
				if(is_a($values, 'pingidentity\opentoken\helpers\multistringarray')) {
					foreach($values->keySet() as $key) {
						foreach($values->get($key) as $value) {
							$i++;
							print "<tr><td class=\"d".($i&1)."\">".$key."</td><td class=\"d".($i&1)."\">".$demoAppUtil->getAuthnDisplay($value)."</td></tr>";
						}
					}
				}
				else {
					foreach($values as $key => $value) {
						$i++;
						print "<tr><td class=\"d".($i&1)."\">".$key."</td><td class=\"d".($i&1)."\">".$demoAppUtil->getAuthnDisplay($value)."</td></tr>";
					}
				}	
				?>
			</table>
		<?php 
		}
		else {
		?>
			<table style="float: left;" class="cell" id="doot">
				<tr>
					<td colspan=2 style="text-align: center;">
						<h1>User Attributes</h1>
						<hr class="cell"/>
					</td>
				</tr>
				<tr><td class="error">No user attributes since you're not logged in.  Use Single Sign-On to login to the Service Provider application.</td></tr>
			</table>
		<?php
		}
		?>
		<form id="form" method="post">
		<table style="float: right;" class="cell">
			<tr>
				<td colspan=2 style="text-align: center;">
					<h1>SSO Activities</h1>
					<hr class="cell"/>
				</td>
			</tr>
			<tr>
				<td>SP:</td>
				<td>
					<select name="PartnerIdpId" id ="PartnerIdpId">
					<?php
					foreach($idps as $key=>$idpMeta) {
					  print '<option value="'.$demoAppUtil->getSpStartSSOLink($idpMeta['entityId'], isset ($_POST['ForceAuthn']) && $_POST['ForceAuthn'] == "on" ? "true" : null, isset ($_POST['IsPassive']) && $_POST['IsPassive'] == "on" ? "true" : null).'">'.$idpMeta['entityId'].'</option>';
					}
					?>
					</select>
				</td>
			</tr>
			<?php
			if(isset ($showAdvanced) && $showAdvanced == "true") {
				?>
				<tr><td>Target URL:</td><td><input name="TargetResource" id="TargetResource"/></td></tr>
				<tr><td>IsPassive:</td><td><input type="checkbox" name="IsPassive" id="IsPassive" <?php echo (  isset ($_POST['IsPassive']) && $_POST['IsPassive'] == "on" ? "checked" : ""); ?> onclick="document.getElementById('form').submit()"/></td></tr>
				<tr><td>ForceAuthn:</td><td><input type="checkbox" name="ForceAuthn" id="ForceAuthn" <?php echo ( isset($_POST['ForceAuthn']) && $_POST['ForceAuthn'] == "on" ? "checked" : ""); ?> onclick="document.getElementById('form').submit()"/></td></tr>
				<?php
			}
			?>
			<?php
			if(isset ($showAdvanced) && $showAdvanced == "true") {
				?><tr><td></td><td><a href="?<?php echo URL_SHOW_ADVANCED;?>=false">Hide advanced options</a></td></tr><?php
			}
			else {
				?><tr><td></td><td><a href="?<?php echo URL_SHOW_ADVANCED;?>=true">Show advanced options</a></td></tr><?php
			}
			?>
			<tr><td>SSO Link:</td><td><input id="ssolink" readonly="readonly"/><a href="javascript:createSSOLink();">create</a></td></tr>
			<tr><td></td><td><input type="button" value=" Single Sign-On " OnClick="javascript:initiateSSO()"/></td></tr>
			<?php
			if($values != null) {
			?>
			<tr>
				<td>
				SLO Link:
				</td>
				<td>
					<input type="hidden" id="hiddenslolink" value="<?php echo $demoAppUtil->getSpStartSLOLink($_SERVER['HTTP_HOST']); ?>" />
					<input id="slolink" readonly="readonly"/><a href="javascript:createSLOLink();">create</a>
				<td>
			</tr>
			<tr>
				<td></td><td><input type="button" value=" Single Logout " OnClick="javascript:initiateSLO()"/></td>
			</tr>
			<?php
		}
		?>
		</table>
		</form>
	</div>
</div>
</body>
</html>
