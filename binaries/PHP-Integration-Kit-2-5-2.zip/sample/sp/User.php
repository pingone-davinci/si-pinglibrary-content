<?php

include_once(dirname(__FILE__) . "/Const.php");
include_once(dirname(__FILE__) . "/pingidentity/opentoken/helpers/multistringarray.php");
use pingidentity\opentoken\helpers\multistringarray;
class User {

  var $xml_user_data;

  function __construct() {
  
  	$user_data = file_get_contents(USER_FILE);
  	$this->xml_user_data = new SimpleXMLElement($user_data); 
  	
  }
  
  function getUsersNames() {
  	$users = array();
  	foreach ($this->xml_user_data->user as $user) {
    	array_push($users, (string)$user['name']);
  	}
  	return $users;
  }
  
  function getUserAttribute($userName, $attributeName) {
  	foreach ($this->xml_user_data->user as $user) {
    	if($userName == (string)$user['name']) {
    		foreach($user->attributes->attribute as $attribute) {
    			if($attributeName == (string)$attribute['name']) {

    				$values = array();
    				
    				foreach($attribute->children() as $value){
    					array_push($values, $value);	
    				}
    				
    				return $values;
    			}
    		}
    	}
  	}
  }
  
  function getUserAttributes($userName) {
  	
  	$attributes = new MultiStringArray();
  	
  	foreach ($this->xml_user_data->user as $user) {
    	if($userName == (string)$user['name']) {
    		foreach($user->attributes->attribute as $attribute) {
    			foreach($attribute->children() as $value){
    				$attributes->add($attribute['name'], $value);
    			}
    		}
    	}
  	}

  	
  	return $attributes;
  }
  
  function authenticateUser($userName, $password) {
  	
  	$passwordArray = $this->getUserAttribute($userName, "password");
  	
  	if($password == $passwordArray[0]) {
  		return true;
  	}
  	
  	return false;
  }
}

?>