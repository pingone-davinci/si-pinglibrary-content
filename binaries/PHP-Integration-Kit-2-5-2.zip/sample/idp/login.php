<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<?php

spl_autoload_extensions(".php");
spl_autoload_register();

use pingidentity\opentoken\agent;
use pingidentity\opentoken\helpers\multistringarray;
use pingidentity\opentoken\helpers\token;
use pingidentity\opentoken\helpers\keyvalueserializer;

include_once(dirname(__FILE__) . "/DemoAppUtil.php");
include_once(dirname(__FILE__) . "/Const.php");
include_once(dirname(__FILE__) . "/Config.php");
include_once(dirname(__FILE__) . "/User.php");


$demoAppUtil = new DemoAppUtil();
$config = new Config();
$users = new User();

ob_start();
session_set_cookie_params (0, $config->getProperty(SAMPLE_LOCAL_COOKIE_PATH));
session_start();


if (!isset($_GET['ForceAuthn']))
{
    //If not isset -> set with dumy value
    $_GET['ForceAuthn'] = null;
}

if (!isset($_SESSION['userInfo']))
{
    //If not isset -> set with dumy value
    $_SESSION['userInfo'] = null;
}

if($_GET['ForceAuthn'] != "true") {
    $userInfo = $_SESSION['userInfo'];
}



if (isset($_GET['error']))
    $error = $_GET['error'];

if (isset($_GET['resume']))
    $resumePath = $_GET['resume'];
else
	$resumePath = '';


$returnUrl = $demoAppUtil->hostPF . $resumePath;

if (!isset ($userInfo))
   $userInfo = null;


if(is_null($userInfo) && isset($_GET['IsPassive']) && $_GET['IsPassive'] == "true") {
    # Redirect back to pingfederate
    header("Location: " . $returnUrl);
}

if(isset ($_POST['Login']) &&  $_POST['Login'] == 'Login' || !is_null($userInfo)) {

    if($users->authenticateUser($_POST['userName'], $_POST['password']) || !is_null($userInfo)) {

        if($userInfo == null) {
            $userInfo = $users->getUserAttributes($_POST['userName']);
            $userInfo->add("userid", $_POST['userName']);
            $_SESSION['userInfo'] = $userInfo;
        }

        ob_end_clean();

        //we're in an SSO transaction
        if(isset($resumePath) &&  $resumePath != null) {

            # Construct and use an agent to write a token
            $agent = new pingidentity\opentoken\Agent();

            $agent_values = new  pingidentity\opentoken\helpers\multistringarray();
            $agent_values->add(pingidentity\opentoken\TOKEN_SUBJECT, $userInfo->get("userid",0));
            $agent_values->add(pingidentity\opentoken\AUTHN_CTX_ATTRIBUTE_NAME, $userInfo->get(pingidentity\opentoken\AUTHN_CTX_ATTRIBUTE_NAME,0));
            $agent_values->add("email", $userInfo->get("email", 0));
            $agent_values->add("email", $userInfo->get("email", 1));

            # Write the token; if the agent is in cookie mode, a cookie is written
            # otherwise, the query parameter that must be appended to the target URL
            # is returned
            $queryParam = $agent->writeTokenToHTTPResponse($agent_values);
            if ($queryParam)
            {
                if (strpos($returnUrl, "?") == FALSE)
                {
                    $returnUrl = $returnUrl . "?";

                }

                $returnUrl = $returnUrl . $queryParam;
            }

            # Redirect back to pingfederate
            header("Location: " . $returnUrl);
        }
        else {
            header("Location: idpmain.php?message=Successfully%20Logged%20In%20Locally");
        }
    }
    else {
        $error = "Local Login Failed.";
    }
}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv=Content-Type content="text/html; charset=utf-8"/>
    <?php
    include(dirname(__FILE__) . "/scripts.php");
    ?>
    <link rel="stylesheet" href="../common/css/main.css" type="text/css"/>
</head>
<body class="idp">
<div id="container">
    <div id="left_header">
        <img src="../common/images/idpbadge.png" align="middle"/>
    </div>
    <div id="right_header">
        <div id="text" style="clear: both;margin-top: 30px;">Identity Provider</div>
    </div>
    <div id="menu">
        <a href="ConfigUI.php">Options</a> |
        <a href="<?php echo SAMPLE_START_PAGE; ?>">Identity Provider Home</a>
    </div>

    <?php
    if(isset($error) && $error != null) {
        ?>
        <div id="errorCenter">
            <?php echo $error; ?>
        </div>
        <?php
    }
    ?>

    <div id="content">
        <form name="login" method="post">
            <table class="cell" style="margin-left: auto; margin-right: auto;">
                <tr>
                    <td colspan=2 style="text-align: center;">
                        <h1>Local Login</h1>
                        <hr class="cell"/>
                    </td>
                </tr>
                <tr>
                    <td>Username:</td>
                    <td>
                        <select name="userName">
                            <?php
                            foreach($users->getUsersNames() as $user) {
                                print '<option>'.$user.'</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Password:</td>
                    <td>
                        <input type="password" name="password"/>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <?php if (isset($resume)) { ?>
                        <input type="hidden" name="resume" value='<?php echo $resume; ?>'/>
                        <?php
                        } else
                        ?>


                        <input type="hidden" name="resume" value='<?php ?>'/>
                        <?php

                        ?>

                        <input type="submit" name="Login" value="Login"/>

                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>