<?php
namespace pingidentity\opentoken\helpers;
/**
 * Edit this variable to point to the absolute path of the
 * configuration file you received from the PingFederate
 * administrator for each of the IdP and Sp applications.
 * 
 * @package opentoken
 */

class config {

    const   AGENT_CONFIG_FILE = "../config/idp/agent-config.txt";
}
?>