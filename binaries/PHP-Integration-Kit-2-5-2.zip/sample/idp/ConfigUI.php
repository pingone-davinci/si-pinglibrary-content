<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<?php
include_once(dirname(__FILE__) . "/Const.php");
include_once(dirname(__FILE__) . "/Config.php");
include_once(dirname(__FILE__) . "/pingidentity/opentoken/helpers/config.php");

$config = new Config();

if (isset ($_GET[URL_SHOW_ADVANCED]))
	$showAdvanced = $_GET[URL_SHOW_ADVANCED];
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8"/>
<link rel="stylesheet" href="../common/css/main.css" type="text/css"/>
<?php
include(dirname(__FILE__) . "/scripts.php");
?>
</head>
<body>
<?php
if( isset ($_POST[POST_SAVE]) && $_POST[POST_SAVE] == POST_SAVE) {

  foreach($_POST as $key=>$value) {
  	if($_POST[$key] != null && $_POST[$key] != POST_SAVE && $key != IDP_DISCOVERY_CHECKBOX && $key != USE_SSL_CHECKBOX) {

    	$config->setProperty($key, $value);
  	}
  	else {
  		$config->removeProperty($key);
  	}

  }

  if($config->save()) {
  	$message ="Configuration Options Saved";
  }
  else {
  	$error = "Error saving Configuration Options.  Check that the file is writable by the web server.";
  }

}
elseif(isset($_POST[POST_UPLOAD])  &&  $_POST[POST_UPLOAD] == POST_UPLOAD ) {
  
  if(count($_FILES) > 0 && $_FILES['file']['name'] != null) {
	 
	  if(move_uploaded_file($_FILES['file']['tmp_name'], \pingidentity\opentoken\helpers\config:: AGENT_CONFIG_FILE)) {
	    $message = "The file ".  basename( $_FILES['file']['name']). 
	    " has been uploaded.";
	  } else{
	    $error = "There was an error uploading the file, please try again.";
	  }
  }
  else {
  	$error = "No file provided for upload.";
  }
}
?>
<div id="container">
	<div id="left_header">
		<img src="../common/images/idpbadge.png" align="middle"/>
	</div>
	<div id="right_header">
		<div id="text" style="clear: both;margin-top: 30px;">Identity Provider</div>
	</div>
	<div id="menu"> 
		<a href="<?php echo SAMPLE_START_PAGE; ?>">Identity Provider Home</a> 
	</div>
	
	<?php
	if(isset ($message) && $message != null) {
	?>
		<div id="messageCenter">
			<?php echo $message; ?>
		</div>
 	<?php
	}
 	?>
 	
	<?php
	if(isset ($error) && $error != null) {
	?>
 	<div id="errorCenter">
		<?php echo $error; ?>
	</div>
 	<?php
	}
 	?>

	<div id="content">
	<form name="config" method="post">
		<table class="cell" style="margin-left: auto; margin-right: auto;">
			<tr>
				<td colspan=2 style="text-align: center;">
					<h1>Configuration Options</h1>
					<hr class="cell"/>
				</td>
			</tr>
			<tr><td>PF Host Name:</td><td><input name="<?php echo SAMPLE_PF_HOST;?>" value="<?php echo $config->getProperty(SAMPLE_PF_HOST);?>"/></td></tr>
		
			<!--<tr><td>Adapter Type:</td><td>
			<?php
			print '<select name="'.SAMPLE_TOKEN_TYPE.'">';
			print '<option value="'.OPT_OPEN_TOKEN.'" '.($config->getProperty(SAMPLE_TOKEN_TYPE)==OPT_OPEN_TOKEN ? 'selected' : '').'>'.OPT_OPEN_TOKEN.'</option>';
			print '<option value="'.OPT_STANDARD.'" '.($config->getProperty(SAMPLE_TOKEN_TYPE)==OPT_STANDARD ? 'selected' : '').'>'.OPT_STANDARD.'</option>';
			print '</select>';
			?>
			</td></tr>-->
		
			<?php
			if(isset ($showAdvanced)  && $showAdvanced == "true") {
				?>
				<!--
				<tr><td>
				IdP Discovery:</td><td><input type="checkbox" name="<?php echo IDP_DISCOVERY_CHECKBOX; ?>" <?php echo ($config->getProperty(SAMPLE_IDP_DISCOVERY) == "true" ? 'checked' : '')  ?> onclick="toggleBoolean('<?php echo SAMPLE_IDP_DISCOVERY; ?>');"/>
				<input type="hidden" id="<?php echo SAMPLE_IDP_DISCOVERY; ?>" name="<?php echo SAMPLE_IDP_DISCOVERY; ?>" value="<?php echo ($config->getProperty(SAMPLE_IDP_DISCOVERY) == "true" ? 'true' : 'false')?>"/>
				</td></tr>
				-->
				
				<tr>
					<td>Use SSL:</td>
					<td>
						<input type="checkbox" name="<?php echo USE_SSL_CHECKBOX; ?>" <?php echo ($config->getProperty(SAMPLE_USE_SSL) == "true" ? 'checked' : '')  ?> onclick="toggleBoolean('<?php echo SAMPLE_USE_SSL; ?>');"/>
						<input type="hidden" id="<?php echo SAMPLE_USE_SSL; ?>" name="<?php echo SAMPLE_USE_SSL; ?>" value="<?php echo ($config->getProperty(SAMPLE_USE_SSL) == "true" ? 'true' : 'false')?>"/>
					</td>
				</tr>
				<tr><td>PF HTTP Port:</td><td><input name="<?php echo SAMPLE_PF_HTTP_PORT;?>" value ="<?php echo $config->getProperty(SAMPLE_PF_HTTP_PORT);?>" /></td></tr>
				<tr><td>PF HTTPS Port:</td><td><input name="<?php echo SAMPLE_PF_HTTPS_PORT;?>" value ="<?php echo $config->getProperty(SAMPLE_PF_HTTPS_PORT);?>" /></td></tr>
				<tr><td>PF Web Service Username:</td><td><input name="<?php echo SAMPLE_PF_WS_UNAME;?>" value ="<?php echo $config->getProperty(SAMPLE_PF_WS_UNAME);?>" /></td></tr>
				<tr><td>PF Web Service Password:</td><td><input name="<?php echo SAMPLE_PF_WS_PWD;?>" value ="<?php echo $config->getProperty(SAMPLE_PF_WS_PWD);?>" /></td></tr>
				<tr><td>Local Cookie Path:</td><td><input name="<?php echo SAMPLE_LOCAL_COOKIE_PATH;?>" value ="<?php echo $config->getProperty(SAMPLE_LOCAL_COOKIE_PATH);?>" /></td></tr>
				<!--<tr><td>Cipher Suite:</td><td>
				<?php
				print '<select name="'.SAMPLE_CIPHER_SUITE.'">';
				print '<option value="'.OPT_AES_128.'" '.($config->getProperty(SAMPLE_CIPHER_SUITE)==OPT_AES_128 ? 'selected' : '').'>AES-128/CBC</option>';
				print '<option value="'.OPT_AES_256.'" '.($config->getProperty(SAMPLE_CIPHER_SUITE)==OPT_AES_256 ? 'selected' : '').'>AES-256/CBC</option>';
				print '<option value="'.OPT_3DES_168.'" '.($config->getProperty(SAMPLE_CIPHER_SUITE)==OPT_3DES_168 ? 'selected' : '').'>3DES-168/CBC</option>';
				print '<option value="'.OPT_NULL.'" '.($config->getProperty(SAMPLE_CIPHER_SUITE)==OPT_NULL ? 'selected' : '').'>Null</option>';
				print '</select>';
				?>
				</td></tr>-->
				<?php
			}
			?>
			<?php
			if(isset ($showAdvanced) && $showAdvanced == "true") {
				?><tr><td></td><td><a href="?<?php echo URL_SHOW_ADVANCED;?>=false">Hide advanced options</a></td></tr><?php
			}
			else {
				?><tr><td></td><td><a href="?<?php echo URL_SHOW_ADVANCED;?>=true">Show advanced options</a></td></tr><?php
			}
			?>
			<tr><td/><td><input type="submit" name="<?php echo POST_SAVE;?>" value="<?php echo POST_SAVE; ?>"/></td></tr>
		</table>
	</form>
	<form enctype="multipart/form-data" name="fileUpload" method="post">
		<table class="cell" style="margin-left: auto; margin-right: auto;">
			<tr><td>Adapter Properties File:</td><td><input type="file" name="file"/></td></tr>
			<tr><td></td><td><input type="submit" value="<?php echo POST_UPLOAD; ?>" name="<?php echo POST_UPLOAD; ?>"/></td></tr>
		</table>
	</form>
	</div>
</div>
</body>
</html>