<script type="text/javascript">
function initiateSSO(url) {
	window.location = url;
}

function initiateSSO() {
	url = document.getElementById('PartnerSpId').value;
	if(document.getElementById('TargetResource') != null) {
		if(document.getElementById('TargetResource').value != "") {
			url += "&TargetResource=";
			url += document.getElementById('TargetResource').value;
		}
	}
	if(document.getElementById('Binding') != null) {
		if(document.getElementById('Binding').value != "") {
			url += "&Binding=";
			url += document.getElementById('Binding').value;
		}			
	}
	if(document.getElementById('RequestedFormat') != null) {
		if(document.getElementById('RequestedFormat').value != "") {
			url += "&RequestedFormat=";
			url += document.getElementById('RequestedFormat').value;
		}						
	}
	window.location = url;
}

function createSSOLink() {
	url = document.getElementById('PartnerSpId').value;
	if(document.getElementById('TargetResource') != null) {
		if(document.getElementById('TargetResource').value != "") {
			url += "&TargetResource=";
			url += document.getElementById('TargetResource').value;
		}
	}
	if(document.getElementById('Binding') != null) {
		if(document.getElementById('Binding').value != "") {
			url += "&Binding=";
			url += document.getElementById('Binding').value;
		}			
	}
	if(document.getElementById('RequestedFormat') != null) {
		if(document.getElementById('RequestedFormat').value != "") {
			url += "&RequestedFormat=";
			url += document.getElementById('RequestedFormat').value;
		}						
	}			
	document.getElementById('ssolink').value = url;
	document.getElementById('ssolink').select();
	copyToClipboard(document.getElementById('ssolink').value);
}		

function initiateSLO() {
	url = document.getElementById('hiddenslolink').value;
	window.location = url;
}		

function createSLOLink() {
	document.getElementById('slolink').value = document.getElementById('hiddenslolink').value;
	document.getElementById('slolink').select();
	copyToClipboard(document.getElementById('slolink').value);
}

function toggleBoolean(elementIdName) {
	var element = document.getElementById(elementIdName);
	if(element.value == "true") {
		element.value = "false";
	}
	else {
		element.value = "true";
	}
}
</script>			