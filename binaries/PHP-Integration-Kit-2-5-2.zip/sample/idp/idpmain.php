<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<?php
include_once(dirname(__FILE__) . "/DemoAppUtil.php");
include_once(dirname(__FILE__) . "/Const.php");
include_once(dirname(__FILE__) . "/Config.php");

ob_start();
header("Cache-Control","no-cache");
header("Pragma","no-cache");
header("Expires","0");

$config = new Config();
session_set_cookie_params (0, $config->getProperty(SAMPLE_LOCAL_COOKIE_PATH));
session_start();

$demoAppUtil = new DemoAppUtil();

if (isset($_GET[URL_SHOW_ADVANCED]))
    $showAdvanced = $_GET[URL_SHOW_ADVANCED];

if (isset($_GET[URL_LOCAL_LOGOUT]))
    $localLogout = $_GET[URL_LOCAL_LOGOUT];

if (isset ($_GET['message']))
	$message = $_GET['message'];

if (isset($_GET[URL_RESUME]))
    $resume = $_GET[URL_RESUME];

if (isset($_SESSION['userInfo']))
	$userInfo = $_SESSION['userInfo'];
	else 
	$userInfo = null;

if(isset($localLogout) && $localLogout == "true") {
    session_destroy();
    ob_end_clean();

    if(isset ($resume ) && $resume != null) {
        header("Location: " . $demoAppUtil->getResumeUrl($resume));
    }
    else {
        header("Location: idpmain.php?message=Successfully%20Logged%20Out%20");
    }
}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Identity Provider</title>
    <meta http-equiv=Content-Type content="text/html; charset=utf-8"/>
    <?php
    include(dirname(__FILE__) . "/scripts.php");
    ?>
    <link rel="stylesheet" href="../common/css/main.css" type="text/css"/>
</head>
<body>
<?php
try {
    $sps = $demoAppUtil->getSpList();
}
catch(Exception $e) {
    $error = "This sample application requires PingFederate to be running in order to retreive a list of configured connections.  Please check to make sure your server is online.";
}
?>
<div id="container">
    <div id="left_header">
        <img src="../common/images/idpbadge.png" align="middle"/>
    </div>
    <div id="right_header">
        <div id="text" style="clear: both;margin-top: 30px;">Identity Provider</div>
    </div>
    <div id="menu">
        <a href="ConfigUI.php">Options</a>
        <?php
        if($userInfo != null) {
            ?>
            | <a href="?localLogout=true">Local Logout</a>
            <?php
        }
        else {
            ?>
            | <a href="login.php">Login Locally</a>
            <?php
        }
        ?>
    </div>

    <?php
    if(isset ($message) && $message != null) {
        ?>
        <div id="messageCenter">
            <?php echo $message; ?>
        </div>
        <?php
    }
    ?>

    <?php
    if(isset($error) && $error != null) {
        ?>
        <div id="errorCenter">
            <?php echo $error; ?>
        </div>
        <?php
    }
    ?>

    <div id="content">
        <?php
        if($userInfo != null) {
            ?>
            <table style="float: left;" class="cell">
                <tr>
                    <td colspan=2 style="text-align: center;">
                        <h1>User Attributes</h1>
                        <hr class="cell"/>
                    </td>
                </tr>
                <?php
                $i = 0;
                foreach($userInfo->keySet() as $key){
                    foreach($userInfo->get($key) as $value){
                        $i++;
                        print "<tr><td class=\"d".($i&1)."\">".$key."</td><td class=\"d".($i&1)."\">".$demoAppUtil->getAuthnDisplay($value)."</td></tr>";
                    }
                }
                ?>
            </table>
            <?php
        }
        else {
            ?>
            <table style="float: left;" class="cell" id="doot">
                <tr>
                    <td colspan=2 style="text-align: center;">
                        <h1>User Attributes</h1>
                        <hr class="cell"/>
                    </td>
                </tr>
                <tr><td class="error">Not logged in locally to IdP</td></tr>
            </table>
            <?php
        }
        ?>
        <form>
            <table style="float: right;" class="cell">
                <tr>
                    <td colspan=2 style="text-align: center;">
                        <h1>SSO Activities</h1>
                        <hr class="cell"/>
                    </td>
                </tr>
                <tr>
                    <td>SP:</td>
                    <td>
                        <select name="PartnerSpId" id ="PartnerSpId">
                            <?php
                            foreach($sps as $key=>$spMeta) {
                                print '<option value="'.$demoAppUtil->getIdpStartSSOLink($spMeta['entityId'],null,null).'">'.$spMeta['entityId'].'</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <?php
                if(isset($showAdvanced) && $showAdvanced == "true") {
                    ?>
                    <tr>
                        <td>Target URL:</td>
                        <td><input name="TargetResource" id="TargetResource"/></td>
                    </tr>
                    <?php
                }
                ?>
                <?php
                if(isset($showAdvanced) && $showAdvanced == "true") {
                    ?>
                    <tr>
                        <td></td>
                        <td><a href="?<?php echo URL_SHOW_ADVANCED;?>=false">Hide advanced options</a></td>
                    </tr>
                    <?php
                }
                else {
                    ?>
                    <tr>
                        <td></td>
                        <td><a href="?<?php echo URL_SHOW_ADVANCED;?>=true">Show advanced options</a></td>
                    </tr>
                    <?php
                }
                ?>
                <tr><td>SSO Link:</td><td><input id="ssolink" readonly="readonly"/><a href="javascript:createSSOLink();">create</a></td></tr>
                <tr><td></td><td><input type="button" value=" Single Sign-On " OnClick="javascript:initiateSSO()"/></td></tr>
                <tr>
                    <td>
                        SLO Link:
                    </td>
                    <td>
                        <input type="hidden" id="hiddenslolink" value="<?php echo $demoAppUtil->getIdpStartSLOLink($_SERVER['HTTP_HOST']); ?>" />
                        <input id="slolink" readonly="readonly"/><a href="javascript:createSLOLink();">create</a>
                    <td>
                </tr>
                <tr>
                    <td></td><td><input type="button" value=" Single Logout " OnClick="javascript:initiateSLO()"/></td>
                </tr>
            </table>
        </form>
    </div>
</div>
</body>
</html>