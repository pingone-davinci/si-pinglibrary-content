  if (context.getVariable("PingAuth.calloutResponse.status.code") == 429) {
    context.setVariable("PingAuth.faultResponse.header.Retry-After", "1");
    context.setVariable("PingAuth.fault.payload",
        "{\n"
        + " \"code\": \"LIMIT_EXCEEDED\",\n"
        + " \"message\": \"The request exceeded the allowed rate limit. Please try after 1 second.\"\n"
        + "}");
    context.setVariable("PingAuth.fault.statusCode", 429);
    context.setVariable("PingAuth.fault.reasonPhrase", "Too Many Requests");
  } else {
    var calloutResponse = context.getVariable("PingAuth.calloutResponse");
    var sidebandResponse = JSON.parse(calloutResponse.content);
    var debug = (properties.debug == "true");

    try {
      if (debug) {
        print("PING AUTH received response from policy provider ",
            JSON.stringify(sidebandResponse));
      }

      if (sidebandResponse.response) {
        // Raise a fault if `response` is set as that means to abort the flow.
        // This is a server generated error.
        // We'll take the headers from Ping, convert them and turn them into
        //  denyResponseHeaders, and then go through those and set them on the
        //  faultResponse object.

        // The raise fault policy doesn't support dynamic headers,
        // but it can copy from a source message. So set the headers
        // in the initialized empty PingAuth.faultMessage.
        // Per docs, sets each multivalued header value using header.name.1, header.name.2, ...
        // and sets the single value as header.name = value.
        var denyResponseHeaders = convertServerSideErrorHeadersFromPing(
            sidebandResponse.response.headers);
        if (hasSetCookieExpiresThatCannotBeConverted(denyResponseHeaders)) {
          throw "Set-Cookie contains 'Expires' that is not set to 1970.";
        } else {
          print("PING AUTH denied by policy provider, Returning HTTP status "
              + sidebandResponse.response.response_code);
          for (var key in denyResponseHeaders) {
            var vals = denyResponseHeaders[key];
            if (vals.length > 1) {
              for (var i = 0; i < vals.length; i++) {
                context.setVariable(
                    "PingAuth.faultResponse.header." + key + "." + (i + 1),
                    vals[i]);
              }
            } else {
              context.setVariable("PingAuth.faultResponse.header." + key,
                  vals[0]);
            }
          }

          context.setVariable("PingAuth.fault.statusCode",
              sidebandResponse.response.response_code);
          context.setVariable("PingAuth.fault.reasonPhrase",
              sidebandResponse.response.response_status);

          if (sidebandResponse.response.body) {
            context.setVariable("PingAuth.fault.payload",
                sidebandResponse.response.body);
          } else {
            context.removeVariable("PingAuth.fault.payload");
          }
        }
      } else if (response) {
        // In this case Ping is modifying the service's response headers

        response.status.message = sidebandResponse.response_status;
        response.status.code = sidebandResponse.response_code;
        // Sets the response body and headers as (potentially) modified by Ping
        response.content = sidebandResponse.body;
        mergeWithApigeeResponseHeaders(
            convertHeadersFromPing(sidebandResponse.headers), debug,
            "response header");
      } else {
        // In this case Ping is modifying the client's request body, headers and querystring

        // Remember the request state for the response call
        context.setVariable("PingAuth.state", sidebandResponse.state);

        // body
        if (sidebandResponse.body) {
          request.body = sidebandResponse.body;
        } else {
          request.body = "";
        }

        // headers
        mergeWithApigeeRequestHeaders(
            convertHeadersFromPing(sidebandResponse.headers), debug,
            "request header");

        // querystring
        if (sidebandResponse.url.indexOf('?') >= 0) {
          mergeApigeeQueryStringCollection(convertQueryStringToApigee(
                  sidebandResponse.url.substring(
                      sidebandResponse.url.indexOf('?') + 1)), request.queryParams,
              debug, "querystring param");
        }
      }
    } catch (ex) {
      print(
          "PING AUTH caught an exception while doing modifications to either request or response: ",
          ex);
      context.setVariable("PingAuth.fault.statusCode", "502");
      context.setVariable("PingAuth.fault.reasonPhrase", "Bad Gateway");
      context.setVariable("PingAuth.fault.payload", ex);
    }
  }