// transform from [{key: value1}, {key: value2}, ...]
// to {key: [value1, value2, ...]}
function convertHeadersFromPing(headersPing)
{
  var headersApigee = {};
  if(undefined !== headersPing && headersPing.length) {
    for (var i = 0; i < headersPing.length; i++) {
      var pair = headersPing[i];
      for (var key in pair) {
        headersApigee[key] = headersApigee[key] || [];
        headersApigee[key].push(pair[key]);
      }
    }
    return headersApigee;
  }
}

function convertServerSideErrorHeadersFromPing(headersPing)
{
  var headersApigee = {};
  if(undefined !== headersPing && headersPing.length)
  {
    for (var i = 0; i < headersPing.length; i++)
    {
      var pair = headersPing[i];
      for (var key in pair)
      {
        // Resolves an Apigee defect that incorrectly parses comma delimited date
        // Approach: If the plugin were to get a Set-Cookie header that had an
        //            Expires date set to Thu,01-Jan-1970 (it could be different formats), then add Max-Age=0
        if(key.toLowerCase() === "set-cookie")
        {
          if(pair[key].toLowerCase().includes("expires") &&
            (pair[key].includes("1970") || pair[key].includes("-70")))
          {
            const expiresValueArray = pair[key].match(/expires.+?;/i);
            if(expiresValueArray)
            {
              pair[key] = pair[key].replace(expiresValueArray[0], "Max-Age=0;");
            }
          }
        }

        // Adjust multi-value headers:
        //   The array will result in: headears(headerkey1, [value1, value2, value3, value4])
        //   The 'date' header, 'expires' header and sub-header will be excluded from parsing logic.
        //   The logic also handles the case when the same header names have different casings.
        if (pair[key])
        {
          if (!headersApigee[key.toLowerCase()])
          {
            headersApigee[key.toLowerCase()] = [];
          }
          if((key.toLowerCase() === 'date') || (key.toLowerCase() === 'expires')|| (pair[key].toLowerCase().includes("expires")))
          {
            headersApigee[key.toLowerCase()].push(pair[key]);
          }
          else
          {
            //split the content by comma and push each one to the values-array for the header/key
            var commaSplitValues = pair[key].split(",");
            commaSplitValues.forEach(item => (headersApigee[key.toLowerCase()].push(item)));
          }
        }
      }
    }
  }

  return headersApigee;
}

// transform from foo=value1&foo=value2
// to {foo: [value1, value2]}
function convertQueryStringToApigee(querystring)
{
  var pl     = /\+/g,  // Regex for replacing addition symbol with a space
    search = /([^&=]+)=?([^&]*)/g, // Regex to search for k=v pairs
    decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); },
    match;

  queryParamsApigee = {};
  while ((match = search.exec(querystring))) {
    var key = decode(match[1]);
    queryParamsApigee[key.toLowerCase()] = queryParamsApigee[key.toLowerCase()] || [];
    queryParamsApigee[key.toLowerCase()].push(decode(match[2]));
  }
  return queryParamsApigee;
}

function mergeWithApigeeRequestHeaders(convertedHeadersFromPing, debug, debugItemName)
{
  var receivedRequestHeaderNames = context.getVariable('request.headers.names').toArray();
  receivedRequestHeaderNames.forEach( function(name)
  {
    if (!convertedHeadersFromPing[name])
    {
      if (debug) { print("Merging headers - removing ", debugItemName, name); }
      context.removeVariable('request.header.' + name);
    }
  });

  // second pass, copy the values
  for (headerName in convertedHeadersFromPing)
  {
    if (debug) { print("Merging headers - adding ", debugItemName, headerName); }
    context.setVariable('request.header.' + headerName, convertedHeadersFromPing[headerName].toString());
  }
}

function mergeWithApigeeResponseHeaders(convertedHeadersFromPing, debug, debugItemName)
{
  var responseHeaderNames = context.getVariable('response.headers.names').toArray();
  responseHeaderNames.forEach( function(name)
  {
    if (!convertedHeadersFromPing[name])
    {
      if (debug) { print("Merging headers - removing ", debugItemName, name); }
      context.removeVariable('response.header.' + name);
    }
  });

  // second pass, copy the values
  for (headerName in convertedHeadersFromPing)
  {
    if (debug) { print("Merging headers - adding ", debugItemName, headerName); }
    context.setVariable('response.header.' + headerName, convertedHeadersFromPing[headerName].toString());
  }
}

function mergeApigeeQueryStringCollection(src, dst, debug, debugItemName) {
  var key;
  // first pass, remove everything in dst that isn't in src
  for (key in dst)
  {
    if (!src[key])
    {
      if (debug) { print("PING AUTH removing", debugItemName, key); }
      dst[key] = null;
    }
  }
  // second pass, copy the values
  for (key in src)
  {
    if (debug) { print("PING AUTH adding new", debugItemName, key); }
    dst[key] = src[key];
  }
  return dst;
}

// The converted headers have already replaced the set-cookie expires with max-age
//    Therefore we can conclude that if expires is still present, it's different date.
function hasSetCookieExpiresThatCannotBeConverted(convertedHeadersValuesArray)
{
  var hasExpires = false;
  for (var key in convertedHeadersValuesArray)
  {
    if(key.toLowerCase() === "set-cookie")
    {
      convertedHeadersValuesArray[key].forEach(value => {
        if(value.toLocaleLowerCase().includes("expires"))
        {
          hasExpires = true;
        }
      });
    }
  }
  if(hasExpires)
  {
    return true;
  }
  return false;
}
// We need these exports for the mocha tests. Apigee doesn't like the exports. We need to find a common ground...
// Uncomment the exports when running the tests. Comment them out when committing to master.
//exports.handleResponse = {
//  convertHeadersFromPing: convertHeadersFromPing,
//  convertServerSideErrorHeadersFromPing: convertServerSideErrorHeadersFromPing,
//  mergeApigeeQueryStringCollection: mergeApigeeQueryStringCollection,
//  convertQueryStringToApigee: convertQueryStringToApigee,
//  hasSetCookieExpiresThatCannotBeConverted: hasSetCookieExpiresThatCannotBeConverted
//}