var debug = (properties.debug == "true");
var requestHeaders = convertRequestHeadersToPing(debug, "request headers");
var responseHeaders = response ? convertResponseHeadersToPing(debug, "response headers") : [];

function assembleAccessTokenForSidebandRequest()
{
  var validated_access_token_values = {};
  var token_status = (context.getVariable('oauthv2accesstoken.GetOAuthv2Info.status') === "approved");
  validated_access_token_values["active"] = token_status;
  validated_access_token_values["scope"] = context.getVariable('oauthv2accesstoken.GetOAuthv2Info.scope');
  validated_access_token_values["client_id"] = context.getVariable('oauthv2accesstoken.GetOAuthv2Info.client_id');
  validated_access_token_values["token_type"] = context.getVariable('oauthv2accesstoken.GetOAuthv2Info.token_type');
  validated_access_token_values["exp"] = context.getVariable('oauthv2accesstoken.GetOAuthv2Info.expires_in');
  validated_access_token_values["iat"] = context.getVariable('oauthv2accesstoken.GetOAuthv2Info.issued_at');

  //-- The following are custom attributes and they are subject to change according to the present access token claims
  // Custom attributes are made available in a context variable with the name accesstoken.{custom_attribute}
  //validated_access_token_values["sub"] = context.getVariable('accesstoken.{custom_attribute}');
  //validated_access_token_values["username"] = context.getVariable('accesstoken.{custom_attribute}');
  //validated_access_token_values["aud"] = context.getVariable('accesstoken.{custom_attribute}');
  //validated_access_token_values["iss"] = context.getVariable('accesstoken.{custom_attribute}');
  //validated_access_token_values["jti"] = context.getVariable('accesstoken.{custom_attribute}');
  //validated_access_token_values["nbf"] = context.getVariable('accesstoken.{custom_attribute}');


  return validated_access_token_values;
}

var requestUrl;
if (response) {
    requestUrl = context.getVariable("PingAuth.origRequestUrl");
}
else {
    // This nonsense is to reconstruct the original client request
    // https://docs.apigee.com/api-platform/fundamentals/understanding-handling-request-response-data#access-request-messages
    var req_verb = context.getVariable('request.verb');
    var req_scheme = context.getVariable('client.scheme');
    var req_host = context.getVariable('request.header.host');
    var req_request_uri = context.getVariable('request.uri');
    requestUrl = req_scheme + "://" + req_host + req_request_uri;
    // save it so that we don't do this again
    context.setVariable("PingAuth.origRequestUrl", requestUrl);
}

var sidebandBody;
if (response)
{
    sidebandBody = {
        method: context.getVariable('request.verb'),
        http_version: context.getVariable("message.version"),
        response_code: response.status.code,
        response_status: response.status.message,
        url: requestUrl,
        headers: responseHeaders,
        state: context.getVariable("PingAuth.state")
    };
    if (response.content) {
        sidebandBody.body = response.content;
    }
}
else
{
  sidebandBody = {
    method: context.getVariable('request.verb'),
    http_version: context.getVariable("message.version"),
    source_ip: context.getVariable("client.ip"),
    source_port: context.getVariable("client.port"),
    url: requestUrl,
    headers: requestHeaders
  };

  var access_token = context.getVariable('oauthv2accesstoken.GetOAuthv2Info.access_token');
  if(access_token)
  {
    sidebandBody.access_token = assembleAccessTokenForSidebandRequest();
  }

  if (request.body) {
      sidebandBody.body = request.body;
  }
}

if (properties.debug == "true") {
    print("PING AUTH prepared request for policy provider ", JSON.stringify(sidebandBody));
}

// set the shared secret header directly in the callout request message
// this can't be done in the callout policy because the header name can vary (via config)
var secretHeaderName = context.getVariable("PingAuth.secretHeaderName");
var sharedSecret = context.getVariable("private.PingAuth.sharedSecret");
context.setVariable("PingAuth.calloutRequest.header." + secretHeaderName, sharedSecret);


// Set the Integration Kit Name and Integration Kit Version
var integrationKitName = "paz-sideband-apigee";
//  The version number corresponds to the version in package.json.
var integrationKitVersion = "1.1.0";
context.setVariable("PingAuth.calloutRequest.header.User-Agent",
    integrationKitName + "/" + integrationKitVersion);

// content type (and accept header) is set in the init message policy
context.setVariable("PingAuth.calloutRequest.content", JSON.stringify(sidebandBody));

var sidebandEndpoint = response ? "/sideband/response" : "/sideband/request";

// for PingOne the service is within the environment
var basePath = context.getVariable("PingAuth.serviceBasePath");
if (basePath && basePath !== "/") {
    sidebandEndpoint = basePath + sidebandEndpoint;
}

context.setVariable("PingAuth.calloutRequest.path", sidebandEndpoint);

// References:
//
// https://docs.apigee.com/api-platform/fundamentals/what-are-flows
// https://docs.apigee.com/api-platform/reference/javascript-object-model.html
// https://community.apigee.com/questions/38535/how-to-use-javascript-variable-in-raise-fault.html
// https://docs.apigee.com/api-platform/reference/variables-reference
// https://stackoverflow.com/questions/901115/how-can-i-get-query-string-values-in-javascript
