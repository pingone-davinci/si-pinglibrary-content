// transform {key: [value1, value2, ...]}
// to [{key: value1}, {key: value2}, ...]

function convertRequestHeadersToPing(debug, debugItemName) {
  var requestHeaders = context.getVariable('request.headers.names'),
    result = {};
  if (debug) { print(debugItemName, "names ", requestHeaders); }
  requestHeaders = requestHeaders + '';
  requestHeaders = requestHeaders.slice(1, -1).split(', ');
  requestHeaders.forEach(function(headerName)
  {
    result[headerName] = context.getVariable('request.header.' + headerName + '.values.string');
  });

  var headersPing = [];
  for (var headerName in result)
  {
    var value = result[headerName];
    pair = {};
    pair[headerName] = value;
    headersPing.push(pair);
  }

  if (debug) { print(debugItemName, "- headersPing after convert ", JSON.stringify(headersPing)); }

  return headersPing;
}


function convertResponseHeadersToPing(debug, debugItemName) {
  var responseHeaderNames = context.getVariable('response.headers.names'),
    result = {};
  if (debug) { print(debugItemName, "names ", responseHeaderNames); }
  responseHeaderNames = responseHeaderNames + '';
  responseHeaderNames = responseHeaderNames.slice(1, -1).split(', ');
  responseHeaderNames.forEach(function(headerName)
  {
    result[headerName] = context.getVariable('response.header.' + headerName + '.values.string');
  });

  var headersPing = [];
  for (var headerName in result)
  {
    var value = result[headerName];
    pair = {};
    pair[headerName] = value;
    headersPing.push(pair);
  }

  if (debug) { print(debugItemName, "- headersPing after convert ", JSON.stringify(headersPing)); }

  return headersPing;
}

// We need these exports for the mocha tests. Apigee doesn't like the exports. We need to find a common ground...
// Uncomment the exports when running the tests. Comment them out when committing to master.
//exports.prepareRequest = {
//  convertRequestHeadersToPing: convertRequestHeadersToPing,
//  convertResponseHeadersToPing: convertResponseHeadersToPing
//}