import javax.net.ssl.X509TrustManager;
import javax.net.ssl.TrustManager;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import java.security.cert.X509Certificate;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLContext;
import java.security.SecureRandom;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def targetMap = [:]

def header_map = attributes.headers
def status_code = attributes.statusCode
def reason_phrase = attributes.reasonPhrase
if (status_code != null && reason_phrase == null) {
    if (status_code == 404) {
        reason_phrase = "Not Found"
    } else if (status_code == 405) {
        reason_phrase = "Method Not Allowed"
    } else if (status_code == 400) {
        reason_phrase = "Bad Request"
    }

}
if (header_map == null || !(header_map instanceof Map) || status_code == null || reason_phrase == null) {
    log.error("The response from the API server is missing a required attribute. Please ensure headers, statusCode, and reasonPhrase are set.")
    targetMap.put('status', 502)
    return targetMap
}

def sideband_request = [:]
sideband_request['http_version'] = vars['request_version']
sideband_request['method'] = vars['request_method']
sideband_request['url'] = vars['orig_url']
sideband_request['state'] = vars['state']
sideband_request['response_code'] = status_code
sideband_request['response_status'] = reason_phrase
sideband_request['headers'] = convertHeadersFromMule(header_map)
if (responseBody && responseBody != "") {
    sideband_request['body'] = responseBody
}
def sideband_request_string = JsonOutput.toJson(sideband_request)
if (vars['debugLogging']) {
    log.info('Request to PingAuthorize /response endpoint: {}', sideband_request_string)
}
def sideband_request_bytes = sideband_request_string.getBytes("UTF-8")

String paz_host = vars['paz_host']

ConnectionTimeout = vars['paz_connection_timeout']
ReadTimeout = vars['paz_read_timeout']
pazToken = vars['paz_token']
useHTTPS = vars['paz_scheme']
allowSelfSigned = vars['paz_allow_ss_cert']

/**
 * Change headers from format used by PAZ to format used by Mule's HTTP-Transform
 * @param headers The headers in PAZ's format, an array of single attribute objects (like pairs)
 * @return The headers in Mule's format, just a Map.
 */
static def convertHeadersFromPaz(headers) {
    def formattedHeaders = [:]
    headers.each {
        it.each { key, value ->
            formattedHeaders.put(key, value)
        }
    }
    return formattedHeaders
}

static def convertHeadersFromMule(Map headers) {
    headers.collect { key, value ->
        [(key): value]
    }
}

try{
    HttpURLConnection post
    if(useHTTPS.equalsIgnoreCase("true")){
        post = new URL("https://" + paz_host + "/sideband/response").openConnection() as HttpURLConnection;
        if(allowSelfSigned.equalsIgnoreCase("true")){
            def trustAllCerts = [
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() { return null; }
                        public void checkServerTrusted(X509Certificate[] certs, String authType) throws CertificateException {}
                        public void checkClientTrusted(X509Certificate[] certs, String authType) throws CertificateException {}
                    }
            ] as TrustManager[];

            HostnameVerifier trustAllHostnames = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) { return true; }
            }
            System.setProperty("jsse.enableSNIExtension", "false");
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new SecureRandom());
            post.setSSLSocketFactory(sc.getSocketFactory());
            post.setHostnameVerifier(trustAllHostnames);
        }
    }
    else{
        post = new URL("http://" + paz_host + "/sideband/response").openConnection() as HttpURLConnection;
    }
    post.setConnectTimeout(ConnectionTimeout.toInteger());
    post.setReadTimeout(ReadTimeout.toInteger());
    post.setRequestMethod("POST")
    post.setDoOutput(true)
    post.setRequestProperty("Content-Type", "application/json")
    post.setRequestProperty("Content-Length", sideband_request_bytes.length.toString())
    if(pazToken?.trim()){
        post.setRequestProperty("PDG-TOKEN", pazToken)
    }
    post.getOutputStream().write(sideband_request_bytes);

    def postRC = post.getResponseCode()
    targetMap.put('status', postRC)

    if (post.getErrorStream() == null) {
        def response = new JsonSlurper().parse(post.getInputStream());
        if (vars['debugLogging']) {
            log.info("Response from PingAuthorize /response endpoint: {}", response.toString())
        }

        if(postRC == 200){
            def headers = response.get("headers")

            targetMap.put('headers', convertHeadersFromPaz(headers).findAll { it.key.toLowerCase() != 'content-encoding' });
            targetMap.put('body', response.get("body"));
            targetMap.put('response_code', response.get("response_code"));
            targetMap.put('response_status', response.get("response_status"))

            //        targetMap['Cookie'] = post.getHeaderField("Set-Cookie");
        }
    } else {
        def response = new JsonSlurper().parse(post.getErrorStream())
        log.error("Error: PingAuthorize server returned " + postRC + " " + post.getResponseMessage() + "\n" + response.inspect())
    }
    post.disconnect()
    return targetMap;
}
catch(Exception ex){
    log.error("Exception Occurred while sending request data to: "+ paz_host + ": "+ex)
    targetMap.put('status', 502)
    return targetMap
}
