import javax.net.ssl.X509TrustManager;
import javax.net.ssl.TrustManager;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import java.security.cert.X509Certificate;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLContext;
import java.security.SecureRandom;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import org.mule.extension.http.api.HttpRequestAttributesBuilder
import org.mule.runtime.api.util.MultiMap

def targetMap = [:]

targetMap.put('orig_attributes', attributes)

def header_map = attributes.headers
String base_url = attributes.scheme + "://" + header_map.get("Host")
String orig_url = base_url + attributes.requestUri
targetMap.put('base_url', base_url)
targetMap.put('orig_url', orig_url)

def source_parts = attributes.remoteAddress.substring(1).split(':')
def sideband_request = [:]
sideband_request['http_version'] = vars['request_version']
sideband_request['method'] = vars['request_method']
sideband_request['source_ip'] = source_parts[0]
sideband_request['source_port'] = source_parts[1]
sideband_request['url'] = orig_url
sideband_request['headers'] = convertHeadersFromMule(header_map)
if (vars['use_parsed_token']) {
    sideband_request['access_token'] = new JsonSlurper().parseText(parsedToken)
}
if (requestBody && (requestBody != "")) {
    sideband_request['body'] = requestBody
}
def sideband_request_string = JsonOutput.toJson(sideband_request)
if (vars['debugLogging']) {
    log.info('Request to PingAuthorize /request endpoint: {}', sideband_request_string)
}
def sideband_request_bytes = sideband_request_string.getBytes("UTF-8")

String paz_host = vars['paz_host']

ConnectionTimeout = vars['paz_connection_timeout']
ReadTimeout = vars['paz_read_timeout']
pazToken = vars['paz_token']
useHTTPS = vars['paz_scheme']
allowSelfSigned = vars['paz_allow_ss_cert']

/**
 * Change headers from format used by PAZ to format used by Mule's HTTP-Transform
 * @param headers The headers in PAZ's format, an array of single attribute objects (like pairs)
 * @return The headers in Mule's format, just a Map.
 */
static def convertHeadersFromPaz(headers) {
    def formattedHeaders = [:]
    headers.each {
        it.each { key, value ->
            formattedHeaders.put(key, value)
        }
    }
    return formattedHeaders
}

static def convertHeadersFromMule(Map headers) {
    headers.collect { key, value ->
        if (key.equalsIgnoreCase("accept-encoding")) {
            // we can only handle gzipped content using the mulesoft decompressor
            // so if the client can handle that then we forward send only 'gzip'
            // otherwise we send 'identity' in order to indicate we don't want anything compressed
            if (value ==~ /.*\bgzip\b.*/) {
                value = "gzip"
            }
            else {
                value = "identity"
            }
        }
        [(key): value]
    }
}

static def convertQuery(query) {
    if (query) {
        query.split('&').collectEntries {
            it.split('=').collect {
                URLDecoder.decode(it, 'UTF-8')
            }
        }
    }
    else {
        [:]
    }
}

try{
    HttpURLConnection post
    if(useHTTPS.equalsIgnoreCase("true")){
        post = new URL("https://" + paz_host + "/sideband/request").openConnection() as HttpURLConnection;
        if(allowSelfSigned.equalsIgnoreCase("true")){
            def trustAllCerts = [
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() { return null; }
                        public void checkServerTrusted(X509Certificate[] certs, String authType) throws CertificateException {}
                        public void checkClientTrusted(X509Certificate[] certs, String authType) throws CertificateException {}
                    }
            ] as TrustManager[];

            HostnameVerifier trustAllHostnames = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) { return true; }
            }
            System.setProperty("jsse.enableSNIExtension", "false");
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new SecureRandom());
            post.setSSLSocketFactory(sc.getSocketFactory());
            post.setHostnameVerifier(trustAllHostnames);
        }
    }
    else{
        post = new URL("http://" + paz_host + "/sideband/request").openConnection() as HttpURLConnection;
    }
    post.setConnectTimeout(ConnectionTimeout.toInteger());
    post.setReadTimeout(ReadTimeout.toInteger());
    post.setRequestMethod("POST")
    post.setDoOutput(true)
    post.setRequestProperty("Content-Type", "application/json")
    post.setRequestProperty("Content-Length", sideband_request_bytes.length.toString())
    if(pazToken?.trim()){
        post.setRequestProperty("PDG-TOKEN", pazToken)
    }
    post.getOutputStream().write(sideband_request_bytes);

    def postRC = post.getResponseCode()
    targetMap.put('status', postRC)

    if (post.getErrorStream() == null) {
        def response = new JsonSlurper().parse(post.getInputStream());
        if (vars['debugLogging']) {
            log.info("Response from PingAuthorize /request endpoint: {}", response.toString())
        }


        if(postRC == 200) {
            def respondNow = response.containsKey("response");
            targetMap.put("respondNow", respondNow);
            if (respondNow) {
                def responseToSend = response.get("response");
                targetMap.put("response_code", responseToSend.get("response_code"))
                targetMap.put('response_status', responseToSend.get("response_status"))
                // PAZ returns each header as a separate object
                def returnedHeaders = responseToSend.get("headers")
                targetMap.put('headers', convertHeadersFromPaz(returnedHeaders))

                targetMap.put('body', responseToSend.get("body"));
            } else {
                String returnedUrlString = response.get("url")
                targetMap.put('requestUriWasModified', orig_url != returnedUrlString)
                def returnedUrl = new URL(returnedUrlString)
                def returnedPath = returnedUrl.getPath()
                def returnedQuery = returnedUrl.getQuery()
                if (returnedQuery) {
                    targetMap.put('requestUri', returnedPath + '?' + returnedQuery)
                }
                else {
                    targetMap.put('requestUri', returnedPath)
                }
                targetMap.put('requestPath', returnedPath)
                if (attributes.relativePath != null) {
                    if (returnedPath != attributes.requestPath) {
                        // try to reconstruct relativePath
                        def basePath = attributes.requestPath.substring(attributes.requestPath.indexOf(attributes.relativePath))
                        if (returnedPath.startsWith(basePath)) {
                            targetMap.put('relativePath', returnedPath.substring(basePath.length()))
                        }
                    }
                    else {
                        targetMap.put('relativePath', attributes.relativePath)
                    }
                }
                if (returnedQuery == null) {
                    returnedQuery = ''
                }
                targetMap.put('queryParams', convertQuery(returnedQuery))
                targetMap.put('queryString', returnedQuery)
                def returnedHeaders = response.get("headers")
                targetMap.put('headers', convertHeadersFromPaz(returnedHeaders))
                targetMap.put('body', response.get("body"))
                targetMap.put('state', response.get("state"))
                targetMap.put('method', response.get("method"))

                HttpRequestAttributesBuilder requestAttributesBuilder = new HttpRequestAttributesBuilder(attributes)
                requestAttributesBuilder.method(response.get("method"))
                        .queryParams(new MultiMap(targetMap.get('queryParams')))
                        .headers(new MultiMap(targetMap.get('headers')))
                        .uriParams(attributes.uriParams)
                        .requestPath(targetMap.get('requestPath'))
                        .rawRequestPath(targetMap.get('requestPath'))
                        .relativePath(targetMap.get('relativePath'))
                        .requestUri(targetMap.get('requestUri'))
                        .rawRequestUri(targetMap.get('requestUri'))
                        .queryString(returnedQuery)

                targetMap.put('builtAttributes', requestAttributesBuilder.build())
                if (targetMap.get("requestUriWasModified")) {
                    log.info("Request URI was modified by PingAuthorize. Some path-related attributes will be removed from the message.")
                }
            }
        }
            //        targetMap['Cookie'] = post.getHeaderField("Set-Cookie");
    } else {
        def response = new JsonSlurper().parse(post.getErrorStream())
        log.error("Error: PingAuthorize server returned " + postRC + " " + post.getResponseMessage() + "\n" + response.inspect())
    }
    post.disconnect()

    return targetMap;
}
catch(Exception ex){
    log.error("Exception Occurred while sending request data to: "+ paz_host + ": "+ex)
    targetMap.put('status', 502)
    return targetMap
}