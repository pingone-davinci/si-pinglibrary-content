'use strict';
/*
 * AWS Lambda Authorizer Version: 1.3.0
 */
const http = require("https");
const config = require("./config");

const networkErrorCodes = ["UND_ERR_SOCKET", "UND_ERR_CONNECT_TIMEOUT",
  "UND_ERR_HEADERS_TIMEOUT", "UND_ERR_BODY_TIMEOUT", "UND_ERR_SOCKET_CLOSED",
  "ECONNRESET", "ETIMEDOUT", "ENOTFOUND", "EAI_AGAIN",
  "ECONNREFUSED", "ECONNABORTED", "EHOSTUNREACH", "ENETUNREACH", "EPIPE",
  "EADDRINUSE"];

/**
 * Makes a request to the sideband API and handles retries based on response status.
 *
 * @param {Object} sidebandApiRequest - The request options for the sideband API.
 * @param {string} sidebandApiBodyString - The JSON stringified body of the request.
 * @returns {Promise<Object>} - Resolves with the response body from the sideband API or rejects with an error.
 */
module.exports = (sidebandApiRequest, sidebandApiBodyString) => {
  const serviceUrlArray = config.serviceUrl.split("\/");

  const options = {
    ...sidebandApiRequest,
    keepalive: true,
    host: serviceUrlArray[2],
    port: 443,
    body: sidebandApiBodyString,
  };

  /**
   * Executes the HTTP request and handles retry logic for specific status codes.
   *
   * @param {number} retry - The current retry attempt number.
   * @returns {Promise<Object>} - Resolves with the response or rejects with an error.
   */
  const doRequest = async (retry) => {
    let response;
    try {
      response = await fetch(sidebandApiRequest.path, options);
    }
    catch (error) {
      if (error?.cause?.code && networkErrorCodes.includes(error.cause.code) && retry < config.maxRetries) {
        console.warn(`Network failure: ${error.cause.code}. Retry #${retry
        + 1} of ${config.maxRetries}`);
        return doRequest(retry + 1);
      } else {
        throw error;
      }
    }

    const responseStatus = response.status;
    const httpStatusCodeMessage = `HTTP response: Status code ${responseStatus}`;

    if (responseStatus === 200) {
      return response.json();
    }
    if (responseStatus === 429) {
      console.warn(httpStatusCodeMessage);
      return response.json();
    } else if (responseStatus >= 500 && responseStatus <= 599 && retry < config.maxRetries) {
      console.warn(`${httpStatusCodeMessage}. Retry #${retry
      + 1} of ${config.maxRetries}`);
      return doRequest(retry + 1);
    }
    const responseBody = await response.json();
    throw new Error(`Request failed with status code: ${responseStatus} and body: ${responseBody}`);
  };

  return doRequest(0);
};