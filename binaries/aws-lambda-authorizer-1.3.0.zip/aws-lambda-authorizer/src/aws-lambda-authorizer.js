'use strict';

/*
* Aws Lambda Authorizer Version : 1.3.0
* */

const querystring = require("querystring");
const callSidebandApi = require("./callsideband-node");
const config = require("./config");

const isDebugEnabled = (process.env.IS_DEBUG_ENABLED === 'true');
const gatewayName = "aws-api-gateway-authorizer";
const gatewayVersion = "1.3.0";

let isCircuitClosed = true;
let circuitTimer = 0;
let startTime = 0;
let endTime = 0;

/**
 * Converts the server response from Ping into a context object by stringifying any nested objects.
 * This is used to support API Gateway IAM Policy by ensuring all properties are in a string format.
 *
 * @param {Object} pingServerResponse - The server response object from Ping.
 * @returns {Object} context - The context object with all properties, where objects are stringified.
 */
const translateServerErrorToContext = (pingServerResponse) => {
  let context = {};
  for (let prop in pingServerResponse) {
    let value = pingServerResponse[prop];

    if (typeof value === "object") {
      context[prop] = JSON.stringify(value);
    } else {
      context[prop] = value;
    }
  }
  return context;
};

/**
 * Generates an IAM policy response object for HTTP 2.0 protocol.
 *
 * @param {string} isAuthorized - Indicates whether the request is allowed or denied ("Allow" or "Deny").
 * @param {Object} pingServerResponse - The response object used to populate the 'context' in the policy document.
 * @returns {Object} - The IAM policy document containing the authorization status and context variables for HTTP 2.0 protocol.
 */
const generateAuthorizerResponseV2 = (isAuthorized, pingServerResponse) => ({
  isAuthorized,
  context: translateServerErrorToContext(pingServerResponse)
});

/**
 * Generates a custom error response for the authorizer with a specified status code.
 *
 * @param {Object} body - The body of the response, typically containing error details.
 * @param {Object} header - Additional headers to be included in the response.
 * @param {number} code - The HTTP status code for the response (defaults to 500).
 * @returns {Object} - The structured error response containing the status code, headers, and body.
 */
const generateAuthorizerResponseError = (body, header, code = 500) => {
  return {
    statusCode: code,
    headers: {
      ...header
    },
    body: JSON.stringify(body)
  };
};

/**
 * Generates an IAM policy response object for HTTP 1.1 protocol.
 *
 * @param {string} principalId - The ID of the principal (can be left empty).
 * @param {string} resource - The AWS API Gateway resource being accessed.
 * @param {string} isAuthorized - Indicates whether the request is allowed or denied ("Allow" or "Deny").
 * @param {Object} pingServerResponse - The response object used to populate the 'context' in the policy document.
 * @returns {Object} - The AWS Policy Document containing the principal ID, policy details, and context variables for HTTP 1.1 protocol.
 */
const generateAuthorizerResponseV1 = (principalId, resource, isAuthorized,
    pingServerResponse) => ({
  principalId,
  policyDocument: {
    Version: "2012-10-17",
    Statement: [{
      Action: "execute-api:Invoke",
      Effect: isAuthorized ? "Allow" : "Deny",
      Resource: resource
    }]
  },
  context: translateServerErrorToContext(pingServerResponse)
})

/**
 * Checks if the provided object is empty or null.
 * Returns true if the object is empty; otherwise, returns false.
 *
 * @param {Object} object - The object to check for emptiness.
 * @returns {boolean} - True if the object is empty or null, otherwise false.
 */
const isEmptyObject = (object) => {
  if (object === null) {
    return true;
  }

  for (let prop in object) {
    if (object.hasOwnProperty(prop)) {
      return false;
    }
  }

  return true;
};

/**
 * Asynchronous function handler that processes the HTTP REST event object,
 * validates the request against the sideband, and sends a response to the API Gateway caller.
 *
 * @param {Object} event - The AWS API Gateway HTTP request event.
 * @returns {Promise<Object>} - Returns an AWS Policy Document with 'Allow' or 'Deny'.
 */
const handler = async (event) => {
  try {

    if (Object.is(event, null) || Object.is(event, undefined)) {
      return "";
    }

    const isVersion2 = event.version === "2.0";

    let headers = [];
    for (let headerKey in event.headers) {
      let pair = {};
      pair[headerKey] = event.headers[headerKey];
      if (headerKey === "Content-Length") {
        pair[headerKey] = "0";
      }
      headers.push(pair);
    }

    let queryString = "";
    if (isVersion2 && event.rawQueryString) {
      queryString = "?" + event.rawQueryString;
    } else if (!isVersion2 && !isEmptyObject(
        event.multiValueQueryStringParameters)) {
      queryString = "?" + querystring.stringify(
          event.multiValueQueryStringParameters);
    }

    const baseurlScheme = event.headers["X-Forwarded-Proto"] || "https";
    const baseurlHost = event.headers["Host"]
        || event.requestContext.domainName;
    const baseurl = `${baseurlScheme}://${baseurlHost}`;

    let sidebandApiBody;
    if (isVersion2) {
      sidebandApiBody = {
        method: event.requestContext.http.method,
        http_version: event.requestContext.http.protocol.split("/")[1],
        source_ip: event.requestContext.http.sourceIp,
        source_port: event.headers["x-forwarded-port"] || "443",
        url: `${baseurl}${event.rawPath}${queryString}`,
        headers: headers
      };
    } else {
      sidebandApiBody = {
        method: event.requestContext.httpMethod,
        http_version: event.requestContext.protocol.split("/")[1],
        source_ip: event.requestContext.identity.sourceIp,
        source_port: event.headers['x-forwarded-port'] || "443",
        url: `${baseurl}${event.path}${queryString}`,
        headers: headers
      };
    }

    const sidebandApiBodyString = JSON.stringify(sidebandApiBody);

    const sidebandApiRequest = {
      method: "POST",
      path: `${config.serviceUrl}/sideband/request`,
      headers: {
        "Client-Token": config.secretHeaderValue,
        "Content-Type": "application/json; charset=utf-8",
        "Content-Length": Buffer.from(sidebandApiBodyString).length,
        "User-Agent": `${gatewayName}/${gatewayVersion}`
      }
    };

    const generateResponse = isVersion2 ? generateAuthorizerResponseV2
        : generateAuthorizerResponseV1.bind(null, "", event.methodArn);
    endTime = new Date().getTime();
    const timeDifference = Math.abs((endTime - startTime) / 1000);

    if (timeDifference > circuitTimer && !isCircuitClosed) {
      startTime = 0;
      isCircuitClosed = true;
    }

    let sidebandApiResponse = null;

    if (isCircuitClosed) {
      sidebandApiResponse = await callSidebandApi(sidebandApiRequest,
          sidebandApiBodyString);

      if (sidebandApiResponse.response) {
        // The Sideband API returns a 200 OK status code with a response_code
        // property in the body with a 401 indicating a failure,
        // so we check the body here instead of the status code
        if (parseInt(sidebandApiResponse.response.response_code) === 401) {
          throw new Error('Unauthorized');
        }
        console.log("Deny Access");
        return generateResponse(false, sidebandApiResponse.response);
      } else {
        if (Object.hasOwn(sidebandApiResponse, 'code')) {
          isCircuitClosed = false;
          startTime = new Date().getTime();
          circuitTimer = sidebandApiResponse['retry-after'] || 1;
          if (isDebugEnabled) {
            console.log("Circuit Time interval to retry= %s seconds",
                circuitTimer);
          }
          return generateAuthorizerResponseError(sidebandApiResponse,
              `retry-after: ${circuitTimer}`, 500);
        }
        console.log("Allow Access");
        return generateResponse(true);
      }
    } else {
      if (isDebugEnabled) {
        console.log("Circuit is open");
      }
      return generateAuthorizerResponseError("Rate Limit-Exceeded",
          `retry-after: ${circuitTimer}`, 500);
    }
  } catch (error) {
    console.error("An error happened while processing the request = %o", error);
    throw error;
  }
};

module.exports = {
  isEmptyObject,
  generateAuthorizerResponseV1,
  translateServerErrorToContext,
  generateAuthorizerResponseV2,
  handler
};
