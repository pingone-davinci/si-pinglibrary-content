'use strict';
/*
* Aws Lambda Authorizer Version : 1.3.0
* */

const credential = process.env.SECRET_HEADER_VALUE;
const serviceUrl = process.env.SERVICE_URL;

module.exports = {
  serviceUrl: serviceUrl,
  secretHeaderValue: credential,
  maxRetries: 1,
};