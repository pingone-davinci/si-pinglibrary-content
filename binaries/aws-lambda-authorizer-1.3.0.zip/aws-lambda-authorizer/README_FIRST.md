## Access Online Documentation

For AWS Lambda Authorizer Integration documentation, please visit PingAuthorize [AWS Lambda Authorizer Integrations](https://docs.pingidentity.com/access/sources/dita/topic?resourceid=pingone_p1az_amazon_api_gateway_integration).

For the latest PingAuthorize documentation, please visit our [Documentation Site](https://docs.pingidentity.com/csh?Product=paz-latest&Page=home).

## Access Developer Resources

For the latest developer resources, please visit our [Developer Site](https://developer.pingidentity.com/en/cloud-software/pingauthorize.html).

## Get Product Support

For deployment, installation, administration, integration, and configuration issues, please reach out to [Ping Identity Support](https://support.pingidentity.com/s/).